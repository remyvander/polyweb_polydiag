/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 129.85.163.136    Database: hgmd_pro-2024.1
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allgenes`
--

DROP TABLE IF EXISTS `allgenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allgenes` (
  `disease` text DEFAULT NULL COMMENT 'Concatenated HGMD phenotypes',
  `expected_inheritance` varchar(5) DEFAULT NULL COMMENT 'Inheritance pattern expected for the predominant phenotype(s) associated with a defect in the related gene',
  `gene_id` int(11) DEFAULT NULL COMMENT 'HGMD gene identifier (from MARKNAME table)',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `chrom` varchar(25) DEFAULT NULL COMMENT 'Chromosomal position (from MARKNAME table)',
  `genename` varchar(200) DEFAULT NULL COMMENT 'Gene name (from MARKNAME table)',
  `refseq` varchar(25) DEFAULT NULL COMMENT 'RefSeq sequence utilised by HGMD',
  `altsymbol` text DEFAULT NULL COMMENT 'Alternate gene symbols',
  `altname` text DEFAULT NULL COMMENT 'Alternate gene names',
  `gdbid` varchar(8) DEFAULT NULL COMMENT 'Genome DataBase identifier now redundant',
  `omimid` varchar(8) DEFAULT NULL COMMENT 'OMIM identifier',
  `entrezID` varchar(10) DEFAULT NULL COMMENT 'Entrez Gene identifier',
  `hgncID` varchar(10) DEFAULT NULL COMMENT 'HUGO Gene Nomenclature Committee identifier',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `svar` int(11) DEFAULT NULL COMMENT 'HGMD gene ID for alternate isoform',
  `mut` char(1) DEFAULT NULL COMMENT 'Disease mutation flag',
  `poly` char(1) DEFAULT NULL COMMENT 'Polymorphism flag',
  `ftv` char(1) DEFAULT NULL COMMENT 'Frameshift/truncating variant flag (now redundant)',
  `go_terms_acc` text DEFAULT NULL COMMENT 'GO terms concatenated accession numbers',
  `go_terms_name` text DEFAULT NULL COMMENT 'GO terms concatenated names',
  `mut_total` int(11) DEFAULT NULL COMMENT 'Total number of entries in HGMD',
  `new_mut_total` int(11) DEFAULT NULL COMMENT 'Total number of new genes for the current release',
  `gene_date` date DEFAULT NULL COMMENT 'Date entered into HGMD (from MARKNAME table)',
  PRIMARY KEY (`gene`),
  UNIQUE KEY `refseq` (`refseq`),
  UNIQUE KEY `gdbid` (`gdbid`),
  UNIQUE KEY `entrezID` (`entrezID`),
  UNIQUE KEY `hgncID` (`hgncID`),
  FULLTEXT KEY `ALLFIELDS` (`disease`,`gene`,`altsymbol`,`altname`,`chrom`,`genename`,`gdbid`,`omimid`,`entrezID`,`hgncID`,`refseq`,`comments`,`go_terms_acc`,`go_terms_name`),
  FULLTEXT KEY `GENEDATA` (`gene`,`altsymbol`,`altname`,`genename`),
  FULLTEXT KEY `OTHERDATA` (`hgncID`,`omimid`,`gdbid`,`entrezID`),
  FULLTEXT KEY `GOTERMS` (`go_terms_acc`,`go_terms_name`),
  FULLTEXT KEY `DISEASE` (`disease`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allgenes`
--

LOCK TABLES `allgenes` WRITE;
/*!40000 ALTER TABLE `allgenes` DISABLE KEYS */;
/*!40000 ALTER TABLE `allgenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allmut`
--

DROP TABLE IF EXISTS `allmut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allmut` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) DEFAULT NULL COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `chrom` varchar(25) DEFAULT NULL COMMENT 'Chromosomal location (from MARKNAME table)',
  `genename` varchar(200) DEFAULT NULL COMMENT 'HGMD gene name (from MARKNAME table)',
  `gdbid` varchar(8) DEFAULT NULL COMMENT 'GenomeDataBase identifier (from MARKNAME table)',
  `omimid` varchar(8) DEFAULT NULL COMMENT 'OMIM identifier (from MARKNAME table)',
  `amino` varchar(8) DEFAULT NULL COMMENT 'Amino acid change (from MUTATION table)',
  `deletion` varchar(65) DEFAULT NULL COMMENT 'Deleted nucleotides (lowercase) with 10bp flanking sequence (from DELETION or INDEL tables)',
  `insertion` varchar(65) DEFAULT NULL COMMENT 'Inserted nucleotides (lowercase) with 10bp flanking sequence (from INSERTION or INDEL table)',
  `codon` int(11) DEFAULT NULL COMMENT 'Codon number (from MUTATION, DELETION, INSERTION or INDEL tables)',
  `codonAff` int(11) DEFAULT NULL COMMENT 'Codon directly affected by the mutation',
  `descr` varchar(125) DEFAULT NULL COMMENT 'Narrative description of the mutation',
  `refseq` varchar(25) DEFAULT NULL COMMENT 'NCBI RefSeq reference sequence',
  `hgvs` varchar(60) DEFAULT NULL COMMENT 'HGVS compliant c-dot nomenclature (from MUTNOMEN table)',
  `hgvsAll` varchar(120) DEFAULT NULL COMMENT 'Composite c-dot and p-dot nomenclature (for indexing purposes)',
  `dbsnp` varchar(12) DEFAULT NULL COMMENT 'dbSNP identifier',
  `chromosome` varchar(2) DEFAULT NULL COMMENT 'Chromosome number (from hg38_COORDS table)',
  `startCoord` int(11) DEFAULT NULL,
  `endCoord` int(11) DEFAULT NULL,
  `expected_inheritance` varchar(5) DEFAULT NULL COMMENT 'Inheritance pattern expected for the predominant phenotype(s) associated with a defect in the related gene',
  `gnomad_AC` int(11) DEFAULT NULL,
  `gnomad_AF` double DEFAULT NULL,
  `gnomad_AN` int(11) DEFAULT NULL,
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `dmsupport` int(11) DEFAULT NULL,
  `rankscore` double DEFAULT NULL,
  `mutype` varchar(25) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `title` text DEFAULT NULL,
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `allname` varchar(200) DEFAULT NULL,
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` char(4) DEFAULT NULL,
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `pmidAll` text DEFAULT NULL,
  `reftag` char(3) DEFAULT NULL,
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  `base` char(1) DEFAULT NULL,
  `clinvarID` varchar(25) DEFAULT NULL,
  `clinvar_clnsig` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`acc_num`),
  KEY `hgvs` (`hgvs`),
  KEY `pmid` (`pmid`),
  KEY `gene` (`gene`),
  KEY `codonAff` (`codonAff`),
  KEY `dbsnp` (`dbsnp`),
  KEY `mutype` (`mutype`),
  FULLTEXT KEY `ALLFIELDS` (`disease`,`gene`,`chrom`,`genename`,`gdbid`,`omimid`,`author`,`fullname`,`allname`,`vol`,`page`,`year`,`pmid`,`pmidAll`,`comments`,`acc_num`),
  FULLTEXT KEY `REFFIELDS` (`gene`,`author`,`fullname`,`allname`,`year`,`pmid`,`pmidAll`),
  FULLTEXT KEY `ACC` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allmut`
--

LOCK TABLES `allmut` WRITE;
/*!40000 ALTER TABLE `allmut` DISABLE KEYS */;
/*!40000 ALTER TABLE `allmut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `altname`
--

DROP TABLE IF EXISTS `altname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `altname` (
  `altname_id` int(11) NOT NULL DEFAULT 0 COMMENT 'Internal identifier',
  `gene_id` int(11) DEFAULT NULL COMMENT 'HGMD gene identifier (from MARKNAME table)',
  `altname` varchar(100) DEFAULT NULL COMMENT 'Alternate gene name',
  PRIMARY KEY (`altname_id`),
  UNIQUE KEY `gene_id` (`gene_id`,`altname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `altname`
--

LOCK TABLES `altname` WRITE;
/*!40000 ALTER TABLE `altname` DISABLE KEYS */;
/*!40000 ALTER TABLE `altname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `altsym`
--

DROP TABLE IF EXISTS `altsym`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `altsym` (
  `alt_id` int(11) NOT NULL DEFAULT 0 COMMENT 'Internal identifier',
  `gene_id` int(11) DEFAULT NULL COMMENT 'HGMD gene identifier (from MARKNAME table)',
  `altsymbol` varchar(35) DEFAULT NULL COMMENT 'Alternative gene symbol',
  PRIMARY KEY (`alt_id`),
  UNIQUE KEY `gene_id` (`gene_id`,`altsymbol`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `altsym`
--

LOCK TABLES `altsym` WRITE;
/*!40000 ALTER TABLE `altsym` DISABLE KEYS */;
/*!40000 ALTER TABLE `altsym` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amino`
--

DROP TABLE IF EXISTS `amino`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amino` (
  `code3` char(4) NOT NULL DEFAULT '' COMMENT 'Triplet amino acid abbreviation',
  `code1` char(1) DEFAULT NULL COMMENT 'Single letter amino acid code',
  `full` varchar(15) DEFAULT NULL COMMENT 'Full amino acid name',
  `polarity` char(3) DEFAULT NULL COMMENT 'Polarity of amino acid',
  `pH` varchar(15) DEFAULT NULL COMMENT 'pH range of amino acid',
  `weight` int(11) DEFAULT NULL COMMENT 'Weight of amino acid residue',
  `hydrophob` decimal(2,1) DEFAULT NULL COMMENT 'Amino acid hydrophobicity',
  `hydrophil` decimal(2,1) DEFAULT NULL COMMENT 'Amino acid hydophilicity',
  `sec` varchar(20) DEFAULT NULL COMMENT 'Amino acid secondary structure propensity',
  PRIMARY KEY (`code3`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amino`
--

LOCK TABLES `amino` WRITE;
/*!40000 ALTER TABLE `amino` DISABLE KEYS */;
/*!40000 ALTER TABLE `amino` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aminoseq`
--

DROP TABLE IF EXISTS `aminoseq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aminoseq` (
  `gene_id` int(11) NOT NULL DEFAULT 0 COMMENT 'HGMD gene identifier (from MARKNAME table)',
  `gene` varchar(15) DEFAULT NULL COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `txid` int(11) DEFAULT NULL COMMENT 'Taxonomy ID from NCBI Taxonomy database',
  `species` varchar(50) DEFAULT NULL COMMENT 'Latin (Linnean) species name',
  `sp_name` varchar(50) DEFAULT NULL COMMENT 'Species name (English)',
  `prot_seq` text DEFAULT NULL COMMENT 'Protein sequence single letter code',
  `prot_acc` varchar(25) NOT NULL COMMENT 'NCBI RefSeq protein sequence identifier',
  `prot_ver` varchar(2) DEFAULT NULL COMMENT 'NCBI RefSeq protein sequence version',
  `curated` char(1) DEFAULT NULL COMMENT 'Automatic or Manual curation',
  PRIMARY KEY (`prot_acc`,`gene_id`),
  KEY `gene` (`gene`),
  KEY `txid` (`txid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aminoseq`
--

LOCK TABLES `aminoseq` WRITE;
/*!40000 ALTER TABLE `aminoseq` DISABLE KEYS */;
/*!40000 ALTER TABLE `aminoseq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amplet`
--

DROP TABLE IF EXISTS `amplet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amplet` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `chrom` varchar(3) DEFAULT NULL COMMENT 'Chromosome',
  `amplet` varchar(50) NOT NULL DEFAULT '' COMMENT 'Repeated sequence',
  `norcopy` varchar(35) NOT NULL DEFAULT '' COMMENT 'Reported copy range normally found in population',
  `patcopy` varchar(35) NOT NULL DEFAULT '' COMMENT 'Reported copy range found in population with phenotype',
  `location` varchar(25) NOT NULL DEFAULT '' COMMENT 'Narrative location of repeat',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`gene`,`amplet`,`norcopy`,`patcopy`,`location`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amplet`
--

LOCK TABLES `amplet` WRITE;
/*!40000 ALTER TABLE `amplet` DISABLE KEYS */;
/*!40000 ALTER TABLE `amplet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complex`
--

DROP TABLE IF EXISTS `complex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complex` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `descr` varchar(75) NOT NULL DEFAULT '' COMMENT 'Narrative description of variant',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) NOT NULL DEFAULT '' COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`gene`,`descr`,`pmid`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complex`
--

LOCK TABLES `complex` WRITE;
/*!40000 ALTER TABLE `complex` DISABLE KEYS */;
/*!40000 ALTER TABLE `complex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbnsfp3`
--

DROP TABLE IF EXISTS `dbnsfp3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbnsfp3` (
  `id` int(11) NOT NULL DEFAULT 0,
  `acc_num` varchar(10) DEFAULT NULL COMMENT 'HGMD mutation accession number',
  `SIFT` varchar(120) DEFAULT NULL COMMENT 'dbNSFP3 SIFT prediction',
  `Polyphen2_HVAR_pred` text DEFAULT NULL COMMENT 'dbNSFP3 PolyPhen prediction',
  `LRT` varchar(1) DEFAULT NULL COMMENT 'dbNSFP3 LRT prediction',
  `mutationTaster` varchar(67) DEFAULT NULL COMMENT 'dbNSFP3 MutationTaster prediction',
  `mutationAssessor` varchar(15) DEFAULT NULL COMMENT 'dbNSFP3 MutationAssessor prediction',
  `FATHMM` varchar(120) DEFAULT NULL COMMENT 'dbNSFP3 FATHMM prediction',
  `PROVEAN` varchar(120) DEFAULT NULL COMMENT 'dbNSFP3 PROVEAN prediction',
  `MCAP` varchar(1) DEFAULT NULL COMMENT 'dbNSFP3 MCAP prediction',
  `CADD_phred` double DEFAULT NULL COMMENT 'dbNSFP3 CADD score',
  `fathmm_MKL` char(1) DEFAULT NULL COMMENT 'dbNSFP3 FATHMM_MKL prediction',
  `MetaSVM_pred` char(1) DEFAULT NULL COMMENT 'dbNSFP3 MetaSVM prediction',
  `MetaLR_pred` char(1) DEFAULT NULL COMMENT 'dbNSFP3 MetaLR prediction',
  `ExAC_AC` varchar(6) DEFAULT NULL COMMENT 'dbNSFP3 ExAC allele count',
  `ExAC_AF` varchar(9) DEFAULT NULL COMMENT 'dbNSFP3 ExAC allele frequency',
  `1000Gp3_AC` varchar(4) DEFAULT NULL COMMENT 'dbNSFP3 1000 Genomes allele count',
  `1000Gp3_AF` varchar(21) DEFAULT NULL COMMENT 'dbNSFP3 1000 Genomes allele frequency',
  `gnomAD_AC` varchar(6) DEFAULT NULL COMMENT 'dbNSFP3 gnomAD allele count',
  `gnomAD_AF` varchar(12) DEFAULT NULL COMMENT 'dbNSFP3 gnomAD allele frequency',
  `Interpro` text DEFAULT NULL COMMENT 'dbNSFP3 InterPro domain',
  `phastCons100` varchar(10) DEFAULT NULL COMMENT 'dbNSFP3 PHAST conservation (100 species)',
  `phyloP100` varchar(15) DEFAULT NULL COMMENT 'dbNSFP3 phylogenetic p-values (100 species)',
  `phastCons20` varchar(10) DEFAULT NULL COMMENT 'dbNSFP3 PHAST conservation (20 species)',
  `phyloP20` varchar(15) DEFAULT NULL COMMENT 'dbNSFP3 phylogenetic p-values (20 species)',
  `GERP_RS` varchar(15) DEFAULT NULL COMMENT 'dbNSFP3 GERP conservation score',
  PRIMARY KEY (`id`),
  KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbnsfp3`
--

LOCK TABLES `dbnsfp3` WRITE;
/*!40000 ALTER TABLE `dbnsfp3` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbnsfp3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbnsfp4`
--

DROP TABLE IF EXISTS `dbnsfp4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbnsfp4` (
  `id` int(11) NOT NULL DEFAULT 0,
  `acc_num` varchar(10) DEFAULT NULL COMMENT 'HGMD mutation accession number',
  `SIFT` varchar(120) DEFAULT NULL COMMENT 'dbNSFP4 SIFT prediction',
  `Polyphen2_HVAR_pred` text DEFAULT NULL COMMENT 'dbNSFP4 PolyPhen prediction',
  `LRT` varchar(1) DEFAULT NULL COMMENT 'dbNSFP4 LRT prediction',
  `mutationTaster` varchar(75) DEFAULT NULL COMMENT 'dbNSFP4 MutationTaster prediction',
  `mutationAssessor` varchar(75) DEFAULT NULL COMMENT 'dbNSFP4 MutationAssessor prediction',
  `FATHMM` varchar(120) DEFAULT NULL COMMENT 'dbNSFP4 FATHMM prediction',
  `PROVEAN` varchar(120) DEFAULT NULL COMMENT 'dbNSFP4 PROVEAN prediction',
  `MCAP` varchar(1) DEFAULT NULL COMMENT 'dbNSFP4 MCAP prediction',
  `CADD_phred` double DEFAULT NULL COMMENT 'dbNSFP4 CADD score',
  `fathmm_MKL` char(1) DEFAULT NULL COMMENT 'dbNSFP4 FATHMM_MKL prediction',
  `MetaSVM_pred` char(1) DEFAULT NULL COMMENT 'dbNSFP4 MetaSVM prediction',
  `MetaLR_pred` char(1) DEFAULT NULL COMMENT 'dbNSFP4 MetaLR prediction',
  `ExAC_AC` varchar(6) DEFAULT NULL COMMENT 'dbNSFP4 ExAC allele count',
  `ExAC_AF` varchar(9) DEFAULT NULL COMMENT 'dbNSFP4 ExAC allele frequency',
  `1000Gp3_AC` varchar(4) DEFAULT NULL COMMENT 'dbNSFP4 1000 Genomes allele count',
  `1000Gp3_AF` varchar(21) DEFAULT NULL COMMENT 'dbNSFP4 1000 Genomes allele frequency',
  `gnomAD_AC` varchar(6) DEFAULT NULL COMMENT 'dbNSFP4 gnomAD allele count',
  `gnomAD_AF` varchar(12) DEFAULT NULL COMMENT 'dbNSFP4 gnomAD allele frequency',
  `Interpro` text DEFAULT NULL COMMENT 'dbNSFP4 InterPro domain',
  `phastCons100` varchar(10) DEFAULT NULL COMMENT 'dbNSFP4 PHAST conservation (100 species)',
  `phyloP100` varchar(15) DEFAULT NULL COMMENT 'dbNSFP4 phylogenetic p-values (100 species)',
  `phastCons470` varchar(10) DEFAULT NULL COMMENT 'dbNSFP4 PHAST conservation (470 species)',
  `phyloP470` varchar(15) DEFAULT NULL COMMENT 'dbNSFP4 phylogenetic p-values (470 species)',
  `GERP_RS` varchar(15) DEFAULT NULL COMMENT 'dbNSFP4 GERP conservation score',
  PRIMARY KEY (`id`),
  KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbnsfp4`
--

LOCK TABLES `dbnsfp4` WRITE;
/*!40000 ALTER TABLE `dbnsfp4` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbnsfp4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbsnp`
--

DROP TABLE IF EXISTS `dbsnp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbsnp` (
  `hgmd_acc` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number (from core mutation tables)',
  `dbsnp_id` varchar(12) DEFAULT NULL COMMENT 'NCBI dbSNP variant identifier',
  `het` decimal(2,2) DEFAULT NULL COMMENT 'dbSNP average het',
  `MAFsource` varchar(25) DEFAULT NULL COMMENT 'dbSNP minor allele frequency source',
  `MAFfreq` varchar(25) DEFAULT NULL COMMENT 'dbSNP minor allele frequency',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comment',
  PRIMARY KEY (`hgmd_acc`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbsnp`
--

LOCK TABLES `dbsnp` WRITE;
/*!40000 ALTER TABLE `dbsnp` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbsnp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deletion`
--

DROP TABLE IF EXISTS `deletion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deletion` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `deletion` varchar(65) NOT NULL DEFAULT '' COMMENT 'Deleted nucleotides (lowercase) with 10bp flanking sequence',
  `codon` int(11) NOT NULL DEFAULT 0 COMMENT 'Codon number denoted by caret (^) symbol',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`gene`,`deletion`,`codon`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deletion`
--

LOCK TABLES `deletion` WRITE;
/*!40000 ALTER TABLE `deletion` DISABLE KEYS */;
/*!40000 ALTER TABLE `deletion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delins`
--

DROP TABLE IF EXISTS `delins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delins` (
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `delins` varchar(65) DEFAULT NULL COMMENT 'HGMD Deletion/insertion/indel sequence data (from core table) ',
  `deleted` varchar(20) DEFAULT NULL COMMENT 'Deleted nucleotides',
  `inserted` varchar(20) DEFAULT NULL COMMENT 'Inserted nucleotides',
  `del_length` int(2) DEFAULT NULL COMMENT 'Length of deletion',
  `ins_length` int(2) DEFAULT NULL COMMENT 'Length of insertion',
  `base` char(1) DEFAULT NULL COMMENT 'Source core table (DELETION, INSERTION or INDEL)',
  PRIMARY KEY (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delins`
--

LOCK TABLES `delins` WRITE;
/*!40000 ALTER TABLE `delins` DISABLE KEYS */;
/*!40000 ALTER TABLE `delins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extrarefs`
--

DROP TABLE IF EXISTS `extrarefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extrarefs` (
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `disease` varchar(125) NOT NULL DEFAULT '' COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) DEFAULT NULL COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `author` varchar(50) NOT NULL DEFAULT '' COMMENT 'First author of cited reference',
  `title` text DEFAULT NULL COMMENT 'Title of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) NOT NULL DEFAULT '' COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `allname` varchar(200) DEFAULT NULL,
  `vol` varchar(15) NOT NULL DEFAULT '' COMMENT 'Volume of cited reference',
  `issue` varchar(6) DEFAULT NULL,
  `page` varchar(25) NOT NULL DEFAULT '' COMMENT 'First page of cited reference',
  `year` char(4) NOT NULL DEFAULT '',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `support` enum('1','0','-1') DEFAULT NULL COMMENT 'Support for or against deleterious nature of variant in cited reference',
  `reftag` char(4) NOT NULL DEFAULT '' COMMENT 'Codes for type of additional reference',
  PRIMARY KEY (`acc_num`,`author`,`fullname`,`vol`,`page`,`year`,`reftag`,`disease`),
  KEY `acc_num` (`acc_num`),
  KEY `gene` (`gene`,`disease`),
  FULLTEXT KEY `REFFIELDS` (`gene`,`author`,`fullname`,`allname`,`year`,`pmid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extrarefs`
--

LOCK TABLES `extrarefs` WRITE;
/*!40000 ALTER TABLE `extrarefs` DISABLE KEYS */;
/*!40000 ALTER TABLE `extrarefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `id` int(10) unsigned NOT NULL COMMENT 'Internal HGMD ID',
  `question` text DEFAULT NULL COMMENT 'FAQ question',
  `answer` text DEFAULT NULL COMMENT 'FAQ answer',
  `owner` varchar(25) DEFAULT NULL COMMENT 'HGMD owner',
  `type` varchar(25) DEFAULT NULL COMMENT 'Is question regarding online or download version',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `func_anotat`
--

DROP TABLE IF EXISTS `func_anotat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `func_anotat` (
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `site_id` int(11) NOT NULL DEFAULT 0 COMMENT 'Internal code for functional site (from FUNC_SITES table)',
  `pmid` int(11) NOT NULL DEFAULT 0 COMMENT 'Pubmed ID of reference for functional relationship',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `direction` char(1) DEFAULT NULL COMMENT 'Loss/Gain of functional site',
  `wildtype` varchar(20) DEFAULT NULL COMMENT 'Wildtype nucleotides',
  `mutant` varchar(20) DEFAULT NULL COMMENT 'Mutated nucleotides',
  PRIMARY KEY (`acc_num`,`site_id`,`pmid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `func_anotat`
--

LOCK TABLES `func_anotat` WRITE;
/*!40000 ALTER TABLE `func_anotat` DISABLE KEYS */;
/*!40000 ALTER TABLE `func_anotat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `func_sites`
--

DROP TABLE IF EXISTS `func_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `func_sites` (
  `id` int(11) NOT NULL COMMENT 'Internal HGMD identifier',
  `abr` varchar(20) DEFAULT NULL COMMENT 'Abbreviation for name',
  `name` varchar(200) NOT NULL COMMENT 'Name of functional site',
  `type` varchar(60) DEFAULT NULL COMMENT 'Type of functional site',
  `comments` varchar(250) DEFAULT NULL COMMENT 'HGMD curator comments',
  PRIMARY KEY (`id`),
  KEY `new_index` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `func_sites`
--

LOCK TABLES `func_sites` WRITE;
/*!40000 ALTER TABLE `func_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `func_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gene2refseq`
--

DROP TABLE IF EXISTS `gene2refseq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gene2refseq` (
  `hgmdID` int(11) NOT NULL DEFAULT 0 COMMENT 'HGMD gene identifier (from MARKNAME table)',
  `refcore` varchar(15) DEFAULT NULL COMMENT 'NCBI RefSeq nucleotide sequence identifier',
  `refversion` varchar(2) DEFAULT NULL COMMENT 'NCBI RefSeq nucleotide sequence version',
  `offset` int(11) DEFAULT NULL COMMENT 'Legacy offset to codon numbering',
  `first` char(1) DEFAULT NULL COMMENT 'Internal HGMD field',
  `chrom` varchar(10) DEFAULT NULL COMMENT 'Chromosome from NCBI annotation',
  `strand` char(1) DEFAULT NULL COMMENT 'Strand orientation from NCBI annotation',
  `startTIS` int(10) unsigned DEFAULT NULL COMMENT 'Transcript start position from NCBI annotation',
  `endTIS` int(10) unsigned DEFAULT NULL COMMENT 'Transcript end position from NCBI annotation',
  `startCDS` int(10) unsigned DEFAULT NULL COMMENT 'Coding sequence start position from NCBI annotation',
  `endCDS` int(10) unsigned DEFAULT NULL COMMENT 'Coding sequence end position from NCBI annotation',
  `exonCOUNT` int(10) unsigned DEFAULT NULL COMMENT 'Number of exons on NCBI annotation',
  `exonSTARTS` longtext DEFAULT NULL COMMENT 'Exon start positions from NCBI annotation',
  `exonENDS` longtext DEFAULT NULL COMMENT 'Exon end positions from NCBI annotation',
  PRIMARY KEY (`hgmdID`),
  UNIQUE KEY `refcore` (`refcore`,`refversion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gene2refseq`
--

LOCK TABLES `gene2refseq` WRITE;
/*!40000 ALTER TABLE `gene2refseq` DISABLE KEYS */;
/*!40000 ALTER TABLE `gene2refseq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gene_concept_scores`
--

DROP TABLE IF EXISTS `gene_concept_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gene_concept_scores` (
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `concept` varchar(50) NOT NULL DEFAULT '' COMMENT 'UMLS concept (from hgmd_phenbase.concept)',
  `num_matching` int(11) DEFAULT NULL COMMENT 'Number of HGMD entries matching',
  `total` int(11) DEFAULT NULL COMMENT 'Total possible',
  `percentage` double DEFAULT NULL COMMENT 'Number of matching entries as percentage',
  PRIMARY KEY (`gene`,`concept`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gene_concept_scores`
--

LOCK TABLES `gene_concept_scores` WRITE;
/*!40000 ALTER TABLE `gene_concept_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `gene_concept_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genefam`
--

DROP TABLE IF EXISTS `genefam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genefam` (
  `url` varchar(100) DEFAULT NULL COMMENT 'URL link for genefamily at HGNC',
  `gene_family_id` varchar(25) NOT NULL DEFAULT '' COMMENT 'HGNC gene family ID',
  `genefamily` varchar(150) DEFAULT NULL COMMENT 'HGNC gene family/group',
  `symbol` varchar(25) DEFAULT NULL COMMENT 'HGNC gene symbol',
  `hgncID` int(11) NOT NULL DEFAULT 0 COMMENT 'HGNC identifier',
  PRIMARY KEY (`gene_family_id`,`hgncID`),
  KEY `symbol` (`symbol`),
  KEY `hgncID` (`hgncID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genefam`
--

LOCK TABLES `genefam` WRITE;
/*!40000 ALTER TABLE `genefam` DISABLE KEYS */;
/*!40000 ALTER TABLE `genefam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goterms`
--

DROP TABLE IF EXISTS `goterms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goterms` (
  `gene_id` int(11) NOT NULL DEFAULT 0 COMMENT 'HGMD gene identifier (from MARKNAME table)',
  `hgmdsym` varchar(15) DEFAULT NULL COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `go_term_name` varchar(255) DEFAULT NULL COMMENT 'GO term name from Gene Ontology database',
  `go_term_type` varchar(55) DEFAULT NULL COMMENT 'GO term type from Gene Ontology database',
  `go_term_acc` varchar(100) NOT NULL DEFAULT '' COMMENT 'GO term accession from Gene Ontology database',
  `go_term_evid` varchar(11) NOT NULL DEFAULT '' COMMENT 'GO term evidence code from Gene Ontology database',
  PRIMARY KEY (`gene_id`,`go_term_acc`,`go_term_evid`),
  FULLTEXT KEY `GOFIELDS` (`hgmdsym`,`go_term_name`,`go_term_type`,`go_term_acc`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goterms`
--

LOCK TABLES `goterms` WRITE;
/*!40000 ALTER TABLE `goterms` DISABLE KEYS */;
/*!40000 ALTER TABLE `goterms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grosdel`
--

DROP TABLE IF EXISTS `grosdel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grosdel` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) DEFAULT NULL COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `descr` varchar(75) DEFAULT NULL COMMENT 'Narrative description of variant',
  `cdna` char(1) DEFAULT NULL COMMENT 'Reported at genomic (g) or cDNA (c) level',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`acc_num`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grosdel`
--

LOCK TABLES `grosdel` WRITE;
/*!40000 ALTER TABLE `grosdel` DISABLE KEYS */;
/*!40000 ALTER TABLE `grosdel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grosins`
--

DROP TABLE IF EXISTS `grosins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grosins` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) DEFAULT NULL COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `type` char(1) DEFAULT NULL COMMENT 'Insertion (I) or duplication (D)',
  `descr` varchar(75) DEFAULT NULL COMMENT 'Narrative description of variant',
  `cdna` char(1) DEFAULT NULL COMMENT 'Reported at genomic (g) or cDNA (c) level',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`acc_num`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grosins`
--

LOCK TABLES `grosins` WRITE;
/*!40000 ALTER TABLE `grosins` DISABLE KEYS */;
/*!40000 ALTER TABLE `grosins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg19_coords`
--

DROP TABLE IF EXISTS `hg19_coords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hg19_coords` (
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `chromosome` varchar(2) DEFAULT NULL COMMENT 'hg19 chromosome number',
  `strand` char(1) DEFAULT NULL COMMENT 'hg19 strand orientation',
  `coordSTART` int(11) DEFAULT NULL COMMENT 'First nucleotide position of mutation',
  `coordEND` int(11) DEFAULT NULL COMMENT 'hg19 final nucleotide position of mutation',
  `upstreamFLANK` varchar(30) DEFAULT NULL COMMENT '30bp upstream flanking sequence (coding strand)',
  `downstreamFLANK` varchar(30) DEFAULT NULL COMMENT '30bp downstream flanking sequence (coding strand)',
  PRIMARY KEY (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg19_coords`
--

LOCK TABLES `hg19_coords` WRITE;
/*!40000 ALTER TABLE `hg19_coords` DISABLE KEYS */;
/*!40000 ALTER TABLE `hg19_coords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hg38_coords`
--

DROP TABLE IF EXISTS `hg38_coords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hg38_coords` (
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `chromosome` varchar(2) DEFAULT NULL COMMENT 'hg38 chromosome number',
  `strand` char(1) DEFAULT NULL COMMENT 'hg38 strand orientation',
  `coordSTART` int(11) DEFAULT NULL COMMENT 'First nucleotide position of mutation',
  `coordEND` int(11) DEFAULT NULL COMMENT 'Final nucleotide position of mutation',
  `upstreamFLANK` varchar(30) DEFAULT NULL COMMENT '30bp upstream flanking sequence (coding strand)',
  `downstreamFLANK` varchar(30) DEFAULT NULL COMMENT '30bp downstream flanking sequence (coding strand)',
  PRIMARY KEY (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hg38_coords`
--

LOCK TABLES `hg38_coords` WRITE;
/*!40000 ALTER TABLE `hg38_coords` DISABLE KEYS */;
/*!40000 ALTER TABLE `hg38_coords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hgmd_hg19_vcf`
--

DROP TABLE IF EXISTS `hgmd_hg19_vcf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hgmd_hg19_vcf` (
  `chrom` varchar(2) NOT NULL DEFAULT '' COMMENT 'hg19 chromosome number VCF compliant',
  `pos` int(11) NOT NULL DEFAULT 0 COMMENT 'hg19 chromosomal position VCF compliant',
  `id` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD identifier',
  `ref` varchar(255) DEFAULT NULL COMMENT 'hg19 reference nucleotide(s) VCF compliant',
  `alt` varchar(255) DEFAULT NULL COMMENT 'hg19 alt nucleotide(s) VCF compliant',
  `qual` char(1) DEFAULT NULL COMMENT 'Qual value VCF compliant',
  `filter` char(1) DEFAULT NULL COMMENT 'Filter value VCF compliant',
  `info` varchar(255) DEFAULT NULL COMMENT 'Info field VCF compliant',
  PRIMARY KEY (`chrom`,`pos`,`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hgmd_hg19_vcf`
--

LOCK TABLES `hgmd_hg19_vcf` WRITE;
/*!40000 ALTER TABLE `hgmd_hg19_vcf` DISABLE KEYS */;
/*!40000 ALTER TABLE `hgmd_hg19_vcf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hgmd_hg38_vcf`
--

DROP TABLE IF EXISTS `hgmd_hg38_vcf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hgmd_hg38_vcf` (
  `chrom` varchar(2) NOT NULL DEFAULT '' COMMENT 'hg38 chromosome number VCF compliant',
  `pos` int(11) NOT NULL DEFAULT 0 COMMENT 'hg38 position VCF compliant',
  `id` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD identifier',
  `ref` varchar(255) DEFAULT NULL COMMENT 'hg38 reference nucleotide(s) VCF compliant',
  `alt` varchar(255) DEFAULT NULL COMMENT 'hg38 alt nucleotide(s) VCF compliant',
  `qual` char(1) DEFAULT NULL COMMENT 'Qual value VCF compliant',
  `filter` char(1) DEFAULT NULL COMMENT 'Filert value VCF compliant',
  `info` varchar(255) DEFAULT NULL COMMENT 'Info field VCF compliant',
  PRIMARY KEY (`chrom`,`pos`,`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hgmd_hg38_vcf`
--

LOCK TABLES `hgmd_hg38_vcf` WRITE;
/*!40000 ALTER TABLE `hgmd_hg38_vcf` DISABLE KEYS */;
/*!40000 ALTER TABLE `hgmd_hg38_vcf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `high_level_concept`
--

DROP TABLE IF EXISTS `high_level_concept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `high_level_concept` (
  `concept` varchar(50) NOT NULL DEFAULT '' COMMENT 'UMLS concept (from hgmd_phenbase.concept)',
  `cui` char(10) NOT NULL DEFAULT '' COMMENT 'UMLS identifier (from hgmd_phenbase.concept)',
  PRIMARY KEY (`concept`,`cui`),
  KEY `concept` (`concept`),
  KEY `cui` (`cui`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `high_level_concept`
--

LOCK TABLES `high_level_concept` WRITE;
/*!40000 ALTER TABLE `high_level_concept` DISABLE KEYS */;
/*!40000 ALTER TABLE `high_level_concept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `histID` int(11) NOT NULL DEFAULT 0 COMMENT 'Internal HGMD identifier',
  `acc_num` varchar(10) DEFAULT NULL COMMENT 'HGMD mutation accession number',
  `tname` varchar(25) DEFAULT NULL COMMENT 'HGMD table name',
  `colname` varchar(25) DEFAULT NULL COMMENT 'HGMD field name (relates to table in TNAME column)',
  `beforeUpd` text DEFAULT NULL COMMENT 'Field data point before update',
  `afterUpd` text DEFAULT NULL COMMENT 'Field data point after update',
  `updDate` date DEFAULT NULL COMMENT 'Date of update',
  PRIMARY KEY (`histID`),
  KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indel`
--

DROP TABLE IF EXISTS `indel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indel` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `wildtype` varchar(65) NOT NULL DEFAULT '' COMMENT 'Deleted nucleotides (lowercase) with 10bp flanking sequence',
  `insertion` varchar(25) NOT NULL DEFAULT '' COMMENT 'Inserted nucleotides',
  `codon` int(11) NOT NULL DEFAULT 0 COMMENT 'Codon number denoted by caret (^) symbol',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`gene`,`wildtype`,`insertion`,`codon`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indel`
--

LOCK TABLES `indel` WRITE;
/*!40000 ALTER TABLE `indel` DISABLE KEYS */;
/*!40000 ALTER TABLE `indel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insertion`
--

DROP TABLE IF EXISTS `insertion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insertion` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `insertion` varchar(65) NOT NULL DEFAULT '' COMMENT 'Inserted nucleotides (lowercase) with 10bp flanking sequence',
  `codon` int(11) NOT NULL DEFAULT 0 COMMENT 'Codon number denoted by caret (^) symbol',
  `nucleotide` varchar(10) NOT NULL DEFAULT '' COMMENT 'Reported nucleotide position (legacy not HGVS compliant)',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`gene`,`insertion`,`codon`,`nucleotide`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insertion`
--

LOCK TABLES `insertion` WRITE;
/*!40000 ALTER TABLE `insertion` DISABLE KEYS */;
/*!40000 ALTER TABLE `insertion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal`
--

DROP TABLE IF EXISTS `journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal` (
  `journal` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD journal or LSDB abbreviation',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation',
  `allname` varchar(200) DEFAULT NULL COMMENT 'Complete journal title',
  `url` varchar(125) DEFAULT NULL COMMENT 'URL of journal or locus-specific database',
  PRIMARY KEY (`journal`),
  KEY `fullname` (`fullname`),
  KEY `allname` (`allname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal`
--

LOCK TABLES `journal` WRITE;
/*!40000 ALTER TABLE `journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `xorder` varchar(1) DEFAULT NULL COMMENT 'Internal ordering flag',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `url` varchar(150) NOT NULL DEFAULT '' COMMENT 'URL for generated link',
  PRIMARY KEY (`gene`,`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `markname`
--

DROP TABLE IF EXISTS `markname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `markname` (
  `gene_id` int(11) NOT NULL DEFAULT 0 COMMENT 'Internal HGMD gene identifier',
  `genesym` varchar(15) DEFAULT NULL COMMENT 'HGMD gene symbol based on HGNC',
  `chrom` varchar(25) DEFAULT NULL COMMENT 'Chromosomal location',
  `genename` varchar(200) DEFAULT NULL COMMENT 'HGMD gene name based on HGNC',
  `gdbid` varchar(8) DEFAULT NULL COMMENT 'Genome DataBase identifier now redundant',
  `omimid` varchar(8) DEFAULT NULL COMMENT 'OMIM identifier',
  `entrezID` int(11) DEFAULT NULL COMMENT 'Entrez Gene identifier',
  `unigeneID` int(11) DEFAULT NULL COMMENT 'Unigene identifier',
  `hgncID` int(11) DEFAULT NULL COMMENT 'HUGO Gene Nomenclature Committee identifier',
  `hprdID` smallint(5) unsigned zerofill DEFAULT NULL COMMENT 'Human Protein Reference Database identifier',
  `swiss_acc` varchar(15) DEFAULT NULL COMMENT 'SwissProt sequence identifier',
  `gene_date` date DEFAULT NULL COMMENT 'Date the gene was entered into HGMD',
  `expected_inheritance` varchar(5) DEFAULT NULL COMMENT 'Inheritance pattern expected for the predominant phenotype(s) associated with a defect in the related gene',
  `svar` int(11) DEFAULT NULL COMMENT 'HGMD gene_id of the main gene entry for alternate isoform',
  `gadb` char(1) DEFAULT NULL COMMENT 'NIH Genetic Association Database entry flag. Now retired.',
  `findbase` char(1) DEFAULT NULL COMMENT 'Findbase entry flag',
  `cosmic` char(1) DEFAULT NULL COMMENT 'COSMIC entry flag',
  `atlas` char(1) DEFAULT NULL COMMENT 'GenAtlas entry flag',
  `instruct` char(1) DEFAULT NULL COMMENT 'INstruct 3D protein interactome flag',
  `mupit` char(1) DEFAULT NULL COMMENT 'muPIT interactive flag (3D protein structures)',
  `acmg` char(1) DEFAULT NULL COMMENT 'ACMG reportable gene flag',
  PRIMARY KEY (`gene_id`),
  UNIQUE KEY `entrezID` (`entrezID`),
  UNIQUE KEY `unigeneID` (`unigeneID`),
  UNIQUE KEY `hgncID` (`hgncID`),
  UNIQUE KEY `hprdID` (`hprdID`),
  UNIQUE KEY `genesym` (`genesym`),
  KEY `svar` (`svar`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `markname`
--

LOCK TABLES `markname` WRITE;
/*!40000 ALTER TABLE `markname` DISABLE KEYS */;
/*!40000 ALTER TABLE `markname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mutation`
--

DROP TABLE IF EXISTS `mutation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mutation` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `base` varchar(9) NOT NULL DEFAULT '' COMMENT 'Codon triplet change',
  `amino` varchar(8) DEFAULT NULL COMMENT 'Amino acid change',
  `codon` int(11) NOT NULL DEFAULT 0 COMMENT 'Codon number',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`gene`,`codon`,`base`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mutation`
--

LOCK TABLES `mutation` WRITE;
/*!40000 ALTER TABLE `mutation` DISABLE KEYS */;
/*!40000 ALTER TABLE `mutation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mutnomen`
--

DROP TABLE IF EXISTS `mutnomen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mutnomen` (
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `refCORE` varchar(14) DEFAULT NULL COMMENT 'NCBI RefSeq nucleotide sequence identifier',
  `refVER` varchar(2) DEFAULT NULL COMMENT 'NCBI RefSeq nucleotide sequence version',
  `cSTART` varchar(11) DEFAULT NULL COMMENT 'First nucleotide position according to HGVS nomenclature',
  `ivsSTART` int(11) DEFAULT NULL COMMENT 'First nucleotide position relative to cSTART if mutation is intronic',
  `cEND` varchar(11) DEFAULT NULL COMMENT 'Last nucleotide position according to HGVS nomenclature',
  `ivsEND` int(11) DEFAULT NULL COMMENT 'Last nucleotide position relative to cEND if mutation is intronic',
  `wildBASE` varchar(255) DEFAULT NULL COMMENT 'Widtype nucleotide at given position',
  `mutBASE` varchar(255) DEFAULT NULL COMMENT 'Mutated nucleotide at given position',
  `protCORE` varchar(14) DEFAULT NULL COMMENT 'NCBI RefSeq protein sequence identifier',
  `protVER` varchar(2) DEFAULT NULL COMMENT 'NCBI RefSeq protein sequence version',
  `wildAMINO` char(1) DEFAULT NULL COMMENT 'Wildtype amino acid at given codon position',
  `mutAMINO` char(1) DEFAULT NULL COMMENT 'Mutated amino acid at given codon position',
  `codon` int(11) DEFAULT NULL COMMENT 'Codon number',
  `hgvs` varchar(60) DEFAULT NULL COMMENT 'HGVS compliant c-dot nomenclature',
  `hgvsPROT` varchar(60) DEFAULT NULL COMMENT 'HGVS compliant p-dot nomenclature',
  `hgvsall` varchar(120) DEFAULT NULL COMMENT 'Composite c-dot and p-dot nomenclature (for search indexing)',
  PRIMARY KEY (`acc_num`),
  FULLTEXT KEY `HGVSALL` (`hgvsall`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mutnomen`
--

LOCK TABLES `mutnomen` WRITE;
/*!40000 ALTER TABLE `mutnomen` DISABLE KEYS */;
/*!40000 ALTER TABLE `mutnomen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prom`
--

DROP TABLE IF EXISTS `prom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prom` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `base` varchar(65) NOT NULL DEFAULT '' COMMENT 'Reported nucleotide change with 30bp flanking sedquence',
  `location` int(11) NOT NULL DEFAULT 0 COMMENT 'Location relative to locref',
  `locref` varchar(5) DEFAULT NULL COMMENT 'Point of reference for location (MET, TIS, TERM)',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`gene`,`base`,`location`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prom`
--

LOCK TABLES `prom` WRITE;
/*!40000 ALTER TABLE `prom` DISABLE KEYS */;
/*!40000 ALTER TABLE `prom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refseqgene`
--

DROP TABLE IF EXISTS `refseqgene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refseqgene` (
  `entrez_id` int(11) NOT NULL DEFAULT 0 COMMENT 'Entrez Gene identifier',
  `ngseq` varchar(50) NOT NULL DEFAULT '' COMMENT 'NCBI RefSeqGene project sequence identifier',
  PRIMARY KEY (`entrez_id`,`ngseq`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refseqgene`
--

LOCK TABLES `refseqgene` WRITE;
/*!40000 ALTER TABLE `refseqgene` DISABLE KEYS */;
/*!40000 ALTER TABLE `refseqgene` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec`
--

DROP TABLE IF EXISTS `sec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec` (
  `code3` char(4) NOT NULL DEFAULT '' COMMENT 'Triplet amino acid abbreviation',
  `helix` int(11) DEFAULT NULL COMMENT 'Chou-Fasman P(a) alpha helix',
  `sheet` int(11) DEFAULT NULL COMMENT 'Chou-Fasman P(b) beta sheet',
  `turn` int(11) DEFAULT NULL COMMENT 'Chou-Fasman P(turn)',
  `helixD` char(1) DEFAULT NULL COMMENT 'Alpha helix secondary strucure propensity',
  `sheetD` char(1) DEFAULT NULL COMMENT 'Beta sheet secondary strucure propensity',
  `p1` decimal(4,3) DEFAULT NULL COMMENT 'Unused',
  `p2` decimal(4,3) DEFAULT NULL COMMENT 'Unused',
  `p3` decimal(4,3) DEFAULT NULL COMMENT 'Unused',
  `p4` decimal(4,3) DEFAULT NULL COMMENT 'Unused',
  PRIMARY KEY (`code3`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec`
--

LOCK TABLES `sec` WRITE;
/*!40000 ALTER TABLE `sec` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequence_ontology`
--

DROP TABLE IF EXISTS `sequence_ontology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequence_ontology` (
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `refseqCdots` text DEFAULT NULL COMMENT 'Concatenated HGVS nomenclature for indexing',
  `refseqPdots` text DEFAULT NULL COMMENT 'Concatenated protein HGVS nomenclature for indexing',
  `hgvsRefWithTranscript` text DEFAULT NULL COMMENT 'Concatenated HGVS nomenclature for display',
  `ensemblCdots` text DEFAULT NULL COMMENT 'Concatenated HGVS nomenclature for indexing',
  `ensemblPdots` text DEFAULT NULL COMMENT 'Concatenated HGVS protein nomenclature for indexing',
  `hgvsEnsemblWithTranscript` text DEFAULT NULL COMMENT 'Concatenated HGVS nomenclature for display',
  `SeqOntologyId` text DEFAULT NULL COMMENT 'Sequence ontology identifiers',
  `SeqOntologyTerm` text DEFAULT NULL COMMENT 'Sequence ontology terms',
  PRIMARY KEY (`acc_num`),
  FULLTEXT KEY `seqontology` (`refseqCdots`,`refseqPdots`,`hgvsRefWithTranscript`,`SeqOntologyId`,`SeqOntologyTerm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequence_ontology`
--

LOCK TABLES `sequence_ontology` WRITE;
/*!40000 ALTER TABLE `sequence_ontology` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequence_ontology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `splice`
--

DROP TABLE IF EXISTS `splice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `splice` (
  `disease` varchar(250) DEFAULT NULL COMMENT 'HGMD phenotype as reported in cited reference',
  `gene` varchar(15) NOT NULL DEFAULT '' COMMENT 'HGMD gene symbol (from MARKNAME table)',
  `ivs` varchar(4) NOT NULL DEFAULT '' COMMENT 'Reported intron (IVS) number',
  `type` char(2) NOT NULL DEFAULT '' COMMENT 'Donor (ds) or acceptor (as) site',
  `base` char(3) NOT NULL DEFAULT '' COMMENT 'Reported nucleotide change',
  `location` int(11) NOT NULL DEFAULT 0 COMMENT 'Location relative to donor or acceptor site',
  `tag` enum('DP','FP','DFP','DM','DM?','FTV','R') DEFAULT NULL COMMENT 'HGMD variant class',
  `author` varchar(50) DEFAULT NULL COMMENT 'First author of cited reference',
  `journal` varchar(10) DEFAULT NULL COMMENT 'HGMD journal or LSDB abbreviation (from JOURNAL table)',
  `fullname` varchar(55) DEFAULT NULL COMMENT 'NLM journal title abbreviation (from JOURNAL table)',
  `vol` varchar(15) DEFAULT NULL COMMENT 'Volume of cited reference',
  `page` varchar(25) DEFAULT NULL COMMENT 'First page of cited reference',
  `year` year(4) DEFAULT NULL COMMENT 'Publication year of cited reference',
  `pmid` varchar(8) DEFAULT NULL COMMENT 'Pubmed ID of cited reference',
  `comments` text DEFAULT NULL COMMENT 'HGMD curator comments',
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `new_date` date DEFAULT NULL COMMENT 'Date entered into HGMD',
  PRIMARY KEY (`gene`,`ivs`,`type`,`base`,`location`),
  UNIQUE KEY `acc_num` (`acc_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `splice`
--

LOCK TABLES `splice` WRITE;
/*!40000 ALTER TABLE `splice` DISABLE KEYS */;
/*!40000 ALTER TABLE `splice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storeAlign`
--

DROP TABLE IF EXISTS `storeAlign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storeAlign` (
  `acc_num` varchar(10) NOT NULL DEFAULT '' COMMENT 'HGMD mutation accession number',
  `codon` int(11) DEFAULT NULL COMMENT 'HGMD codon position',
  `taxonomy` int(11) DEFAULT NULL COMMENT 'Taxonomy ID from NCBI Taxonomy database',
  `species` varchar(250) DEFAULT NULL COMMENT 'Latin (Linnean) species name',
  `sp_name` varchar(250) DEFAULT NULL COMMENT 'Species name (English)',
  `prot_acc` varchar(25) NOT NULL DEFAULT '' COMMENT 'NCBI RefSeq protein sequence identifier',
  `prot_ver` varchar(2) DEFAULT NULL COMMENT 'NCBI RefSeq protein sequence version',
  `first10` int(11) DEFAULT NULL COMMENT 'Start codon of first 10 flanking amino acids',
  `upstreamOrth` varchar(25) DEFAULT NULL COMMENT 'Upstream flanking amino acids',
  `mutOrth` char(1) DEFAULT NULL COMMENT 'Orthologous amino acid at mutated position',
  `downstreamOrth` varchar(25) DEFAULT NULL COMMENT 'Downstream flanking amino acids',
  `final10` int(11) DEFAULT NULL COMMENT 'End codon of last 10 flanking amino acids',
  `sim_percent` int(11) DEFAULT NULL COMMENT 'Percentage match',
  `Qmethod` varchar(50) DEFAULT NULL COMMENT 'Internal HGMD method',
  `highscore` int(11) DEFAULT NULL COMMENT 'Highest score matching position',
  `highpos` int(11) DEFAULT NULL COMMENT 'Highest scoring position',
  PRIMARY KEY (`acc_num`,`prot_acc`),
  KEY `species` (`species`),
  KEY `sp_name` (`sp_name`),
  KEY `taxonomy` (`taxonomy`),
  KEY `sim_percent` (`sim_percent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storeAlign`
--

LOCK TABLES `storeAlign` WRITE;
/*!40000 ALTER TABLE `storeAlign` DISABLE KEYS */;
/*!40000 ALTER TABLE `storeAlign` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-14  3:08:02
