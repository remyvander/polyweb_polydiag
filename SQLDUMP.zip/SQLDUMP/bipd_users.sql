-- MariaDB dump 10.18  Distrib 10.5.8-MariaDB, for Linux (x86_64)
--
-- Host: 10.200.27.108    Database: bipd_users
-- ------------------------------------------------------
-- Server version	10.5.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ALAMUT_LICENCE`
--

DROP TABLE IF EXISTS `ALAMUT_LICENCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ALAMUT_LICENCE` (
  `ALAMUT_ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(45) NOT NULL,
  `API_KEY` varchar(45) DEFAULT NULL,
  `INSTITUTION_KEY` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ALAMUT_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EQUIPE`
--

DROP TABLE IF EXISTS `EQUIPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EQUIPE` (
  `EQUIPE_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LIBELLE` varchar(200) DEFAULT NULL,
  `RESPONSABLES` varchar(100) DEFAULT NULL,
  `UNITE_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`EQUIPE_ID`),
  KEY `index2` (`UNITE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EQUIPE_ALAMUT_LICENCE`
--

DROP TABLE IF EXISTS `EQUIPE_ALAMUT_LICENCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EQUIPE_ALAMUT_LICENCE` (
  `EQUIPE_ID` int(10) NOT NULL,
  `ALAMUT_ID` int(10) NOT NULL,
  PRIMARY KEY (`EQUIPE_ID`,`ALAMUT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UGROUP`
--

DROP TABLE IF EXISTS `UGROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UGROUP` (
  `UGROUP_ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`UGROUP_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UGROUP_USER`
--

DROP TABLE IF EXISTS `UGROUP_USER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UGROUP_USER` (
  `UGROUP_ID` int(10) NOT NULL,
  `USER_ID` int(10) NOT NULL,
  PRIMARY KEY (`UGROUP_ID`,`USER_ID`),
  KEY `fk_UGROUP_USER_2_idx` (`USER_ID`),
  CONSTRAINT `fk_UGROUP_USER_1` FOREIGN KEY (`UGROUP_ID`) REFERENCES `UGROUP` (`UGROUP_ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_UGROUP_USER_2` FOREIGN KEY (`USER_ID`) REFERENCES `USER` (`USER_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UNITE`
--

DROP TABLE IF EXISTS `UNITE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UNITE` (
  `UNITE_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CODE_UNITE` varchar(45) NOT NULL,
  `ORGANISME` varchar(45) DEFAULT NULL,
  `SITE` varchar(45) DEFAULT NULL,
  `DIRECTEUR` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`UNITE_ID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=latin1 PACK_KEYS=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `USER`
--

DROP TABLE IF EXISTS `USER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER` (
  `USER_ID` int(10) NOT NULL AUTO_INCREMENT,
  `NOM_RESPONSABLE` varchar(45) NOT NULL,
  `PRENOM_U` varchar(45) DEFAULT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LOGIN` varchar(45) NOT NULL,
  `PASSWORD_TXT` varchar(200) DEFAULT NULL,
  `EQUIPE_ID` int(10) unsigned DEFAULT NULL,
  `PW` varchar(45) DEFAULT NULL,
  `hgmd` tinyint(1) DEFAULT 1,
  `PW_DATE` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `Key` varchar(30) DEFAULT NULL,
  `uKey` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `Login` (`LOGIN`) USING BTREE,
  UNIQUE KEY `prenom_nom` (`NOM_RESPONSABLE`,`PRENOM_U`),
  KEY `equipe` (`EQUIPE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=864 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `USER2`
--

DROP TABLE IF EXISTS `USER2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER2` (
  `USER_ID` int(10) unsigned NOT NULL,
  `NOM_RESPONSABLE` varchar(45) NOT NULL,
  `PRENOM_U` varchar(45) DEFAULT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `CREATION_DATE` datetime /* mariadb-5.3 */ NOT NULL,
  `LOGIN` varchar(45) NOT NULL,
  `PASSWORD_TXT` varchar(200) NOT NULL,
  `EQUIPE_ID` int(10) unsigned DEFAULT NULL,
  `PW` varchar(45) NOT NULL,
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `prenom_nom` (`NOM_RESPONSABLE`,`PRENOM_U`),
  KEY `Login` (`LOGIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 15:11:42
