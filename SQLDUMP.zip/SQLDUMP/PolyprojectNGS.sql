/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 129.85.163.136    Database: PolyprojectNGS
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analyse`
--

DROP TABLE IF EXISTS `analyse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analyse` (
  `analyse_id` int(2) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`analyse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analyse`
--

LOCK TABLES `analyse` WRITE;
/*!40000 ALTER TABLE `analyse` DISABLE KEYS */;
INSERT INTO `analyse` VALUES (1,'exome'),(2,'genome'),(3,'target'),(4,'rnaseq'),(5,'singlecell');
/*!40000 ALTER TABLE `analyse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle`
--

DROP TABLE IF EXISTS `bundle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle` (
  `bundle_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `description` varchar(150) DEFAULT NULL,
  `mesh_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`bundle_id`),
  UNIQUE KEY `index_2` (`name`,`version`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1284 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle`
--

LOCK TABLES `bundle` WRITE;
/*!40000 ALTER TABLE `bundle` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundleLike`
--

DROP TABLE IF EXISTS `bundleLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundleLike` (
  `bundle_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  `version` int(11) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `description` varchar(150) DEFAULT NULL,
  `mesh_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`bundle_id`),
  UNIQUE KEY `index_2` (`name`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundleLike`
--

LOCK TABLES `bundleLike` WRITE;
/*!40000 ALTER TABLE `bundleLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundleLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_panel`
--

DROP TABLE IF EXISTS `bundle_panel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_panel` (
  `bundle_id` int(11) NOT NULL,
  `panel_id` int(11) NOT NULL,
  PRIMARY KEY (`bundle_id`,`panel_id`),
  KEY `fk_bundle_panel_1` (`bundle_id`),
  KEY `fk_bundle_panel_2` (`panel_id`),
  CONSTRAINT `fk_bundle_panel_1` FOREIGN KEY (`bundle_id`) REFERENCES `bundle` (`bundle_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bundle_panel_2` FOREIGN KEY (`panel_id`) REFERENCES `panel` (`panel_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_panel`
--

LOCK TABLES `bundle_panel` WRITE;
/*!40000 ALTER TABLE `bundle_panel` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_panel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_release_gene`
--

DROP TABLE IF EXISTS `bundle_release_gene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_release_gene` (
  `rel_gene_id` int(11) NOT NULL,
  `bundle_id` int(11) NOT NULL,
  PRIMARY KEY (`rel_gene_id`,`bundle_id`),
  UNIQUE KEY `index_uniq` (`rel_gene_id`,`bundle_id`),
  KEY `fk_bundle_release_gene_1` (`rel_gene_id`),
  KEY `fk_bundle_release_gene_2` (`bundle_id`),
  CONSTRAINT `fk_bundel_release_gene_2` FOREIGN KEY (`bundle_id`) REFERENCES `bundle` (`bundle_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bundle_release_gene_1` FOREIGN KEY (`rel_gene_id`) REFERENCES `release_gene` (`rel_gene_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_release_gene`
--

LOCK TABLES `bundle_release_gene` WRITE;
/*!40000 ALTER TABLE `bundle_release_gene` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_release_gene` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_transcript_tmp`
--

DROP TABLE IF EXISTS `bundle_transcript_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_transcript_tmp` (
  `bundle_id` int(11) NOT NULL,
  `transcript_id` int(11) NOT NULL,
  UNIQUE KEY `index_1` (`bundle_id`,`transcript_id`),
  KEY `FK_design_transcript_2` (`transcript_id`),
  KEY `FK3` (`bundle_id`),
  CONSTRAINT `FK3` FOREIGN KEY (`bundle_id`) REFERENCES `bundle` (`bundle_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_design_transcript_2` FOREIGN KEY (`transcript_id`) REFERENCES `transcripts` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_transcript_tmp`
--

LOCK TABLES `bundle_transcript_tmp` WRITE;
/*!40000 ALTER TABLE `bundle_transcript_tmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_transcript_tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_transcripts`
--

DROP TABLE IF EXISTS `bundle_transcripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_transcripts` (
  `bundle_id` int(11) NOT NULL,
  `transcript_id` int(11) NOT NULL,
  `transmission` varchar(45) DEFAULT NULL,
  `update_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`bundle_id`,`transcript_id`),
  KEY `transcript_id_idx` (`transcript_id`),
  CONSTRAINT `bundle_id` FOREIGN KEY (`bundle_id`) REFERENCES `bundle` (`bundle_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_transcripts`
--

LOCK TABLES `bundle_transcripts` WRITE;
/*!40000 ALTER TABLE `bundle_transcripts` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_transcripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_transcriptsLike`
--

DROP TABLE IF EXISTS `bundle_transcriptsLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_transcriptsLike` (
  `bundle_id` int(11) NOT NULL,
  `transcript_id` int(11) NOT NULL,
  `transmission` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`bundle_id`,`transcript_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_transcriptsLike`
--

LOCK TABLES `bundle_transcriptsLike` WRITE;
/*!40000 ALTER TABLE `bundle_transcriptsLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_transcriptsLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_bundle`
--

DROP TABLE IF EXISTS `capture_bundle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_bundle` (
  `capture_id` int(11) NOT NULL,
  `bundle_id` int(11) NOT NULL,
  PRIMARY KEY (`capture_id`,`bundle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_bundle`
--

LOCK TABLES `capture_bundle` WRITE;
/*!40000 ALTER TABLE `capture_bundle` DISABLE KEYS */;
/*!40000 ALTER TABLE `capture_bundle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_bundleLike`
--

DROP TABLE IF EXISTS `capture_bundleLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_bundleLike` (
  `capture_id` int(11) NOT NULL,
  `bundle_id` int(11) NOT NULL,
  PRIMARY KEY (`capture_id`,`bundle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_bundleLike`
--

LOCK TABLES `capture_bundleLike` WRITE;
/*!40000 ALTER TABLE `capture_bundleLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `capture_bundleLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_systems`
--

DROP TABLE IF EXISTS `capture_systems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_systems` (
  `capture_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `version` int(11) DEFAULT 0,
  `description` varchar(45) DEFAULT NULL,
  `filename` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `transcripts` varchar(10000) DEFAULT NULL,
  `validation_db` varchar(45) DEFAULT NULL,
  `primers_filename` varchar(45) DEFAULT NULL,
  `analyse` varchar(45) DEFAULT NULL,
  `design_id` int(11) DEFAULT NULL,
  `method` varchar(20) NOT NULL,
  `release_id` int(11) NOT NULL,
  `rel_gene_id` int(11) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `umi_id` int(2) DEFAULT 0,
  `def` tinyint(1) unsigned DEFAULT 1,
  `plt` tinyint(1) unsigned zerofill DEFAULT NULL,
  PRIMARY KEY (`capture_id`),
  KEY `index_2` (`name`,`version`),
  KEY `index3` (`release_id`),
  KEY `index4` (`rel_gene_id`)
) ENGINE=InnoDB AUTO_INCREMENT=589 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_systems`
--

LOCK TABLES `capture_systems` WRITE;
/*!40000 ALTER TABLE `capture_systems` DISABLE KEYS */;
INSERT INTO `capture_systems` VALUES (1,'agilent_v30',1,'agilent capture version 1','agilent.v30.bed','agilent','','','','exome',NULL,'capture',919,0,'2010-01-10 14:32:39',0,0,NULL),(2,'agilent_v50',1,'50 Mb','agilent.v50.bed','agilent','','','','exome',NULL,'capture',919,0,'2010-01-10 14:32:39',0,0,NULL),(3,'ciliomeV1',1,'ciliomeV1','ciliome_v1.bed','ciliome','ENST00000367800;ENST00000457866;ENST00000265602;ENST00000327035;ENST00000264448;ENST00000303097;ENST00000394222;ENST00000471138;ENST00000535334;ENST00000493990;ENST00000463745;ENST00000335979;ENST00000394206;ENST00000261499;ENST00000575403;ENST00000243578;ENST00000318312;ENST00000393262;ENST00000314218;ENST00000542236;ENST00000245157;ENST00000268057;ENST00000542334;ENST00000295240;ENST00000264499;ENST00000506636;ENST00000508244;ENST00000425232;ENST00000503292;ENST00000424120;ENST00000413206;ENST00000511544;ENST00000503658;ENST00000438599;ENST00000507954;ENST00000515124;ENST00000278935;ENST00000552810;ENST00000223208;ENST00000541543;ENST00000343969;ENST00000489512;ENST00000398093;ENST00000375735;ENST00000262366;ENST00000433375;ENST00000347300;ENST00000296266;ENST00000348417;ENST00000349441;ENST00000426508;ENST00000260570;ENST00000542766;ENST00000314067;ENST00000556742;ENST00000238628;ENST00000326448;ENST00000483465;ENST00000496589;ENST00000319980;ENST00000351808;ENST00000262457;ENST00000262456;ENST00000349820;ENST00000310864;ENST00000394412;ENST00000399054;ENST00000347364;ENST00000393119;ENST00000537529;ENST00000439128;ENST00000512193;ENST00000510533;ENST00000511633;ENST00000507142;ENST00000268766;ENST00000316534;ENST00000355301;ENST00000393272;ENST00000445609;ENST00000337331;ENST00000378156;ENST00000340096;ENST00000287600;ENST00000371117;ENST00000340994;ENST00000242067;ENST00000350941;ENST00000355070;ENST00000396127;ENST00000379925;ENST00000262135;ENST00000366541;ENST00000397655;ENST00000397659;ENST00000551590;ENST00000426174;ENST00000303372;ENST00000265993;ENST00000430368;ENST00000278826;ENST00000515837;ENST00000258173;ENST00000398114;ENST00000409883;ENST00000409444;ENST00000409623;ENST00000453321;ENST00000373327;ENST00000391993;ENST00000373983;ENST00000450136;ENST00000243344;ENST00000380656;ENST00000345383;ENST00000346301;ENST00000272321;ENST00000399820;ENST00000372715;ENST00000281405;ENST00000345530;ENST00000407559;ENST00000561648;ENST00000262383','ciliome','ciliome_v1_primers.bed','ciliome',NULL,'capture',919,1,'2014-04-14 12:24:00',0,0,NULL),(4,'SIDS',1,'mort subite ','SIDS.bed','agilent','','','','SIDS',NULL,'capture',919,1,'2011-05-03 07:09:23',0,0,NULL),(5,'Alport',1,'ALPORT MASTR ','alport.bed','multiplicom','ENST00000396578;ENST00000396625;ENST00000361603','Alport','alport.bed.primers','Alport',NULL,'pcr',919,1,'2011-08-11 10:56:45',0,0,NULL),(6,'rainDance_chrX',1,'Raindance chrX','raindance.X.bed','rainDance','','','','diagnostic',NULL,'pcr',919,1,'2018-09-04 10:44:19',0,0,NULL),(7,'rainDance_Fournet',1,'Raindance Fournet','rainDance_Fournet.bed','rainDance','','','','diagnostic',NULL,'pcr',919,1,'2012-01-05 12:45:54',0,0,NULL),(8,'myopathie',1,'myopathie','Myopathie.bed.txt','agilent','','ciliome','','ciliome',NULL,'capture',919,1,'2012-03-27 10:14:34',0,0,NULL),(9,'ciliomeV2',2,'ciliomeV2','ciliome_V2.bed','ciliome','ENST00000367800;ENST00000457866;ENST00000265602;ENST00000327035;ENST00000264448;ENST00000303097;ENST00000394222;ENST00000471138;ENST00000535334;ENST00000493990;ENST00000463745;ENST00000335979;ENST00000394206;ENST00000261499;ENST00000575403;ENST00000243578;ENST00000318312;ENST00000393262;ENST00000314218;ENST00000542236;ENST00000245157;ENST00000268057;ENST00000542334;ENST00000295240;ENST00000264499;ENST00000506636;ENST00000508244;ENST00000425232;ENST00000503292;ENST00000424120;ENST00000413206;ENST00000511544;ENST00000503658;ENST00000438599;ENST00000507954;ENST00000515124;ENST00000373602;ENST00000278935;ENST00000552810;ENST00000223208;ENST00000541543;ENST00000343969;ENST00000489512;ENST00000398093;ENST00000375735;ENST00000262366;ENST00000433375;ENST00000347300;ENST00000296266;ENST00000348417;ENST00000349441;ENST00000426508;ENST00000260570;ENST00000542766;ENST00000314067;ENST00000556742;ENST00000238628;ENST00000326448;ENST00000483465;ENST00000496589;ENST00000319980;ENST00000351808;ENST00000262457;ENST00000262456;ENST00000349820;ENST00000310864;ENST00000394412;ENST00000399054;ENST00000347364;ENST00000393119;ENST00000537529;ENST00000439128;ENST00000512193;ENST00000510533;ENST00000511633;ENST00000507142;ENST00000268766;ENST00000316534;ENST00000355301;ENST00000393272;ENST00000445609;ENST00000337331;ENST00000378156;ENST00000340096;ENST00000287600;ENST00000371117;ENST00000340994;ENST00000242067;ENST00000350941;ENST00000355070;ENST00000396127;ENST00000379925;ENST00000262135;ENST00000366541;ENST00000397655;ENST00000397659;ENST00000551590;ENST00000426174;ENST00000303372;ENST00000265993;ENST00000430368;ENST00000278826;ENST00000515837;ENST00000258173;ENST00000398114;ENST00000409883;ENST00000409444;ENST00000409623;ENST00000453321;ENST00000373327;ENST00000391993;ENST00000373983;ENST00000450136;ENST00000243344;ENST00000380656;ENST00000345383;ENST00000346301;ENST00000272321;ENST00000399820;ENST00000372715;ENST00000281405;ENST00000345530;ENST00000407559;ENST00000561648;ENST00000262383','ciliome','ciliome_V2_primers.bed','ciliome',NULL,'capture',919,1,'2013-02-08 08:39:06',0,0,NULL),(10,'HLH',1,'HLH','HLH.bed','multiplicom','ENST00000441259;ENST00000207549;ENST00000367568;ENST00000221283;ENST00000396307;ENST00000389793;ENST00000371139;ENST00000371199;ENST00000422843','HLH','HLH.bed.primers','HLH',NULL,'pcr',919,1,'2012-07-10 12:30:21',0,0,NULL),(11,'SeqCap_EZ_Exome_v3_capture',3,'SeqCap_EZ_Exome_v3_capture','SeqCap_EZ_Exome_v3_capture.bed','nimblegen','','','SeqCap_EZ_Exome_v3_capture.bed.primers','exome',NULL,'capture',919,0,'2014-04-15 10:23:01',0,0,NULL),(12,'agilent_v70',1,'70 Mb','agilent.v70.bed','agilent','','','','exome',NULL,'capture',919,0,'2012-08-17 07:18:14',0,0,NULL),(13,'IAD23758',1,'ampliseq','IAD23758.bed','AmpliSeq','',NULL,NULL,'diagnostic',NULL,'pcr',919,1,'0000-00-00 00:00:00',0,1,NULL),(14,'AUU_custom_agilent',1,'custom AUU agilent','AUU.bed','agilent','','divers','','divers',NULL,'capture',919,1,'2012-08-23 11:16:17',0,0,NULL),(15,'agilent_50_v4',4,'agilent 50 v4','agilent.50.v4.bed','agilent','',NULL,NULL,'exome',NULL,'capture',919,0,'2012-10-26 17:20:50',0,0,NULL),(16,'mitochondrie',0,'mitochondrie','mito.bed','other','',NULL,'','diagnostic',NULL,'',919,1,'2012-11-16 09:47:20',0,0,NULL),(17,'bacteria',1,'bacteria','bacteria.bed','other','',NULL,NULL,'other',NULL,'',919,1,'2012-12-07 13:14:38',0,1,NULL),(18,'SeqCap_EZ_Exome_v2',2,'nimblegen v2','SeqCap_EZ_Exome_v2.bed','nimblegen','',NULL,NULL,'exome',NULL,'capture',919,0,'2012-12-11 10:06:38',0,0,NULL),(19,'raindance_mirnome',1,'raindance mirnome','raindance.MIR.bed','rainDance','',NULL,NULL,'diagnostic',NULL,'',919,1,'2014-04-16 10:25:50',0,0,NULL),(20,'CFTR',1,'CFTR Multiplicom','CFTR.bed','multiplicom','ENST00000003084',NULL,NULL,'CFTR',NULL,'pcr',919,1,'2013-02-22 12:43:01',0,0,NULL),(21,'agilent_50_v5',5,'agilent 50 v5','agilent.50.v5.bed','agilent','','','','exome',NULL,'capture',919,0,'2013-05-14 07:23:25',0,0,NULL),(22,'FSGS',3,'FSGS','FSGS-amplicon.v3.bed','multiplicom','ENST00000252699;ENST00000324464;ENST00000395184;ENST00000269321;ENST00000306954;ENST00000397420;ENST00000359314;ENST00000311469;ENST00000334571;ENST00000359543;ENST00000392634;ENST00000320031;ENST00000200181;ENST00000586659;ENST00000418109;ENST00000526117;ENST00000354212;ENST00000319217;ENST00000216181;ENST00000288235;ENST00000378910;ENST00000367615;ENST00000369037;ENST00000260766;ENST00000281171;ENST00000264896;ENST00000357276;ENST00000344327;ENST00000243344;ENST00000332351;ENST00000386347;ENST00000371385','FSGS','FSGS-amplicon.v3.bed.primers','FSGS',NULL,'pcr',919,1,'2013-04-05 11:44:41',0,0,NULL),(23,'Ion-targetSeq',1,'TargetSeq','Ion-50-revA.bed','targetseq','',NULL,NULL,'exome',NULL,'capture',919,0,'2014-04-15 10:26:18',0,0,NULL),(24,'OI',1,'osteogenese imparfaite','osteoImparfaite.bed','other','ENST00000225964;ENST00000297268;ENST00000320954;ENST00000397054;ENST00000300026;ENST00000524558;ENST00000254722;ENST00000321562;ENST00000536324;ENST00000282903','OI','','OI',NULL,'',919,1,'2013-05-28 12:56:30',0,0,NULL),(25,'chuber_syn_desb',1,'syndrome de desb','chuber_syn_desb.bed','other','','Desb','chuber_syn_desb_primer.bed','Desb',NULL,'',919,1,'2014-04-16 10:22:09',0,0,NULL),(26,'mito',1,'mitochondrie','mito.bed','other','dloop-1;ENST00000387314;ENST00000389680;ENST00000387342;ENST00000387347;ENST00000386347;ENST00000361390;ENST00000387365;ENST00000387372;ENST00000387377;ENST00000361453;ENST00000387382;ENST00000387392;ENST00000387400;ENST00000387405;ENST00000387409;ENST00000361624;ENST00000387416;ENST00000387419;ENST00000361739;ENST00000387421;ENST00000361851;ENST00000361899;ENST00000362079;ENST00000387429;ENST00000361227;ENST00000387439;ENST00000361335;ENST00000361381;ENST00000387441;ENST00000387449;ENST00000387456;ENST00000361567;ENST00000361681;ENST00000387459;ENST00000361789;ENST00000387460;ENST00000387461;dloop-2','mito','mito.primers.bed','mito',NULL,'capture',901,1,'2013-07-01 07:05:05',0,0,NULL),(27,'CHR8_JMR',1,'capture chr8 nimblegen pour JMR ','CHR8_JMR.bed','nimblegen','',NULL,NULL,'diagnostic',NULL,'capture',919,1,'2014-04-16 10:19:27',0,0,NULL),(28,'ciliomev3',3,'ciliomev3','ciliome_V3.bed','ciliome','ENST00000367800;ENST00000457866;ENST00000265602;ENST00000327035;ENST00000264448;ENST00000303097;ENST00000394222;ENST00000471138;ENST00000535334;ENST00000493990;ENST00000463745;ENST00000335979;ENST00000394206;ENST00000261499;ENST00000575403;ENST00000243578;ENST00000318312;ENST00000393262;ENST00000314218;ENST00000542236;ENST00000245157;ENST00000268057;ENST00000542334;ENST00000295240;ENST00000264499;ENST00000506636;ENST00000508244;ENST00000425232;ENST00000503292;ENST00000424120;ENST00000413206;ENST00000511544;ENST00000503658;ENST00000438599;ENST00000507954;ENST00000515124;ENST00000278935;ENST00000552810;ENST00000223208;ENST00000541543;ENST00000343969;ENST00000489512;ENST00000398093;ENST00000375735;ENST00000262366;ENST00000433375;ENST00000347300;ENST00000296266;ENST00000348417;ENST00000349441;ENST00000426508;ENST00000260570;ENST00000542766;ENST00000314067;ENST00000556742;ENST00000238628;ENST00000326448;ENST00000483465;ENST00000496589;ENST00000319980;ENST00000351808;ENST00000262457;ENST00000262456;ENST00000349820;ENST00000310864;ENST00000394412;ENST00000399054;ENST00000347364;ENST00000393119;ENST00000537529;ENST00000439128;ENST00000512193;ENST00000510533;ENST00000511633;ENST00000507142;ENST00000268766;ENST00000316534;ENST00000355301;ENST00000393272;ENST00000445609;ENST00000337331;ENST00000378156;ENST00000340096;ENST00000287600;ENST00000371117;ENST00000340994;ENST00000242067;ENST00000350941;ENST00000355070;ENST00000396127;ENST00000379925;ENST00000262135;ENST00000366541;ENST00000397655;ENST00000397659;ENST00000551590;ENST00000426174;ENST00000303372;ENST00000265993;ENST00000430368;ENST00000278826;ENST00000515837;ENST00000258173;ENST00000398114;ENST00000409883;ENST00000409444;ENST00000409623;ENST00000453321;ENST00000373327;ENST00000391993;ENST00000373983;ENST00000450136;ENST00000243344;ENST00000380656;ENST00000345383;ENST00000346301;ENST00000272321;ENST00000399820;ENST00000372715;ENST00000281405;ENST00000345530;ENST00000407559;ENST00000561648;ENST00000262383','ciliome','ciliome_V3.bed.primers','ciliome',NULL,'capture',919,1,'2014-03-17 09:22:17',0,0,NULL),(29,'Cancer_Panel',1,'cancer panel ','cancerpanel.bed','AmpliSeq','',NULL,NULL,'diagnostic',NULL,'pcr',919,1,'2013-09-26 11:24:48',0,0,NULL),(30,'PKHD1',1,'pkhd1','pkhd1.bed','AmpliSeq','ENST00000371117;ENST00000340994;ENST00000225893','PKHD1','pkhd1.bed.primers','PKHD1',NULL,'pcr',919,1,'2013-10-09 17:28:45',0,0,NULL),(31,'hemopathie',1,'hemopathie ','hemopathie.bed','AmpliSeq','ENST00000381652;ENST00000320356;ENST00000281708;ENST00000296555;ENST00000263981;ENST00000264033;ENST00000341259;ENST00000264122;ENST00000335508;ENST00000372470;ENST00000264709;ENST00000241453;ENST00000311936;ENST00000345146;ENST00000396373;ENST00000270279;ENST00000377967;ENST00000277541;ENST00000288135;ENST00000437180;ENST00000291552;ENST00000392485;ENST00000380013;ENST00000307771;ENST00000375687;ENST00000371953;ENST00000322652;ENST00000351677;ENST00000296930;ENST00000330062;ENST00000452863;ENST00000369535;ENST00000498907;ENST00000265165;ENST00000269305;ENST00000379951','hemopathie','','hemopathie',NULL,'pcr',919,1,'2013-10-28 10:36:53',0,0,NULL),(32,'ampliseq_exome',1,'ampliseq_exome','AmpliSeqExome.20131001.designed.bed','AmpliSeq','','','','exome',NULL,'pcr',919,0,'2013-12-19 14:43:43',0,0,NULL),(33,'DM1',1,'DM1','LR_ST.bed','other','ENST00000291270;ENST00000263274','DM1','','DM1',NULL,'',919,1,'2014-03-13 15:05:39',0,0,NULL),(34,'AlportcDNA',1,'AlportcDNA','AlportcDNA.bed','other','ENST00000396578;ENST00000396625;ENST00000361603;ENST00000284110;ENST00000395310',NULL,NULL,'diagnostic',NULL,'',919,1,'2014-03-17 08:49:33',0,0,NULL),(35,'cDNA',1,'cDNA','cDNA.bed','other','ENST00000395310;ENST00000284110',NULL,NULL,'diagnostic',NULL,'',919,1,'2014-03-17 08:49:21',0,0,NULL),(36,'nextera',1,'nextera','nextera.bed','other','',NULL,NULL,'diagnostic',NULL,'',919,1,'0000-00-00 00:00:00',0,0,NULL),(37,'NF1',1,'NF1','NF1.bed','AmpliSeq','ENST00000358273;ENST00000299084','NF1','NF1.primers.bed','NF1',NULL,'pcr',919,1,'2014-04-01 17:40:56',0,0,NULL),(38,'FSHD',1,'FSHD','FSHD.bed','AmpliSeq','ENST00000320876;ENST00000369763;ENST00000376687','FSHD','FSHD.primers.bed','FSHD',NULL,'pcr',919,1,'2014-04-11 07:12:27',0,0,NULL),(39,'nextera_rapid',1,'nextera_rapid','nexterarapidcapture_exome_targetedregions.bed','illumina','',NULL,NULL,'exome',NULL,'capture',919,0,'2014-05-06 12:36:40',0,0,NULL),(40,'ciliome_V3_SRY',1,'ciliome_V3_SRY','ciliome_V3_SRY.bed','ciliome','','ciliome','ciliome_V3_SRY.bed.primers','ciliome',NULL,'capture',919,1,'2014-06-06 08:05:32',0,0,NULL),(41,'leber',1,'Capture SureSelect LEBER','leber.bed','agilent','ENST00000254854;ENST00000393272;ENST00000262340;ENST00000221996;ENST00000231188;ENST00000338791;ENST00000342292;ENST00000310864;ENST00000331664;ENST00000409883;ENST00000503292;ENST00000503581;ENST00000334888;ENST00000542188;ENST00000535699;ENST00000393504;ENST00000233826;ENST00000397795;ENST00000331056;ENST00000229771;ENST00000340096;ENST00000261892;ENST00000336356;ENST00000376265;ENST00000351050;ENST00000371447;ENST00000421804;ENST00000366541;ENST00000371464;ENST00000381129;ENST00000426508;ENST00000378156;ENST00000264448;ENST00000379925;ENST00000278826;ENST00000457866;ENST00000358544;ENST00000393545;ENST00000223208;ENST00000320005;ENST00000371712;ENST00000400017;ENST00000342595;ENST00000377205;ENST00000425232;ENST00000262210;ENST00000552810;ENST00000382082;ENST00000325656;ENST00000409444;ENST00000551171;ENST00000337331;ENST00000286688;ENST00000392959;ENST00000471138;ENST00000367002;ENST00000394412;ENST00000367400','leber','leber.primers.bed','leber',NULL,'capture',919,1,'2014-06-19 07:40:33',0,0,NULL),(42,'LAImmature',1,'LAImmature','LAImmature.bed','other','ENST00000341259;ENST00000351677;ENST00000241453;ENST00000267163;ENST00000345514;ENST00000558401;ENST00000330062;ENST00000264010;ENST00000420246;ENST00000358273;ENST00000322652;ENST00000580830;ENST00000392485;ENST00000359692;ENST00000263388;ENST00000458235;ENST00000498907;ENST00000246792;ENST00000406403;ENST00000375687;ENST00000344691;ENST00000459639;ENST00000263253;ENST00000307771;ENST00000251900;ENST00000342274;ENST00000377967;ENST00000376670;ENST00000322213;ENST00000371160;ENST00000540052;ENST00000332070;ENST00000424325','LAImmature','LAImmature.primers.bed','LAImmature',NULL,'',919,1,'2014-07-01 11:51:33',0,0,NULL),(43,'test_diag',1,'test diag','FragiliteVasculaire_v32.bed','other','','testdiag','test_diag.primers.bed','testdiag',NULL,'',919,1,'2014-07-04 06:59:20',0,0,NULL),(44,'surdite',1,'surdite','surdite.bed','other','ENST00000573283;ENST00000311916;ENST00000370228;ENST00000392456;ENST00000245816;ENST00000396618;ENST00000372216;ENST00000334504;ENST00000342947;ENST00000545231;ENST00000398557;ENST00000400324;ENST00000340726;ENST00000388740;ENST00000367895;ENST00000355167;ENST00000379328;ENST00000382848;ENST00000373366;ENST00000373362;ENST00000356192;ENST00000264126;ENST00000230771;ENST00000504811;ENST00000256216;ENST00000347132;ENST00000265537;ENST00000360614;ENST00000362288;ENST00000388958;ENST00000388956;ENST00000388957;ENST00000272371;ENST00000402415;ENST00000403946;ENST00000373200;ENST00000230732;ENST00000372435;ENST00000247182;ENST00000265715;ENST00000373189;ENST00000379494;ENST00000392793;ENST00000372902;ENST00000297784;ENST00000340019;ENST00000226760','Surdite','surdite.primers.bed','Surdite',NULL,'pcr',919,1,'0000-00-00 00:00:00',0,0,NULL),(45,'PolG-1exon2',1,'PolG-1exon2','PolG-1exon2.bed','other','',NULL,NULL,'diagnostic',NULL,'pcr',919,1,'2014-07-15 13:17:31',0,0,NULL),(46,'hemopathie_v2',2,'hemopathie_v2','hemopathie_v2.bed','AmpliSeq','ENST00000381652;ENST00000320356;ENST00000281708;ENST00000296555;ENST00000263981;ENST00000264033;ENST00000341259;ENST00000264122;ENST00000335508;ENST00000372470;ENST00000264709;ENST00000241453;ENST00000311936;ENST00000345146;ENST00000396373;ENST00000270279;ENST00000377967;ENST00000277541;ENST00000288135;ENST00000437180;ENST00000291552;ENST00000392485;ENST00000380013;ENST00000307771;ENST00000375687;ENST00000371953;ENST00000322652;ENST00000351677;ENST00000296930;ENST00000330062;ENST00000452863;ENST00000369535;ENST00000498907;ENST00000265165;ENST00000269305;ENST00000379951','hemopathie','hemopathie_v2.bed.primers','hemopathie',NULL,'pcr',919,1,'2014-07-18 08:55:53',0,0,NULL),(47,'FSGS_v4',4,'FSGS_v4','FSGS_v4.bed','multiplicom','ENST00000252699;ENST00000324464;ENST00000395184;ENST00000269321;ENST00000306954;ENST00000397420;ENST00000359314;ENST00000311469;ENST00000334571;ENST00000359543;ENST00000392634;ENST00000320031;ENST00000200181;ENST00000586659;ENST00000418109;ENST00000526117;ENST00000354212;ENST00000319217;ENST00000216181;ENST00000288235;ENST00000378910;ENST00000367615;ENST00000369037;ENST00000260766;ENST00000281171;ENST00000264896;ENST00000357276;ENST00000344327;ENST00000243344;ENST00000332351;ENST00000386347;ENST00000371385','FSGS','FSGS_v4.bed.primers','FSGS',NULL,'pcr',919,1,'2014-07-25 11:50:03',0,0,NULL),(48,'callosome',1,'callosome','callosome.bed','agilent','','callosome','callosome.primers.bed.new.2','callosome',NULL,'capture',919,1,'2014-08-28 11:05:57',0,0,NULL),(49,'HLH_baits',1,'HLH_baits','HLH_baits.bed','baits_capture','','HLHbaits','HLH_baits.bed.primers','HLHbaits',NULL,'capture',919,1,'2014-09-06 03:20:14',0,0,NULL),(50,'IDiome',1,'IDiome','IDiome.bed','agilent','','idefix','IDiome.primers.bed','idefix',NULL,'capture',919,1,'2014-09-08 06:35:54',0,0,NULL),(52,'trypasian',1,'trypasian','Trypasian.bed','other','','trypasian','Trypasian.bed.primers','trypasian',NULL,'',919,1,'2014-09-06 03:17:06',0,0,NULL),(53,'RETL1_genomic',1,'RETL1_genomic','RETL1_genomic.bed','BAC','','RETL1genomic','','RETL1genomic',NULL,'',919,1,'2014-09-08 06:30:16',0,0,NULL),(54,'Rab27a_genomic',1,'Rab27a_genomic','Rab27a_genomic.bed','BAC','','Rab27agenomic','Rab27a_genomic.bed.primers','Rab27agenomic',NULL,'',919,1,'2014-09-08 06:31:04',0,0,NULL),(55,'DM1_bac_cosmid',1,'DM1_bac_cosmid','DM1_bac_cosmid.bed','BAC','','DM1baccosmid','','DM1baccosmid',NULL,'',919,1,'2014-09-08 06:17:47',0,0,NULL),(59,'OH_mutation_Polycomb',1,'OH_mutation_Polycomb','OH_mutation_Polycomb.bed','Truseq','','Polycomb','Polycomb_truseq_primers.bed','Polycomb',NULL,'pcr',919,1,'2014-09-22 06:37:37',0,0,NULL),(60,'Cakutome_TSCA',1,'Cakutome Truseq panel','Cakutome.bed','Truseq','','Cakutome','Cakutome_primers.bed','Cakutome',NULL,'pcr',919,1,'2014-09-22 12:58:01',0,0,NULL),(61,'OI_TSCA',1,'Osteogenese imparfaite Truseq panel','OI.bed','Truseq','','OI','OI_primers.bed','OI',NULL,'pcr',919,1,'2014-09-22 13:04:11',0,0,NULL),(62,'Surdite_TSCA',1,'Surdite Truseq panel','Surdite.bed','Truseq','','Surdite','Surdite_primers.bed','Surdite',NULL,'pcr',919,1,'2014-09-22 12:57:25',0,0,NULL),(63,'AS',1,'Avance Staturale','AS.bed','Truseq','','AS','AS_primers.bed','AS',NULL,'pcr',919,1,'2014-09-23 06:40:07',0,0,NULL),(64,'CD',1,'Cornelia De Lange','CD.bed','Truseq','','CD','CD_primers.bed','CD',NULL,'pcr',919,1,'2014-09-23 06:39:38',0,0,NULL),(65,'test',1,'only for tests','test2.bed','other','','','','exome',NULL,'capture',938,0,'2014-09-24 06:37:17',0,0,NULL),(71,'LGMD',1,'Limb Girdle Muscular Dystrophy','LGMD.bed','AmpliSeq','','LGMD','LGMD_primers.bed','LGMD',NULL,'pcr',919,1,'2014-10-10 11:12:52',0,0,NULL),(72,'DMD',1,'dystrophinopathies','DMD.bed','AmpliSeq','','DMD','DMD_primers.bed','DMD',NULL,'pcr',919,1,'2014-10-10 10:20:44',0,0,NULL),(83,'MOC',1,'Maladies Osseuses Constitutives','MOC.bed','agilent','','MOC','MOC.primers.bed','MOC',NULL,'capture',919,1,'2015-01-28 09:12:55',0,0,NULL),(84,'Hirschprome',1,'Hirschprome','Hirschprome.bed','agilent','','hirschsprome','Hirschprome.primers.bed','hirschsprome',NULL,'capture',919,1,'2014-11-12 12:26:11',0,0,NULL),(85,'Sotos_v1',1,'IAD54204 3 genes','SotosIAD54204.bed','AmpliSeq','','Sotos','SotosIAD54204.primers.bed','Sotos',NULL,'pcr',919,1,'2014-11-14 09:31:57',0,0,NULL),(86,'SOTOSv2',2,'Sotosv2','DesignSOTOSv2.bed','AmpliSeq','','Sotos','IAD62451_primers.bed','Sotos',NULL,'pcr',919,1,'2014-11-25 11:01:07',0,0,NULL),(87,'charge',1,'charge','charge.bed','other','','charge','charge.bed.primers','charge',NULL,'pcr',919,1,'2014-12-01 08:36:26',0,0,NULL),(88,'ciliome_V2_selection',1,'13genes','ciliome_V2_selection.bed','ciliome','','ciliome','ciliome_V2_selection.bed.primers','ciliome',NULL,'capture',919,1,'2014-12-08 08:44:36',0,0,NULL),(89,'ciliome_v4',4,'ciliome v4','ciliomeV4.bed','ciliome','','ciliome','ciliome_v4.primers.bed','ciliome',NULL,'capture',919,1,'2014-12-19 10:27:42',0,0,NULL),(90,'all_genes',1,'all_gene','all_genes.bed','other','',NULL,NULL,'genome',NULL,'capture',919,0,'0000-00-00 00:00:00',0,0,NULL),(91,'all_exons',1,'all_exons','all_exons.bed','other','',NULL,NULL,'genome',NULL,'',919,0,'2016-09-20 08:06:19',0,0,NULL),(92,'OI_v2',2,'OI_v2','OI_v2.bed','Truseq','','OI','OI_v2_primers.bed','OI',NULL,'pcr',919,1,'2015-01-20 09:27:39',0,0,NULL),(93,'surdite_v2',2,'surdite_v2','surdite_v2.bed','Truseq','','Surdite','surdite_v2_primers.bed','Surdite',NULL,'pcr',919,1,'2015-01-26 14:09:41',0,0,NULL),(94,'CDG-DC',1,'CDG-DC','CDG-DC_amplicons.bed','Haloplex','','CDGDC','CDG-DC_amplicons_uniques.bed.primers','CDGDC',NULL,'',919,1,'2015-01-23 14:24:29',0,0,NULL),(97,'full_exome',1,'full_exome','full_exome.bed','other','',NULL,NULL,'genome',NULL,'',919,0,'2015-11-16 09:55:26',0,0,NULL),(98,'SDHv1',1,'SDH Multiplicom','SDHv1.bed','multiplicom','','PGLPHEO','SDHv1.primer.bed','PGLPHEO',NULL,'pcr',919,1,'2015-01-23 15:30:01',0,0,NULL),(99,'Haloplex_kitVF',1,'kitVF haloplex','Haloplex_kitVF.amplicons.bed','Haloplex','','FragiliteVasculaire','Haloplex_kitVF.primers.bed','FragiliteVasculaire',NULL,'pcr',919,1,'2015-01-26 08:13:49',0,0,NULL),(100,'agilent_clinical_research',1,'agilent_clinical_research','agilent.clinical.research.bed','agilent','','','agilent.clinical.research.primers','exome',NULL,'capture',919,0,'2015-01-26 15:18:24',0,0,NULL),(101,'Tubulo_v1',1,'Tubulo_v1 multiplicom','Tubulo_v1.bed','multiplicom','','Tubulopathies','Tubulo_v1.primers.bed','Tubulopathies',NULL,'pcr',919,1,'2015-01-28 09:33:49',0,0,NULL),(102,'Cardiomyopathie_raindance',1,'CMH_raindance','raindance_CMH.bed','rainDance','','Cardiomyopathie','raindance_CMH.primers.bed','Cardiomyopathie',NULL,'pcr',919,1,'2015-01-29 13:15:20',0,0,NULL),(103,'NER',1,'NER','NER.bed','AmpliSeq','','NER','NER_primers_ok.txt','NER',NULL,'pcr',919,1,'2015-02-04 08:05:37',0,0,NULL),(104,'Keratine1_10',1,'Keratine1_10','Keratine1_10.bed','other','','Keratine','Keratine1_10_primers.bed','Keratine',NULL,'capture',919,1,'2015-02-04 12:47:40',0,0,NULL),(105,'MitomeV1',1,'MitomeV1','MitomeV1.bed','agilent','','Mitome','MitomeV1.primers.bed','Mitome',NULL,'capture',919,1,'2015-02-23 08:11:51',0,0,NULL),(106,'Cakutome_agilent',1,'Cakutome_agilent','Cakutome.bed','agilent','','CakutomeBaits','Cakutome.primers.bed','CakutomeBaits',NULL,'capture',919,1,'2015-04-10 07:31:45',0,0,NULL),(107,'ColonLung',1,'ColonLung','ColonLung.bed','AmpliSeq','','ColonLung','ColonLung_primers.bed','ColonLung',NULL,'pcr',919,1,'2015-03-19 08:13:12',0,0,NULL),(108,'Def_immuno',1,'Deficits_immuno','Def_immuno.bed','agilent','','DefIm','Def_immuno_primers.bed','DefIm',NULL,'capture',919,1,'2015-05-04 12:31:04',0,0,NULL),(109,'OH_Mutation_LAImmatureATL_1401010',1,'OH_Mutation_LAImmatureATL_1401010','OH_Mutation_LAImmatureATL_1401010.bed','Nextera_rapid_capture','','OHLAImATL','OH_Mutation_LAImmatureATL_1401010_primers.bed','OHLAImATL',NULL,'capture',919,1,'2015-03-25 09:26:24',0,0,NULL),(111,'LALT_Haloplex',1,'LALT_Haloplex','LALT_Haloplex_amplicons_sort_uniq.bed','Haloplex','','LALTHaloplex','LALT_Haloplex_amplicons_sort_uniq_primers.bed','LALTHaloplex',NULL,'pcr',919,1,'2015-04-15 11:41:40',0,0,NULL),(112,'haloplex_exome',1,'haloplex_exome','haloplex_exome.covered.bed','Haloplex','','','','exome',NULL,'pcr',919,0,'2015-04-27 06:28:19',0,0,NULL),(113,'IAD74298_231_OK',1,'IAD74298_231_OK','IAD74298_231_OK.bed','AmpliSeq','','testdiag','IAD74298_231_OK_primers.bed','testdiag',NULL,'pcr',919,1,'2015-04-27 13:12:19',0,0,NULL),(114,'mvt_disorders',1,'mvt_disorders','mvt_disorders.bed','nimblegen','','MvtDis','mvt_disorders_primers.bed','MvtDis',NULL,'capture',919,1,'2015-05-12 06:24:54',0,0,NULL),(115,'MCN_V1_hg19',1,'Malfo Crete Neurale','MCN.V1.hg19.bed','agilent','','MCN','MCN.V1.hg19_primers.bed','MCN',NULL,'capture',919,1,'2015-06-29 07:55:29',0,0,NULL),(116,'MCD_V1_hg19',1,'Malfo cerebrales','MCD.V1.hg19.bed','agilent','','MCD','MCD.V1.hg19_primers.bed','MCD',NULL,'capture',919,1,'2015-09-22 07:08:06',0,0,NULL),(117,'ichtyose',1,'ichtyose','ichtyose.bed','Qiagen_pcr','','ichtyose','ichtyose_primers.bed','ichtyose',NULL,'pcr',919,1,'2015-05-26 07:21:59',0,0,NULL),(118,'pkhd1_flexicapture',1,'pkhd1 flexicapture','pkhd1_flexicapture.bed','other','','PKHD1','pkhd1_flexicapture.bed.primers','PKHD1',NULL,'capture',919,1,'2015-06-09 10:15:32',0,0,NULL),(119,'FSGS_v5',5,'FSGS_v5','FSGS_v5_initial.bed','other','','FSGS','FSGS_v5_initial.bed.primers','FSGS',NULL,'capture',919,1,'2015-06-09 10:08:25',0,0,NULL),(120,'JSL-big',1,'JSL-big Lupus','Lupus.bed','agilent','','Lupus','Lupus_primers.bed','Lupus',NULL,'capture',919,1,'2015-06-16 12:25:20',0,0,NULL),(121,'SDH_MASTR_v2',2,'Multiplicom_SDH_v2','SDH_MASTR_v2.bed','multiplicom','','PGLPHEO','SDH_MASTR_v2.primer.bed','PGLPHEO',NULL,'pcr',919,1,'2015-06-18 11:58:27',0,0,NULL),(122,'BRCA_IAD77882',1,'BRCA_IAD77882_cochin','BRCA_IAD77882.bed','AmpliSeq','','BRCA','BRCA_IAD77882_primers.bed','BRCA',NULL,'pcr',919,1,'2015-06-26 07:48:00',0,0,NULL),(123,'OI_v3',1,'OI_v3 Truseq','OI_v3.bed','Truseq','','OI','OI_v3_primers.bed','OI',NULL,'pcr',919,1,'2015-10-16 11:07:10',0,0,NULL),(124,'Surdite_v3',1,'Surdite_v3 Truseq','Surdite_v3.bed','Truseq','','Surdite','Surdite_v3_primers.bed','Surdite',NULL,'pcr',919,1,'2015-10-05 12:38:44',0,0,NULL),(125,'DC2_Amplicons',1,'DC2 design haloplex 04403-1424096733_Amplicon','DC2_Amplicons.bed','Haloplex','','CDGDC','DC2_Amplicons_primers.bed','CDGDC',NULL,'pcr',919,1,'2015-06-26 12:16:08',0,0,NULL),(126,'ADC',1,'Anomalies du dev cortical','ADC.bed','AmpliSeq','','ADC','ADC_primers.bed','ADC',NULL,'pcr',919,1,'2015-06-29 06:45:42',0,0,NULL),(127,'TruSight_CMH',1,'TruSight_Cardiomyopathies','TruSight_CMH.bed','TruSight','','CMH','TruSight_CMH.primer.bed','CMH',NULL,'capture',919,1,'2015-07-01 13:02:57',0,0,NULL),(128,'TruSight_Cancer',1,'TruSight_Cancer','TruSight_Cancer.bed','TruSight','','Cancer','TruSight_Cancer.primer.bed','Cancer',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(129,'Tubulo_Nextera_v1',1,'Tubulo_Nextera_v1','Tubulo_Nextera_v1.bed','Nextera_long_range_pcr','','Tubulopathies','Tubulo_Nextera_v1_primer.bed','Tubulopathies',NULL,'pcr',919,1,'2015-07-10 11:21:02',0,0,NULL),(130,'dermatome_v1_hg19',1,'dermatome_v1_hg19','dermatome_v1_hg19.bed','agilent','','dermatome','dermatome_v1_hg19_primers.bed','dermatome',NULL,'capture',919,1,'2015-11-13 09:25:51',0,0,NULL),(131,'epileptome_v1_hg19',1,'epileptome_v1_hg19','epileptome_v1_hg19.bed','agilent','','epileptome','epileptome_v1_hg19_primers.bed','epileptome',NULL,'capture',919,1,'2015-11-13 09:27:21',0,0,NULL),(132,'enteropathies_v1_hg19',1,'enteropathies_v1_hg19','enteropathies_v1_hg19.bed','agilent','','entheropathies','enteropathies_v1_hg19_primers.bed','entheropathies',0,'capture',919,1,'2015-09-22 07:10:10',0,0,NULL),(133,'CFTR_Ampliseq',1,'CFTR_Ampliseq','CFTR.bed','AmpliSeq','','CFTR','CFTR_primers.bed','CFTR',NULL,'pcr',919,1,'2015-07-30 10:59:10',0,0,NULL),(134,'SLE_Lupus',1,'SLE Lupus Manchester','SLE.bed','agilent','','Lupus','SLE_primers.bed','Lupus',NULL,'capture',919,1,'2015-07-31 08:35:20',0,0,NULL),(135,'Complement_disorders',1,'ComplementDisorders_MASTR_v1','ComplementDisorders_MASTR_v1.bed','multiplicom','','CompDisorders','ComplementDisorders_MASTR_v1.primer.bed','CompDisorders',NULL,'pcr',919,1,'2015-07-31 10:35:16',0,0,NULL),(136,'FragiliteVasculaire_v2',2,'FragiliteVasculaire_v2','FragiliteVasculaire_v2.bed','Haloplex','','FragiliteVasculaire','FragiliteVasculaire_v2.primer.bed','FragiliteVasculaire',NULL,'pcr',919,1,'2015-08-12 07:43:33',0,0,NULL),(137,'HIF2A_Nextera_v1',1,'HIF2A_Nextera_v1','HIF2A_Nextera_v1.bed','Nextera_long_range_pcr','','HIF2A','HIF2A_Nextera_v1.primer.bed','HIF2A',NULL,'pcr',919,1,'2015-08-18 10:59:38',0,0,NULL),(138,'Hirschprome_v1-2',1,'Hirschprome_v1.2','Hirschprome_v1.2.bed','baits_capture','','hirschsprome','Hirschprome_v1.2_primers.bed','hirschsprome',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(139,'FSGS_v5_multiplicom',1,'FSGS_v5_multiplicom','FSGS_v5_multiplicom.bed','multiplicom','','FSGS','FSGS_v5_multiplicom.bed.primers','FSGS',NULL,'pcr',919,1,'2015-09-08 11:36:44',0,0,NULL),(140,'IAD45315_Cyn1',1,'IAD45315_Cyn1','IAD45315_Cyn1.bed','AmpliSeq','','addictions','IAD45315_Cyn1_primers.bed','addictions',NULL,'pcr',919,1,'2015-10-05 11:01:13',0,0,NULL),(141,'ADG_CDG-2',1,'ADG_CDG_DESIGN2','ADG_CDG_DESIGN2.bed','Haloplex','','CDGDC','ADG_CDG_DESIGN2_primers.bed','CDGDC',NULL,'pcr',919,1,'2015-10-15 08:00:37',0,0,NULL),(142,'agilent_50_v5_MT',5,'exome avec mitochondrie','agilent.50.v5.MT.bed','agilent','','','','exome',NULL,'capture',919,0,'2015-11-06 14:39:33',0,0,NULL),(143,'Hirschprome_v1-3',1,'Hirschprome_v1.3','Hirschprome_v1.3.bed','baits_capture','','hirschsprome','Hirschprome_v1.3_primers.bed','hirschsprome',NULL,'capture',919,1,'2016-01-11 13:28:57',0,0,NULL),(144,'PTEN_TALL',1,'PTEN_TALL','PTEN_TALL.bed','Truseq','','PTEN','PTEN_TALL_primers.bed','PTEN',NULL,'pcr',919,1,'2015-11-17 14:36:04',0,0,NULL),(145,'DC3',1,'DC3','DC3.bed','Haloplex','','CDGDC','DC3_primers.bed','CDGDC',NULL,'pcr',919,1,'2015-11-23 13:28:08',0,0,NULL),(146,'agilent_58_v6',6,'agilent.58.v6','agilent.58.v6.bed','agilent','','','','exome',NULL,'capture',919,0,'2015-12-17 09:50:16',0,0,NULL),(147,'PARN',1,'parn','parn.bed','other','','PARN','parn.primers.bed','PARN',NULL,'capture',919,1,'2015-12-18 12:38:22',0,0,NULL),(148,'IRD',1,'Inherited Retinal Dystrophies','IRD.V1.hg19.bed','agilent','','IRD','IRD.V1.hg19_primers.bed','IRD',NULL,'capture',919,1,'2016-02-29 15:11:06',0,0,NULL),(149,'OneSeq',1,'exome et cnv','OneSeq.bed','agilent','','','','exome',NULL,'capture',919,0,'2015-12-29 13:14:54',0,0,NULL),(150,'AS_v2',2,'Avance Staturale panel Truseq version 2','AS_v2.bed','Truseq','','AS','AS_v2_primers.bed','AS',NULL,'pcr',919,1,'2016-01-08 09:34:37',0,0,NULL),(151,'agilent_v4_UTR',4,'agilent_v4_UTR','agilent_v4_UTR.bed','agilent','','','','exome',NULL,'capture',919,0,'2016-01-21 14:19:39',0,0,NULL),(152,'genome_hg19b',19,'full_genome hg19b','genome.bed','other','','','','genome',NULL,'capture',920,0,'2016-01-29 13:55:24',0,0,NULL),(153,'CDL_v2',1,'Cornelia De Lange v2','CDL_v2.bed','Truseq','','CD','CDL_v2_primers.bed','CD',NULL,'pcr',919,1,'2016-04-13 06:12:51',0,0,NULL),(154,'PID_V2',1,'PID_V2','PID_V2.bed','agilent','','DefIm','PID_V2.bed.primers','DefIm',NULL,'capture',919,1,'2016-06-24 13:05:54',0,0,NULL),(155,'Hypothyseq',1,'Hypothyseq','Hypothyseq.bed','agilent','','Hypothyseq','Hypothyseq_primers.bed','Hypothyseq',NULL,'capture',919,1,'2016-03-01 14:32:34',0,0,NULL),(156,'ATLv1',1,'ATLv1','ATLv1.bed','Truseq','','ATLv1','ATLv1_primers.bed','ATLv1',NULL,'pcr',919,1,'2016-04-26 11:07:20',0,0,NULL),(157,'uree_AO',1,'uree_AO','uree_AO.bed','Truseq','','ureeAO','uree_AO.bed.primers','ureeAO',NULL,'pcr',919,1,'2016-04-15 06:19:20',0,0,NULL),(158,'ADG-CDG-1',1,'ADG-CDG-1','ADG-CDG-1.bed','Haloplex','','CDGDC','ADG-CDG-1.bed.primers','CDGDC',NULL,'pcr',919,1,'2016-04-18 08:19:08',0,0,NULL),(159,'Hypothyseq_DYRK1a',1,'Hypothyseq et DYRK1a','Hypothyseq_DYRK1a.bed','agilent','','Hypothyseq','Hypothyseq_DYRK1a.bed.primers','Hypothyseq',NULL,'capture',919,1,'2016-04-25 07:09:34',0,0,NULL),(160,'MedExome_hg19',1,'MedExome_hg19','MedExome_hg19.bed','nimblegen','','','MedExome_hg19.bed.primers','exome',NULL,'capture',919,0,'2016-05-02 08:14:15',0,0,NULL),(161,'FSGS_v5_complPanel_Redesign9',1,'FSGS_v5_complPanel_Redesign9','FSGS_v5_complPanel_Redesign9.bed','multiplicom','','FSGS','FSGS_v5_complPanel_Redesign9.bed.primers','FSGS',NULL,'pcr',919,1,'2016-05-09 07:15:06',0,0,NULL),(162,'DC_design4',1,'DC_design4','DC_design4.bed','Haloplex','','CDGDC','DC_design4.bed.primers','CDGDC',NULL,'pcr',919,1,'2016-05-24 11:49:56',0,0,NULL),(163,'polycomb_v2',1,'polycomb_v2','polycomb_v2.bed','Truseq','','Polycomb','polycomb_v2.bed.primers','Polycomb',NULL,'pcr',919,1,'2016-06-02 06:50:04',0,0,NULL),(164,'amylose',1,'amylose','amylose.bed','Truseq','','Amylose','amylose.bed.primers','Amylose',NULL,'pcr',919,1,'0000-00-00 00:00:00',0,0,NULL),(165,'Vitreoretinopathies',1,'Vitreoretinopathies','Vitreoretinopathies.bed','AmpliSeq','','Vitreoretinopathies','Vitreoretinopathies.bed.primers','Vitreoretinopathies',NULL,'pcr',920,1,'2016-05-24 12:51:44',0,0,NULL),(166,'Panel_Commun',1,'Panel_commun','Panel_Commun.bed','other','','PanelCommun','Panel_Commun.bed.primers','PanelCommun',NULL,'capture',919,1,'2016-06-14 07:33:25',0,0,NULL),(167,'agilent_v5_UTR',1,'agilent_v5_UTR','agilent_v5_UTR.bed','agilent','','','','exome',NULL,'capture',919,0,'2016-06-30 07:24:02',0,0,NULL),(168,'ADG-CDG_design3',1,'ADG-CDG_design3','ADG-CDG_design3.bed','Haloplex','','CDGDC','ADG-CDG_design3.bed.primers','CDGDC',NULL,'pcr',919,1,'2016-07-04 08:12:42',0,0,NULL),(169,'MOC_V2',1,'MOC_V2','MOC_V2.bed','agilent','','MOC','MOC_V2.bed.primers','MOC',NULL,'capture',919,1,'2017-01-18 09:41:37',0,0,NULL),(170,'enteropathies_v2',1,'enteropathies_v2','enteropathies_v2.bed','agilent','','entheropathies','enteropathies_v2.bed.primers','entheropathies',NULL,'capture',919,1,'2016-09-08 13:03:13',0,0,NULL),(171,'cervelet',1,'cervelet','cervelet.bed','agilent','','cervelet','cervelet.bed.primers','cervelet',NULL,'capture',919,1,'2016-08-08 12:22:43',0,0,NULL),(172,'BAIT',1,'BAIT','BAIT.bed','agilent','','BAIT','BAIT.bed.primers','BAIT',NULL,'capture',919,1,'2016-09-16 13:20:26',0,0,NULL),(173,'DC_Nimblegen_design1',1,'DC_Nimblegen_design1','DC_Nimblegen_design1.bed','nimblegen','','CDGDC','DC_Nimblegen_design1.bed.primers','CDGDC',NULL,'capture',919,1,'2016-08-02 07:45:01',0,0,NULL),(174,'Panel_B_diag',1,'Panel_B_diag','Panel_B_diag.bed','Truseq','','Panel_B','Panel_B_diag.bed.primers','Panel_B',NULL,'pcr',919,1,'2016-08-02 08:38:57',0,0,NULL),(175,'niblegen_Myop_Duch',1,'myopathie de duchesne','niblegen_Myop_Duch.bed','nimblegen','','','','exome',NULL,'capture',919,0,'0000-00-00 00:00:00',0,0,NULL),(176,'rna_seq',82,'rnaseq','rna_seq.bed','other','','','','rnaseq',NULL,'capture',919,0,'2016-08-23 05:24:34',0,0,NULL),(177,'CFTR_DPNI_1',1,'CFTR_DPNI_1','CFTR_DPNI_1.bed','agilent','','CFTRDPNI','CFTR_DPNI_1.bed.primers','CFTRDPNI',NULL,'capture',919,1,'2016-08-23 06:56:09',0,0,NULL),(178,'Amylose-V2',1,'Amylose-V2','Amylose-V2.bed','Truseq','','Amylose','Amylose-V2.bed.primers','Amylose',NULL,'pcr',919,1,'2016-09-29 08:29:14',0,0,NULL),(179,'DysgenesieSegmentAnterieur-V1',1,'DysgenesieSegmentAnterieur-V1','DysgenesieSegmentAnterieur-V1.bed','Truseq','','DSA','DysgenesieSegmentAnterieur-V1.bed.primers','DSA',NULL,'pcr',919,1,'2016-10-28 06:13:51',0,0,NULL),(180,'Dystrophies_corneennes',1,' Dystrophies corneennes','DystrophieAmyloide-V1.bed','Truseq','','DystrophieAmyloide','DystrophieAmyloide-V1.bed.primers','DystrophieAmyloide',NULL,'pcr',919,1,'2016-09-29 10:21:12',0,0,NULL),(181,'TNGS_14_LCA_Genes',1,'TNGS_14_LCA_Genes','TNGS_14_LCA_Genes.bed','agilent','','14GenesOphtalmo','TNGS_14_LCA_Genes.bed.primers','14GenesOphtalmo',NULL,'capture',919,1,'2016-11-15 13:03:42',0,0,NULL),(182,'NMAT',1,'NMAT','NMAT.bed','baits_capture','','NMNAT','NMAT.bed.primers','NMNAT',NULL,'capture',919,1,'2016-09-01 12:07:50',0,0,NULL),(183,'truseq_exome_manifeste_v1-2',1,'exome truseq bichat','truseq_exome_manifeste_v1-2.bed','Truseq','','','','exome',NULL,'capture',919,0,'2016-09-05 13:32:14',0,0,NULL),(184,'Panel_T_V2_Capture',1,'Panel_T_V2_Capture','Panel_T_V2_Capture.bed','Nextera_rapid_capture','','PanelTv2','Panel_T_V2_Capture.bed.primers','PanelTv2',NULL,'capture',919,1,'2016-09-08 08:07:30',0,0,NULL),(185,'truseq_rapid_exome_v1_2',1,'exome truseq_rapid bichat','truseq_rapid_exome_v1_2.bed','Truseq','','','','exome',NULL,'capture',919,0,'2016-09-12 10:14:15',0,0,NULL),(186,'rnaseq_mm38',38,'rnase mouse','rnaseq_mm38.bed','other','','','','rnaseq',NULL,'capture',800,0,'2016-09-16 10:53:16',0,1,NULL),(187,'CD-3',1,'Cornelia De Lange version 3','CD-3.bed','Truseq','','CD','CD-3.bed.primers','CD',NULL,'pcr',919,1,'2016-09-16 11:23:15',0,0,NULL),(188,'L3_ADG_CDG_Nimb',1,'ADG-CDG-Nimblegen','ADG-CDG-Nimblegen.bed','nimblegen','','CDGDC','ADG-CDG-Nimblegen.bed.primers','CDGDC',NULL,'capture',919,1,'2016-09-19 09:57:30',0,0,NULL),(189,'semaphorine',1,'semaphorine','semaphorine.bed','baits_capture','','semaphorine','semaphorine.bed.primers','semaphorine',NULL,'capture',919,1,'2016-09-15 07:52:14',0,0,NULL),(190,'HBB-HBD',1,'HBB-HBD','HBB-HBD.bed','baits_capture','','HBBHBD','HBB-HBD.bed.primers','HBBHBD',NULL,'capture',919,1,'2016-09-21 05:49:47',0,0,NULL),(191,'niblegen_MyopDuch_XY',1,'MyopDuchenne_ChrXY','niblegen_MyopDuch_XY.bed','nimblegen','','DMD','niblegen_MyopDuch_XY.bed.primers','DMD',NULL,'capture',919,1,'2017-02-08 09:04:59',0,0,NULL),(192,'EVC2',1,'EVC2','EVC2.bed','baits_capture','','EVC2','EVC2.bed.primers','EVC2',NULL,'capture',919,1,'2016-10-10 12:54:22',0,0,NULL),(193,'OI_v4',1,'OI_v4','OI_TNGS_V1.bed','agilent','','OI','OI_TNGS_V1.bed.primers','OI',NULL,'capture',919,1,'2017-06-28 09:17:54',0,0,NULL),(194,'Genodermatoses_AH_V1',1,'Genodermatoses_AH_V1','Genodermatoses_AH_V1.bed','agilent','','Genodermatoses','Genodermatoses_AH_V1.bed.primers','Genodermatoses',NULL,'capture',919,1,'2017-01-02 12:55:53',0,0,NULL),(195,'FlexiBac_Chr8_S1_LABEL',1,'FlexiBac_Chr8_S1_LABEL','FlexiBac_Chr8_S1_LABEL.bed','other','','','FlexiBac_Chr8_S1_LABEL.bed.primers','default',NULL,'capture',919,1,'2016-10-25 12:43:25',0,0,NULL),(196,'Onco_MM1groupe',1,'Onco_MM1groupe','Onco_MM1groupe.bed','Haloplex','','OncoMM1groupe','Onco_MM1groupe.bed.primers','OncoMM1groupe',NULL,'pcr',919,1,'2016-11-23 09:40:06',0,0,NULL),(197,'Mitomev2',1,'Mitomev2','Mitomev2.bed','agilent','','Mitome','Mitomev2.bed.primers','Mitome',NULL,'capture',919,1,'2017-02-08 14:26:50',0,0,NULL),(198,'LyCoProme_V1',1,'LyCoProme_V1','LyCoProme_V1.bed','agilent','','LyCoProme','LyCoProme_V1.bed.primers','LyCoProme',NULL,'capture',919,1,'2017-06-12 08:07:20',0,0,NULL),(199,'cildiag',1,'cildiag','cildiag.bed','agilent','','CilDiag','cildiag.bed.primers','CilDiag',NULL,'capture',919,1,'2016-12-02 15:57:11',0,0,NULL),(200,'TUBB',1,'TUBB','TUBB.bed','baits_capture','','TUBB','TUBB.bed.primers','TUBB',NULL,'capture',919,1,'2016-12-19 14:54:14',0,0,NULL),(201,'EVC-EVC2',1,'EVC-EVC2','EVC-EVC2.bed','baits_capture','','EVC2','EVC-EVC2.bed.primers','EVC2',NULL,'capture',919,1,'2016-12-19 15:03:50',0,0,NULL),(202,'LysPur_V1',1,'LysPur_V1','LysPur_V1.bed','agilent','','LysPur','LysPur_V1.bed.primers','LysPur',NULL,'capture',919,1,'2017-06-16 11:32:31',0,0,NULL),(203,'callosome_v2D',1,'callosome_v2D','callosome_v2D.bed','agilent','','callosome','callosome_v2D.bed.primers','callosome',NULL,'capture',919,1,'2017-01-02 09:49:08',0,0,NULL),(204,'CallosomeV2R',1,'CallosomeV2R','CallosomeV2R.bed','agilent','','callosome','CallosomeV2R.bed.primers','callosome',NULL,'capture',919,1,'2017-01-09 14:17:51',0,0,NULL),(205,'DC_Design5',1,'DC_Design5','DC_Design5.bed','Haloplex','','CDGDC','DC_Design5.bed.primers','CDGDC',NULL,'pcr',919,1,'2017-01-25 09:24:01',0,0,NULL),(206,'CakutomeV2',1,'CakutomeV2','CakutomeV2.bed','agilent','','CakutomeBaits','CakutomeV2.bed.primers','CakutomeBaits',NULL,'capture',919,1,'2017-01-23 09:25:07',0,0,NULL),(208,'rn6',6,'rattus','rnaseq_rn6.bed','other','','','','rnaseq',NULL,'capture',500,0,'2017-02-01 14:27:13',0,1,NULL),(209,'IdFix_V2',1,'IdFix_V2','IdFix_V2.bed','agilent','','idefix','IdFix_V2.bed.primers','idefix',NULL,'capture',919,1,'2017-04-25 12:01:52',0,0,NULL),(210,'FlexiBAC_PIK3CA',1,'FlexiBAC_PIK3CA','FlexiBAC_PIK3CA.bed','BAC','','PIK3CA','FlexiBAC_PIK3CA.bed.primers','PIK3CA',NULL,'capture',919,1,'2017-02-20 15:31:49',0,0,NULL),(211,'FlexiBac_BRCA1',1,'FlexiBac_BRCA1','FlexiBac_BRCA1.bed','BAC','','BRCA1','FlexiBac_BRCA1.bed.primers','BRCA1',NULL,'capture',919,1,'2017-02-20 15:31:21',0,0,NULL),(212,'FlexiBAC_BLNK',1,'FlexiBAC_BLNK','FlexiBAC_BLNK.bed','BAC','','BLNK','FlexiBAC_BLNK.bed.primers','BLNK',NULL,'capture',919,1,'2017-02-20 15:25:49',0,0,NULL),(213,'FlexiBac_IL12RB1',1,'FlexiBac_IL12RB1','FlexiBac_IL12RB1.bed','BAC','','IL12RB1','FlexiBac_IL12RB1.bed.primers','IL12RB1',NULL,'capture',919,1,'2017-04-06 07:30:15',0,0,NULL),(214,'TUB_MASTR_V2',2,'tub_mastr','TUB_MASTR_V2.bed','AmpliSeq','','testdiag','TUB_MASTR_V2.bed.primers','testdiag',NULL,'pcr',919,1,'2017-02-22 12:10:35',0,0,NULL),(215,'alportmastr',1,'alportmastr gdansk','alportmastr.bed','multiplicom','','Alport','alportmastr.bed.primers','Alport',NULL,'pcr',919,1,'2017-03-02 15:10:42',0,0,NULL),(216,'BOY',1,'BOY','BOY.bed','other','','BOY','BOY.bed.primers','BOY',NULL,'capture',919,1,'2017-03-10 14:58:26',0,0,NULL),(217,'MCN_v2',1,'MCN_v2','MCN_v2.bed','agilent','','MCN','MCN_v2.bed.primers','MCN',NULL,'capture',919,1,'2017-07-20 06:22:16',0,0,NULL),(218,'GL_SL_design4',1,'GL_SL_design4','GL_SL_design4.bed','Haloplex','','ADC','GL_SL_design4.bed.primers','ADC',NULL,'pcr',919,1,'2017-04-04 13:18:10',0,0,NULL),(219,'EFL1',1,'EFL1','EFL1.bed','BAC','','EFL1','EFL1.bed.primers','EFL1',NULL,'capture',919,1,'2017-04-05 12:16:17',0,0,NULL),(220,'Chronic_Proteinuria_v1_hg19',1,'Chronic_Proteinuria_v1_hg19','Chronic_Proteinuria_v1_hg19.bed','agilent','','ChronicProteinuria','Chronic_Proteinuria_v1_hg19.bed.primers','ChronicProteinuria',NULL,'capture',919,1,'2017-09-06 06:27:36',0,0,NULL),(221,'RenomeV1',1,'RenomeV1','RenomeV1.bed','agilent','','renome','RenomeV1.bed.primers','renome',NULL,'capture',919,1,'2017-04-13 10:51:17',0,0,NULL),(222,'AS_capture_hg19_v1',1,'AS_capture_hg19_v1','AS_capture_hg19_v1.bed','agilent','','AS','AS_capture_hg19_v1.bed.primers','AS',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(223,'CD_capture_hg19_v1',1,'CD_capture_hg19_v1','CD_capture_hg19_v1.bed','agilent','','CD','CD_capture_hg19_v1.bed.primers','CD',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(224,'DC_design5bis',1,'DC_design5bis','DC_design5bis.bed','Haloplex','','CDGDC','DC_design5bis.bed.primers','CDGDC',NULL,'pcr',919,1,'2017-07-10 07:37:41',0,0,NULL),(225,'CD_AS_callingAS',1,'CD_AS_callingAS','CD_AS_callingAS.bed','agilent','','AS','CD_AS_callingAS.bed.primers','AS',NULL,'capture',919,1,'2017-05-05 07:34:00',0,0,NULL),(226,'CD_AS_callingCD',1,'CD_AS_callingCD','CD_AS_callingCD.bed','agilent','','CD','CD_AS_callingCD.bed.primers','CD',NULL,'capture',919,1,'2017-05-05 07:31:01',0,0,NULL),(227,'agilent_clinical_research_v2',2,'agilent.clinical.research.v2','agilent_clinical_research_v2.bed','agilent','','','agilent_clinical_research_v2.bed.primers','exome',NULL,'capture',919,0,'2017-05-12 12:28:44',0,0,NULL),(228,'Metabolisme_hepato',1,'Metabolisme_hepato','Metabolisme_hepato.bed','agilent','','MetaboHepato','Metabolisme_hepato.bed.primers','MetaboHepato',NULL,'capture',919,1,'2017-09-26 07:20:23',0,0,NULL),(230,'genome_hg19',1,'genome_hg19','genome_hg19.bed','other','','','','genome',NULL,'capture',919,0,'2017-05-19 08:55:44',0,0,NULL),(232,'ParaplegieSpastique',1,'ParaplegieSpastique','ParaplegieSpastique.bed','agilent','','ParaplegieStatique','ParaplegieSpastique.bed.primers','ParaplegieStatique',NULL,'capture',919,1,'2018-03-01 10:57:36',0,0,NULL),(233,'SCC_MT',1,'SCC_MT','SCC_MT.bed','agilent','','SCCMT','SCC_MT.bed.primers','SCCMT',NULL,'capture',919,1,'2018-11-23 10:28:08',0,0,NULL),(234,'syndromePierreRobin',1,'syndromePierreRobin','syndromePierreRobin.bed','BAC','','SPR','syndromePierreRobin.bed.primers','SPR',NULL,'capture',919,1,'2017-07-19 13:22:07',0,0,NULL),(235,'DC_haloplex_design6',1,'DC_haloplex_design6','DC_haloplex_design6.bed','Haloplex','','CDGDC','DC_haloplex_design6.bed.primers','CDGDC',NULL,'pcr',919,1,'2017-08-22 07:55:26',0,0,NULL),(236,'GL-SL-DESIGN2-NIMBLEGEN',1,'GL-SL-DESIGN2-NIMBLEGEN','GL-SL-DESIGN2-NIMBLEGEN.bed','nimblegen','','CDGDC','GL-SL-DESIGN2-NIMBLEGEN.bed.primers','CDGDC',NULL,'capture',919,1,'2017-08-16 12:14:32',0,0,NULL),(237,'PanelB-v2_diag',1,'PanelB-v2_diag','PanelB-v2_diag.bed','Truseq','','Panel_B','PanelB-v2_diag.bed.primers','Panel_B',NULL,'pcr',919,1,'2017-10-09 12:53:51',0,0,NULL),(238,'captureTestBichat',1,'testBichat','captureTestBichat.bed','nimblegen','','testBichat','captureTestBichat.bed.primers','testBichat',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(239,'agilent_v6_UTR',6,'agilent_v6_UTR','agilent_v6_UTR.bed','agilent','','','agilent_v6_UTR.bed.primers','exome',NULL,'capture',919,0,'2017-09-22 13:20:36',0,0,NULL),(240,'TSCA_NF_Tier2',1,'TSCA_NF_Tier2','TSCA_NF_Tier2.bed','other','','testdiag','TSCA_NF_Tier2.bed.primers','testdiag',NULL,'pcr',919,1,'2017-09-26 08:16:59',0,0,NULL),(241,'panelT_v3',1,'panelT_v3','panelT_v3.bed','Nextera_rapid_capture','','PanelTv2','panelT_v3.bed.primers','PanelTv2',NULL,'capture',919,1,'2017-10-17 12:30:37',0,0,NULL),(242,'Genestarget_Abel-V1-hg19_PolyDiag',1,'Genestarget_Abel-V1-hg19_PolyDiag','Genestarget_Abel-V1-hg19_PolyDiag.bed','agilent','','genestargetAbel','Genestarget_Abel-V1-hg19_PolyDiag.bed.primers','genestargetAbel',NULL,'capture',919,1,'2017-12-11 10:17:04',0,0,NULL),(243,'Halo_DC_design7',1,'Halo_DC_design7','Halo_DC_design7.bed','Haloplex','','CDGDC','Halo_DC_design7.bed.primers','CDGDC',NULL,'pcr',919,1,'2017-11-17 08:08:30',0,0,NULL),(244,'Ion-TargetSeq-Exome-50Mb-hg19_revA',1,'Ion-TargetSeq-Exome-50Mb-hg19_revA','Ion-TargetSeq-Exome-50Mb-hg19_revA.bed','targetseq','','','Ion-TargetSeq-Exome-50Mb-hg19_revA.bed.primer','exome',NULL,'capture',919,0,'2017-12-08 13:07:15',0,0,NULL),(245,'PMDA',1,'PMDA','PMDA.bed','agilent','','MvtDis','PMDA.bed.primers','MvtDis',NULL,'capture',919,1,'2017-12-15 07:38:07',0,0,NULL),(246,'Genodermatoses_AH_V2',1,'Genodermatoses_AH_V2','Genodermatoses_AH_V2.bed','agilent','','Genodermatoses','Genodermatoses_AH_V2.bed.primers','Genodermatoses',NULL,'capture',919,1,'2018-04-24 15:36:01',0,0,NULL),(247,'transcriptome_10X',1,'transcriptome_10X','transcriptome_10X.bed','other','','','','singlecell',NULL,'capture',938,0,'2018-01-25 13:55:30',0,1,NULL),(248,'enteropathiesV3',1,'enteropathiesV3','enteropathiesV3.bed','agilent','','entheropathies','enteropathiesV3.bed.primers','entheropathies',NULL,'capture',919,1,'2018-01-23 15:32:53',0,0,NULL),(249,'DU_Ampliseq',1,'DU','DU_Ampliseq.bed','AmpliSeq','','DU','DU_Ampliseq.bed.primers','DU',NULL,'pcr',919,1,'2018-01-24 21:22:16',0,0,NULL),(250,'DU_Illumina',1,'DU','DU_Illumina.bed','AmpliSeq','','DU','','DU',NULL,'capture',919,1,'2018-01-24 21:48:31',0,0,NULL),(251,'FlexiBAC_PIK3CA-KRT',1,'FlexiBAC_PIK3CA-KRT','FlexiBAC_PIK3CA-KRT.bed','BAC','','PIK3CA','FlexiBAC_PIK3CA-KRT.bed.primers','PIK3CA',NULL,'capture',919,1,'2018-02-12 15:08:58',0,0,NULL),(252,'Danio_rerio',10,'Danio_Rerio','Danio_rerio.bed','other','','','','rnaseq',NULL,'capture',910,0,'2018-02-16 09:00:07',0,0,NULL),(253,'WAI',1,'WAI','WAI.bed','other','','','WAI.bed.primers','exome',NULL,'pcr',666,0,'2018-02-20 15:25:10',0,0,NULL),(254,'RenomeV2hg19',1,'Renome.V2.hg19','RenomeV2hg19.bed','agilent','','renome','RenomeV2hg19.bed.primers','renome',NULL,'capture',919,1,'2018-04-18 13:59:09',0,0,NULL),(255,'ABCA4',1,'ABCA4','ABCA4.bed','agilent','','ABCA4','ABCA4.bed.primers','ABCA4',NULL,'capture',919,1,'2018-05-15 12:36:48',0,0,NULL),(256,'AgilentOneSeqCible',1,'AgilentOneSeqCible','AgilentOneSeqCible.bed','agilent','','AgilentOneSeqCible','AgilentOneSeqCible.bed.primers','AgilentOneSeqCible',NULL,'capture',919,1,'2018-02-26 15:01:11',0,0,NULL),(257,'Halo_DC_design8',1,'Halo_DC_design8','Halo_DC_design8.bed','Haloplex','','CDGDC','Halo_DC_design8.bed.primers','CDGDC',NULL,'pcr',919,1,'2018-03-19 13:09:12',0,0,NULL),(258,'genome_hg19c',19,'full_genome hg19c','genome.bed','other','','','','genome',NULL,'capture',921,0,'2019-01-17 10:29:36',0,0,NULL),(259,'rna_seq_HG38',1,'rna_seq_HG38','rna_seq_HG38.bed','other','','','rna_seq_HG38.bed.primers','rnaseq',NULL,'capture',938,0,'2018-03-15 15:29:04',0,1,NULL),(260,'lnc_rna_HG38',1,'lnc_rna_HG38','lnc_rna_HG38.bed','other','','','lnc_rna_HG38.bed.primers','rnaseq',NULL,'capture',939,0,'2018-03-21 19:10:37',0,0,NULL),(261,'GL-SL-DESIGN3-NIMBLEGEN',1,'GL-SL-DESIGN3-NIMBLEGEN','GL-SL-DESIGN3-NIMBLEGEN.bed','nimblegen','','CDGDC','GL-SL-DESIGN3-NIMBLEGEN.bed.primers','CDGDC',NULL,'capture',919,1,'2018-04-09 12:03:43',0,0,NULL),(262,'IRD-v2',1,'IRD-v2','IRD-v2.bed','agilent','','IRD','IRD-v2.bed.primers','IRD',NULL,'capture',919,1,'2018-07-05 14:46:27',0,0,NULL),(263,'MM38-ERCC',1,'MM38-ERCC','MM38-ERCC.bed','other','','','MM38-ERCC.bed.primers','rnaseq',NULL,'capture',922,0,'2018-04-17 11:02:11',0,0,NULL),(264,'test2',2,'test','test2.bed','agilent','','','','exome',NULL,'capture',919,0,'2020-03-12 17:10:53',0,0,NULL),(265,'hirschprome1bis',1,'hirschprome1bis','hirschprome1bis.bed','agilent','','Hirschprome','hirschprome1bis.bed.primers','Hirschprome',NULL,'capture',919,1,'2018-04-20 09:11:48',0,0,NULL),(266,'TSC2-TSC1',1,'TSC2-TSC1','TSC2-TSC1.bed','BAC','','TSC2TSC1','TSC2-TSC1.bed.primers','TSC2TSC1',NULL,'capture',919,1,'2018-04-20 09:51:19',0,0,NULL),(267,'twist',1,'twist','twist.bed','other','','','twist.bed.primers','exome',NULL,'capture',919,0,'2018-05-22 14:48:50',0,0,NULL),(268,'test_chrUn',1,'test_ChrUn','test_chrUn.bed','other','','','','exome',NULL,'capture',919,0,'0000-00-00 00:00:00',0,0,NULL),(269,'Omim',1,'Omim','Omim.bed','other','','','Omim.bed.primers','exome',NULL,'capture',919,0,'0000-00-00 00:00:00',0,0,NULL),(270,'Omim_hg38',1,'Omim_hg38','Omim_hg38.bed','other','','','Omim_hg38.bed.primers','exome',NULL,'capture',938,0,'0000-00-00 00:00:00',0,0,NULL),(271,'ComplementDisorders_v2',1,'ComplementDisorders_v2','ComplementDisorders_v2.bed','multiplicom','','CompDisorders','ComplementDisorders_v2.bed.primers','CompDisorders',NULL,'pcr',919,1,'2018-05-30 11:16:41',0,0,NULL),(272,'xgen-idt-exome',1,'xgen-idt-exome','xgen-idt-exome.bed','illumina','','','xgen-idt-exome.bed.primers','exome',NULL,'capture',919,0,'2018-06-11 07:15:48',0,0,NULL),(273,'IL10RB',1,'IL10RB','IL10RB.bed','BAC','','IL10RB','IL10RB.bed.primers','IL10RB',NULL,'capture',919,1,'2018-06-04 15:13:48',0,0,NULL),(274,'RTE3',1,'RTE3','RTE3.bed','Qiagen_pcr','','RTE3','RTE3.bed.primers','RTE3',NULL,'pcr',919,1,'2018-06-05 15:17:19',0,0,NULL),(275,'mini_IdFix',1,'mini_IdFix','mini_IdFix.bed','agilent','','idefix','mini_IdFix.bed.primers','idefix',NULL,'capture',919,1,'2018-10-04 09:18:27',0,0,NULL),(276,'OncoB_UMI',1,'OncoB_UMI','OncoB_UMI.bed','Qiagen_pcr','','Panel_B','OncoB_UMI.bed.primers','Panel_B',NULL,'pcr',919,1,'2018-06-25 10:14:28',0,0,NULL),(277,'agilent_v7',7,'agilent_v7','agilent_v7.bed','agilent','','','agilent_v7.bed.primers','exome',NULL,'capture',919,0,'2018-07-10 13:42:04',0,0,NULL),(278,'COHEN',1,'COHEN','COHEN.bed','other','','','COHEN.bed.primers','exome',NULL,'capture',923,0,'2018-07-06 15:16:12',0,0,NULL),(280,'Amyloses_V1_hg19',1,'Amyloses_V1_hg19','Amyloses_V1_hg19.bed','agilent','','Amylose','Amyloses_V1_hg19.bed.primers','Amylose',NULL,'capture',919,1,'2019-01-16 15:07:00',0,0,NULL),(281,'SPRUES',1,'SPRUES','SPRUES.bed','Qiagen_pcr','','SPRUES','SPRUES.bed.primers','SPRUES',NULL,'pcr',919,1,'2018-08-08 08:37:41',0,0,NULL),(282,'EGR',1,'EGR','EGR.bed','other','','','EGR.bed.primers','exome',NULL,'capture',800,0,'2018-07-23 13:49:18',0,0,NULL),(283,'IdFix-V3_hg19',1,'IdFix-V3_hg19','IdFix-V3_hg19.bed','agilent','','idefix','IdFix-V3_hg19.bed.primers','idefix',NULL,'capture',919,1,'2018-09-19 12:48:29',0,0,NULL),(284,'ALPORTMASTR_2018',1,'ALPORTMASTR_2018','ALPORTMASTR_2018.bed','multiplicom','','Alport','ALPORTMASTR_2018.bed.primers','Alport',NULL,'pcr',919,1,'2018-07-26 10:16:01',0,0,NULL),(285,'MSMD_CMC',1,'MSMD_CMC','MSMD_CMC.bed','agilent','','MSMDCMC','MSMD_CMC.bed.primers','MSMDCMC',NULL,'capture',919,1,'2018-10-31 10:59:51',0,0,NULL),(286,'DIPAI',1,'DIPAI','DIPAI.bed','agilent','','DIPAI','DIPAI.bed.primers','DIPAI',NULL,'capture',919,1,'2018-08-06 12:42:24',0,0,NULL),(287,'xgen-idt-exome-research-panel',2,'xgen-idt-exome-research-panel','xgen-idt-exome-research-panel.bed','illumina','','','xgen-idt-exome-research-panel.bed.primers','exome',NULL,'capture',919,0,'2018-08-10 09:29:29',0,0,NULL),(288,'MOC_V3',1,'MOC_V3','MOC_V3.bed','agilent','','MOC','MOC_V3.bed.primers','MOC',NULL,'capture',919,1,'2018-11-13 09:29:34',0,0,NULL),(289,'KTR1_10_DYRK1a',1,'KTR1_10_DYRK1a','KTR1_10_DYRK1a.bed','other','','Keratine','KTR1_10_DYRK1a.bed.primers','Keratine',NULL,'capture',919,1,'2018-10-01 09:25:16',0,0,NULL),(290,'FlexiBac_BRCA1_FSGS_v5_initial',1,'FlexiBac_BRCA1_FSGS_v5_initial','FlexiBac_BRCA1_FSGS_v5_initial.bed','BAC','','FSGS','FlexiBac_BRCA1_FSGS_v5_initial.bed.primers','FSGS',NULL,'capture',919,1,'2018-09-27 16:20:06',0,0,NULL),(291,'FGF3',1,'FGF3','FGF3.bed','BAC','','FGF3','FGF3.bed.primers','FGF3',NULL,'capture',919,1,'2018-10-31 11:17:01',0,0,NULL),(324,'Twist_plus',2,'Twist_plus','Twist_plus.bed','other','','','Twist_plus.bed.primers','exome',NULL,'capture',919,0,'2018-10-26 13:36:14',0,0,NULL),(325,'XT_HS_HEGP_Onco',1,'XT_HS_HEGP_Onco','XT_HS_HEGP_Onco.bed','agilent','','XT_HS_HEGP_Onco','','XT_HS_HEGP_Onco',NULL,'capture',919,1,'2018-10-22 13:02:10',0,0,NULL),(326,'RenomeV2_BIS_3172891',1,'RenomeV2_BIS_3172891','RenomeV2_BIS_3172891.bed','agilent','','renome','RenomeV2_BIS_3172891.bed.primers','renome',NULL,'capture',919,1,'2019-01-21 10:34:21',0,0,NULL),(327,'Surdites_V1',1,'Surdites_V1','Surdites_V1.bed','agilent','','Surdite','Surdites_V1.bed.primers','Surdite',NULL,'capture',919,1,'2018-10-29 15:37:46',0,0,NULL),(328,'PIK3CA_Twist_V2',1,'PIK3CA_Twist_V2','PIK3CA_Twist_V2.bed','BAC','','PIK3CA','PIK3CA_Twist_V2.bed.primers','PIK3CA',NULL,'capture',919,1,'2018-10-31 11:14:03',0,0,NULL),(329,'oncoT_agilent',1,'oncoT_agilent','oncoT_agilent.bed','agilent','','PanelTv2','oncoT_agilent.bed.primers','PanelTv2',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(330,'DC_nimblegen_design2',1,'DC_nimblegen_design2','DC_nimblegen_design2.bed','nimblegen','','CDGDC','DC_nimblegen_design2.bed.primers','CDGDC',NULL,'capture',919,1,'2018-11-12 13:12:12',0,0,NULL),(331,'HBG',1,'HBG','HBG.bed','other','','HBG','HBG.bed.primers','HBG',NULL,'capture',924,1,'2018-11-09 16:28:56',0,0,NULL),(332,'SBDS_EFL1_p53_EIF6',1,'SBDS_EFL1_p53_EIF6','SBDS_EFL1_p53_EIF6.bed','other','','EFL1','SBDS_EFL1_p53_EIF6.bed.primers','EFL1',NULL,'capture',919,1,'2018-11-13 16:28:10',0,0,NULL),(333,'agilent_58_v6_r2',2,'agilent.58.v6.r2','agilent_58_v6_r2.bed','agilent','','','agilent_58_v6_r2.bed.primers','exome',NULL,'capture',919,0,'2018-11-30 10:59:32',0,0,NULL),(334,'DMPK1',1,'DMPK1','DMPK1.bed','BAC','','DMPK1','DMPK1.bed.primers','DMPK1',NULL,'capture',919,1,'2018-12-14 09:57:11',0,0,NULL),(335,'sysid',1,'sysid','sysid.bed','other','','','sysid.bed.primers','exome',NULL,'capture',919,0,'0000-00-00 00:00:00',0,1,NULL),(336,'panelT_nextflex',1,'panelT_nextflex','panelT_nextflex.bed','agilent','','PanelTv2','panelT_nextflex.bed.primers','PanelTv2',NULL,'capture',919,1,'2019-01-23 16:16:08',0,0,NULL),(337,'renome_twist_v3',1,'renome_twist_v3','renome_twist_v3.bed','agilent','','renome','renome_twist_v3.bed.primers','renome',NULL,'capture',919,1,'2019-03-22 07:54:58',0,0,NULL),(338,'LysPurV1',1,'LysPurV1','LysPurV1.bed','agilent','','LysPur','LysPurV1.bed.primers','LysPur',NULL,'capture',925,1,'2019-01-30 10:40:35',0,0,NULL),(339,'Panel_commun_v2',1,'Panel_commun_v2','Panel_commun_v2.bed','agilent','','PanelCommun','Panel_commun_v2.bed.primers','PanelCommun',NULL,'capture',919,1,'2019-02-21 16:28:06',0,0,NULL),(340,'MUC1_HG38',1,'MUC1_HG38','MUC1_HG38.bed','agilent','','renome','MUC1_HG38.bed.primers','renome',NULL,'capture',938,1,'2019-02-27 10:07:11',0,0,NULL),(341,'SLC26A4',1,'SLC26A4','SLC26A4.bed','BAC','','SLC26A4','SLC26A4.bed.primers','SLC26A4',NULL,'capture',919,1,'2019-02-28 16:28:10',0,0,NULL),(342,'UL14',1,'UL14','UL14.bed','other','','EFL1','UL14.bed.primers','EFL1',NULL,'pcr',919,1,'2019-03-08 15:07:03',0,0,NULL),(343,'SBDS_EFL1_p53_EIF6_UL14',1,'SBDS_EFL1_p53_EIF6_UL14','SBDS_EFL1_p53_EIF6_UL14.bed','other','','EFL1','SBDS_EFL1_p53_EIF6_UL14.bed.primers','EFL1',NULL,'capture',919,1,'2019-02-28 13:45:43',0,0,NULL),(344,'OFT',1,'OFT','','other','','test','','amplicon',NULL,'capture',900,34,'2018-08-04 21:28:35',0,1,NULL),(345,'JAG1',1,'JAG1','JAG1.bed','BAC','','JAG1','JAG1.bed.primers','JAG1',NULL,'capture',919,1,'2019-03-13 14:27:52',0,0,NULL),(346,'transcriptome_10X_mm38',1,'transcriptome_10X_mm38','','other','','rnaseq','','singlecell',NULL,'capture',800,0,'2019-03-18 11:02:29',0,1,NULL),(347,'Segment_Anterieur_Oeil_V1',1,'Segment_Anterieur_Oeil.V1','Segment_Anterieur_Oeil_V1.bed','agilent','','SegmentAnterieurOeilV1','Segment_Anterieur_Oeil_V1.bed.primers','SegmentAnterieurOeilV1',NULL,'capture',919,1,'2019-04-19 09:58:25',0,0,NULL),(348,'Genes_empreinte',1,'Genes_empreinte','Genes_empreinte.bed','other','','','Genes_empreinte.bed.primers','exome',NULL,'capture',919,0,'0000-00-00 00:00:00',0,0,NULL),(349,'Hypothyseq_V2',1,'Hypothyseq_V2','Hypothyseq_V2.bed','agilent','','Hypothyseq','Hypothyseq_V2.bed.primers','Hypothyseq',NULL,'capture',919,1,'2019-03-27 10:04:21',0,0,NULL),(350,'AKT1',1,'FlexiBac_AKT1','AKT1.bed','BAC','','AKT1','AKT1.bed.primers','AKT1',NULL,'capture',919,1,'2019-04-11 09:07:40',0,0,NULL),(351,'NIPBL',1,'Flexibac_NIPBL','NIPBL.bed','BAC','','NIPBL','NIPBL.bed.primers','NIPBL',NULL,'capture',919,1,'2019-04-11 08:49:10',0,0,NULL),(352,'MitomeV2bis',1,'MitomeV2bis','MitomeV2bis.bed','agilent','','Mitome','MitomeV2bis.bed.primers','Mitome',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(353,'Pole1',1,'Pole1','Pole1.bed','other','','Pole1','Pole1.bed.primers','Pole1',NULL,'pcr',919,1,'2019-05-09 08:26:06',0,0,NULL),(354,'GLSLDESIGN4_nimblegen',1,'GLSLDESIGN4_nimblegen','GLSLDESIGN4.bed','nimblegen','','CDGDC','GLSLDESIGN4.bed.primers','CDGDC',NULL,'capture',919,1,'2019-05-22 11:37:55',0,0,NULL),(355,'PID',1,'PID','PID.bed','other','','PID','PID.bed.primers','PID',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(356,'OncoB_Fusion_Qiaseq_UMI',1,'OncoB_Fusion_Qiaseq_UMI','OncoB_Fusion_Qiaseq_UMI.bed','Qiagen_pcr','','Panel_B','OncoB_Fusion_Qiaseq_UMI.bed.primers','Panel_B',NULL,'pcr',919,1,'2019-07-01 13:23:38',0,0,NULL),(357,'CLOVES_QIAGEN_UMI',1,'CLOVES_QIAGEN_UMI','CLOVES_QIAGEN_UMI.bed','Qiagen_pcr','','CLOVES','CLOVES_QIAGEN_UMI.bed.primers','CLOVES',NULL,'pcr',919,1,'2019-07-11 10:18:34',0,0,NULL),(358,'T-ALL_Diag_REc_Qiaseq_UMI',1,'T-ALL_Diag_REc_Qiaseq_UMI','T-ALL_Diag_REc_Qiaseq_UMI.bed','Qiagen_pcr','','TALL','T-ALL_Diag_REc_Qiaseq_UMI.bed.primers','TALL',NULL,'pcr',919,1,'2019-08-12 15:03:52',0,0,NULL),(359,'Twist_integragen',1,'Twist_integragen','Twist_integragen.bed','other','','','Twist_integragen.bed.primers','exome',NULL,'capture',919,0,'2019-07-11 09:23:48',0,0,NULL),(360,'TNFRSF9',1,'TNFRSF9','TNFRSF9.bed','other','','TNFRSF9','TNFRSF9.bed.primers','TNFRSF9',NULL,'pcr',919,1,'2019-07-16 07:27:38',0,0,NULL),(361,'XIAP',1,'XIAP','XIAP.bed','BAC','','XIAP','XIAP.bed.primers','XIAP',NULL,'capture',919,1,'2019-09-12 08:18:34',0,0,NULL),(362,'genodermatose_v3',1,'genodermatose_v3','genodermatose_v3.bed','agilent','','Genodermatoses','genodermatose_v3.bed.primers','Genodermatoses',NULL,'capture',919,1,'2019-10-20 07:18:13',0,0,NULL),(363,'IdFix-V3_UFGM_hg19',1,'IdFix-V3_UFGM_hg19','IdFix-V3_UFGM_hg19.bed','agilent','','idefix','IdFix-V3_UFGM_hg19.bed.primers','idefix',NULL,'capture',919,1,'2020-02-20 14:52:47',0,0,NULL),(364,'OncoB_reduit_Qiaseq_UMI',1,'OncoB_reduit_Qiaseq_UMI','OncoB_reduit_Qiaseq_UMI.bed','Qiagen_pcr','','Panel_B','OncoB_reduit_Qiaseq_UMI.bed.primers','Panel_B',NULL,'pcr',919,1,'2019-09-04 08:51:50',0,0,NULL),(365,'MitomeV2bis_hg19_ADNnc',1,'MitomeV2bis_hg19_ADNnc','MitomeV2bis_hg19_ADNnc.bed','agilent','','Mitome','MitomeV2bis_hg19_ADNnc.bed.primers','Mitome',NULL,'capture',919,1,'2019-08-05 09:21:56',0,1,NULL),(366,'MitomeV2bis_hg19_ADNmt',1,'MitomeV2bis_hg19_ADNmt','MitomeV2bis_hg19_ADNmt.bed','other','','Mitome','MitomeV2bis_hg19_ADNmt.bed.primers','Mitome',NULL,'capture',901,1,'2019-08-05 09:28:08',0,1,NULL),(367,'KIT',1,'deletion KIT','KIT.bed','other','','KIT','KIT.bed.primers','KIT',NULL,'pcr',919,1,'2019-07-19 13:04:45',0,0,NULL),(368,'rnaseq_mm38_gfp',38,'rnaseq mouse gfp','','other','','rnaseq','','rnaseq',NULL,'capture',800,0,'2019-09-20 06:45:48',0,0,NULL),(369,'EBV_HLH_V1',1,'EBV_HLH_V1','EBV_HLH_V1.bed','agilent','','EBV_HLH','EBV_HLH_V1.bed.primers','EBV_HLH',NULL,'capture',919,3,'2020-01-08 10:27:34',0,0,NULL),(370,'MUC1_120mers_sans7-7',1,'MUC1_120mers_sans7-7','MUC1_120mers_sans7-7.bed','other','','','MUC1_120mers_sans7-7.bed.primers','renome',NULL,'capture',950,1,'2019-09-30 16:09:56',0,0,NULL),(371,'TL_Nimblegen_design3',1,'TL_Nimblegen_design3','TL_Nimblegen_design3.bed','nimblegen','','CDGDC','TL_Nimblegen_design3.bed.primers','CDGDC',NULL,'capture',919,1,'2020-01-20 11:21:39',0,0,NULL),(372,'CLOVES_AGILENT_UMI',1,'CLOVES_AGILENT_UMI','CLOVES_AGILENT_UMI.bed','agilent','','CLOVES','CLOVES_AGILENT_UMI.bed.primers','CLOVES',NULL,'capture',919,1,'2019-11-04 13:30:33',0,0,NULL),(373,'identitovigilance',1,'identitovigilance','identitovigilance.bed','other','','identitovigilance','identitovigilance.bed.primers','identitovigilance',NULL,'capture',919,1,'0000-00-00 00:00:00',0,0,NULL),(374,'LysPur_V2',1,'LysPur_V2','LysPur_V2.bed','agilent','','LysPur','LysPur_V2.bed.primers','LysPur',NULL,'capture',919,1,'2020-01-10 15:23:03',0,1,NULL),(375,'WSB1',1,'WSB1','WSB1.bed','other','','WSB1','WSB1.bed.primers','WSB1',NULL,'pcr',919,1,'2019-12-03 08:49:02',0,0,NULL),(376,'CilbrainV1',1,'CilbrainV1','CilbrainV1.bed','agilent','','CilbrainV1','CilbrainV1.bed.primers','CilbrainV1',NULL,'capture',919,3,'2019-12-10 13:02:54',0,0,NULL),(377,'MCN-v3',1,'MCN-v3_twist','MCN-v3.bed','twist','','MCN','MCN-v3.bed.primers','MCN',NULL,'capture',919,1,'2019-12-18 16:22:22',0,0,NULL),(378,'AMH-AMHR2',1,'AMH-AMHR2','AMH-AMHR2.bed','BAC','','AMHAMHR2','AMH-AMHR2.bed.primers','AMHAMHR2',NULL,'capture',919,1,'2020-02-06 16:19:34',0,0,NULL),(379,'Twist_RefSeq_CeGaT',1,'Twist_Human_Core_Exome_enrichment_kit_CeGaT','Twist_RefSeq_CeGaT.bed','twist','','','Twist_RefSeq_CeGaT.bed.primers','exome',NULL,'capture',919,0,'2019-12-19 14:18:10',0,0,NULL),(380,'renome_twist_v4',1,'renome_twist_v4','renome_twist_v4.bed','twist','','renome','renome_twist_v4.bed.primers','renome',NULL,'capture',919,1,'2020-01-14 10:58:34',0,0,NULL),(381,'genome_hg38',1,'genome_hg38','genome_hg38.bed','other','','','','genome',NULL,'capture',938,0,'2019-04-15 09:42:43',0,1,NULL),(382,'Dermatome_V2_Twist_hg19',1,'Dermatome_V2_Twist_hg19','Dermatome_V2_Twist_hg19.bed','twist','','dermatome','Dermatome_V2_Twist_hg19.bed.primers','dermatome',NULL,'capture',919,33,'2020-05-20 08:37:37',0,0,NULL),(383,'PID_v3',1,'PID_v3_twist','PID_v3.bed','twist','','PID','PID_v3.bed.primers','PID',NULL,'capture',919,3,'2020-03-13 11:04:23',0,0,NULL),(384,'IdFix-V4_IME_hg19',1,'IdFix.V4_IME.hg19','IdFix-V4_IME_hg19.bed','agilent','','idefix','IdFix-V4_IME_hg19.bed.primers','idefix',NULL,'capture',919,33,'2020-04-10 15:45:00',0,0,NULL),(385,'OncoT_V4',1,'OncoT_V4','OncoT_V4.bed','agilent','','PanelTv2','OncoT_V4.bed.primers','PanelTv2',NULL,'capture',919,1,'2020-05-14 10:07:33',0,0,NULL),(386,'BAC_DOCK8',1,'BAC_DOCK8','BAC_DOCK8.bed','BAC','','DOCK8','BAC_DOCK8.bed.primers','DOCK8',NULL,'capture',919,3,'2020-05-25 09:34:26',0,0,NULL),(387,'EnteropathiesV4',1,'EnteropathiesV4','EnteropathiesV4.bed','agilent','','entheropathies','EnteropathiesV4.bed.primers','entheropathies',NULL,'capture',919,33,'0000-00-00 00:00:00',0,0,NULL),(388,'BONEome',1,'BONEome','BONEome.bed','twist','','BONEome','BONEome.bed.primers','BONEome',NULL,'capture',919,4,'2020-06-05 15:37:33',0,0,NULL),(389,'DIH_V4',1,'DIH_V4','DIH_V4.bed','twist','','DefIm','DIH_V4.bed.primers','DefIm',NULL,'capture',919,33,'2020-07-22 14:36:34',0,0,NULL),(390,'CLOVES_AGILENT_UMI_V2',2,'CLOVES_AGILENT_UMI_V2','CLOVES_AGILENT_UMI_V2.bed','agilent','','CLOVES','CLOVES_AGILENT_UMI_V2.bed.primers','CLOVES',NULL,'capture',919,1,'2020-07-27 06:44:19',1,0,NULL),(391,'MCN_v4',4,'MCN_v4','MCN_v4.bed','agilent','','MCN','MCN_v4.bed.primers','MCN',NULL,'capture',919,1,'2020-08-05 14:55:56',0,0,NULL),(392,'panel_rapide1',1,'panel_rapide1','panel_rapide1.bed','twist','','panelrapid1','panel_rapide1.bed.primers','panelrapid1',NULL,'capture',919,1,'2020-08-28 14:00:46',0,0,NULL),(393,'panel_rapide2',1,'panel_rapide2','panel_rapide2.bed','twist','','panelrapid2','panel_rapide2.bed.primers','panelrapid2',NULL,'capture',919,1,'2020-08-28 14:10:38',0,0,NULL),(394,'panel_rapide2_chrM',1,'panel_rapide2_chrM','panel_rapide2_chrM.bed','other','','panelrapid2','panel_rapide2_chrM.bed.primers','panelrapid2',NULL,'capture',901,1,'2020-09-01 12:55:04',0,0,NULL),(395,'Danio_Rerio_11',1,'Danio_Rerio_11','Danio_Rerio_11.bed','other','','','Danio_Rerio_11.bed.primers','genome',NULL,'capture',911,0,'2020-10-09 11:05:44',0,0,NULL),(396,'genome_hg19_cng',1,'hg19_cng','genome_hg19_cng.bed','other','','','','genome',NULL,'capture',929,0,'2020-10-13 08:37:44',0,1,NULL),(397,'onco-T-v5',1,'onco-T-v5','onco-T-v5.bed','agilent','','PanelTv2','onco-T-v5.bed.primers','PanelTv2',NULL,'capture',919,1,'2020-10-13 09:33:58',0,0,NULL),(398,'panel_NTI',1,'panel_NTI','panel_NTI.bed','twist','','renome','panel_NTI.bed.primers','renome',NULL,'capture',919,1,'2020-10-15 10:49:42',0,0,NULL),(399,'GLSLTL_V1_NIMB',1,'GLSLTL_V1_NIMB','GLSLTL_V1_NIMB.bed','nimblegen','','CDGDC','GLSLTL_V1_NIMB.bed.primers','CDGDC',NULL,'capture',919,1,'2020-10-19 09:10:46',0,0,NULL),(400,'LysPur_V2_bis',1,'LysPur_V2_bis','LysPur_V2_bis.bed','agilent','','LysPur','LysPur_V2_bis.bed.primers','LysPur',NULL,'capture',919,3,'2020-10-20 10:19:48',0,1,NULL),(401,'enteropathie_v4_bis',1,'enteropathie_v4_bis','enteropathie_v4_bis.bed','agilent','','entheropathies','enteropathie_v4_bis.bed.primers','entheropathies',NULL,'capture',919,33,'2020-10-21 14:18:21',0,0,NULL),(402,'human-mouse-10X',1,'human-mouse-10X','human-mouse-10X.bed','other','','','','singlecell',NULL,'capture',850,0,'2020-10-22 19:22:53',0,0,NULL),(403,'mouse_egfp_dsRed',1,'mouse_egfp_dsRed','','other','','','','singlecell',NULL,'capture',930,0,'2020-11-02 14:45:51',0,0,NULL),(404,'TNGS_14_LCA_Genes-bis',1,'TNGS_14_LCA_Genes-bis','TNGS_14_LCA_Genes-bis.bed','agilent','','14GenesOphtalmo','TNGS_14_LCA_Genes-bis.bed.primers','14GenesOphtalmo',NULL,'capture',919,1,'2020-11-06 08:39:14',0,0,NULL),(405,'diag_rechute_mathieu',1,'diag_rechute_mathieu','diag_rechute_mathieu.bed','Qiagen_pcr','','TALL','diag_rechute_mathieu.bed.primers','TALL',NULL,'capture',919,1,'2020-11-20 09:29:19',0,0,NULL),(406,'rna_hg38_ercc',1,'rna_hg38_ercc','','other','','','','rnaseq',NULL,'capture',941,0,'2020-11-23 13:48:32',0,0,NULL),(407,'Felis_catus_9',1,'Felis_catus_9','Felis_catus_9.bed','other','','','','genome',NULL,'capture',604,0,'2020-12-01 14:49:34',0,0,NULL),(408,'DIH_v5',1,'DIH_v5','DIH_v5.bed','twist','','DefIm','DIH_v5.bed.primers','DefIm',NULL,'capture',919,34,'2020-12-01 15:25:31',0,0,NULL),(409,'RAPID1_V2',2,'RAPID1_V2','RAPID1_V2.bed','twist','','panelrapid1','RAPID1_V2.bed.primers','panelrapid1',NULL,'capture',919,1,'2020-12-15 17:49:11',0,0,NULL),(410,'RAPID2_V2',2,'RAPID2_V2','RAPID2_V2.bed','twist','','panelrapid2','RAPID2_V2.bed.primers','panelrapid2',NULL,'capture',919,1,'2020-12-15 17:57:33',0,0,NULL),(411,'IRD_V_Labo',1,'IRD_V_Labo','IRD_V_Labo.bed','agilent','','IRD','IRD_V_Labo.bed.primers','IRD',NULL,'capture',919,33,'2020-12-16 14:19:19',0,0,NULL),(412,'BONEome_V2',1,'BONEome_V2','BONEome_V2.bed','twist',NULL,'BONEome','BONEome_V2.bed.primers','BONEome',NULL,'capture',919,4,'2021-01-11 09:00:41',0,0,NULL),(413,'epileptome_v1_plus',1,'epileptome_v1_plus','epileptome_v1_plus.bed','agilent',NULL,'epileptome','epileptome_v1_plus.bed.primers','epileptome',NULL,'capture',919,1,'2021-01-14 14:48:26',0,0,NULL),(414,'onco_dijon',1,'onco_dijon','onco_dijon.bed','agilent',NULL,'oncodijon','onco_dijon.bed.primers','oncodijon',NULL,'capture',919,1,'2021-01-15 12:19:37',0,0,NULL),(415,'gyn_dijon',1,'gyn_dijon','gyn_dijon.bed','agilent',NULL,'gyndijon','gyn_dijon.bed.primers','gyndijon',NULL,'capture',919,1,'2021-01-15 16:12:36',0,0,NULL),(416,'amm_dijon',1,'amm_dijon','amm_dijon.bed','agilent',NULL,'ammdijon','amm_dijon.bed.primers','ammdijon',NULL,'capture',919,1,'2021-01-15 17:58:15',0,0,NULL),(417,'IKZF1',1,'IKZF1','IKZF1.bed','Qiagen_pcr',NULL,'IKZF1','IKZF1.bed.primers','IKZF1',NULL,'pcr',919,1,'2021-01-28 08:48:38',0,0,NULL),(418,'idefix_v4_UFGM',1,'idefix_v4_UFGM','idefix_v4_UFGM.bed','twist',NULL,'idefix','idefix_v4_UFGM.bed.primers','idefix',NULL,'capture',919,1,'2021-02-01 15:12:08',0,0,NULL),(419,'HLH_EBV_v2_twist',1,'HLH_EBV_v2_twist','HLH_EBV_v2_twist.bed','twist',NULL,'HLHEBV','HLH_EBV_v2_twist.bed.primers','HLHEBV',NULL,'capture',919,3,'2021-02-12 09:37:38',0,0,NULL),(420,'INNE_v2_twist',1,'INNE_v2_twist','INNE_v2_twist.bed','twist',NULL,'INNE','INNE_v2_twist.bed.primers','INNE',NULL,'capture',919,3,'2021-02-12 09:42:51',0,0,NULL),(421,'oncoB_reduit2',1,'oncoB_reduit2','oncoB_reduit2.bed','Qiagen_pcr',NULL,'oncoB','oncoB_reduit2.bed.primers','oncoB',NULL,'pcr',919,1,'2021-02-15 09:23:01',0,1,NULL),(422,'sgRNA',1,'sgRNA','sgRNA.bed','other',NULL,'','','rnaseq',NULL,'pcr',942,0,'2021-02-23 17:39:18',0,0,NULL),(423,'surdite_v2_twist',1,'surdite_v2_twist','surdite_v2_twist.bed','twist',NULL,'Surdite','surdite_v2_twist.bed.primers','Surdite',NULL,'capture',919,1,'2021-02-25 11:33:13',0,0,NULL),(424,'oncoT_v6',1,'oncoT_v6','oncoT_v6.bed','agilent',NULL,'PanelTv2','oncoT_v6.bed.primers','PanelTv2',NULL,'capture',919,1,'2021-03-08 09:25:24',1,1,NULL),(425,'Epithelium_hg19',1,'Epithelium_hg19','Epythelium_hg19.bed','twist',NULL,'Epythelium','Epythelium_hg19.bed.primers','Epythelium',NULL,'capture',919,38,'2021-03-10 11:43:46',0,0,NULL),(426,'insertion',1,'insertion','','other',NULL,'','','rnaseq',NULL,'capture',900,0,'2021-03-12 13:49:29',0,0,NULL),(427,'SCD_leukemia',1,'SCD_leukemia','SCD_leukemia.bed','other',NULL,'SCDleukemia','SCD_leukemia.bed.primers','SCDleukemia',NULL,'capture',919,1,'2021-03-23 19:03:59',0,0,NULL),(428,'Genodermatoses_v4',1,'Genodermatoses_v4','Genodermatoses_v4.bed','agilent',NULL,'Genodermatoses','Genodermatoses_v4.bed.primers','Genodermatoses',NULL,'capture',919,34,'2021-03-29 08:38:01',0,0,NULL),(429,'Epileptome_V2',1,'Epileptome_V2','Epileptome_V2.bed','twist',NULL,'epileptome','Epileptome_V2.bed.primers','epileptome',NULL,'capture',919,34,'2021-04-13 13:12:16',0,0,NULL),(430,'KAPA_HyperExome_hg19_capture_targets',1,'KAPA_HyperExome_hg19_capture_targets','KAPA_HyperExome_hg19_capture_targets.bed','nimblegen',NULL,'','','exome',NULL,'capture',919,0,'2021-04-23 08:11:03',0,0,NULL),(431,'MM10-Tomato-LacZ',1,'MM10-Tomato-LacZ','','other',NULL,'','','singlecell',NULL,'capture',932,0,'2021-05-06 12:39:56',0,0,NULL),(432,'RAPID1_v3',1,'RAPID1_v3','RAPID1_v3.bed','twist',NULL,'panelrapid1','RAPID1_v3.bed.primers','panelrapid1',NULL,'capture',919,1,'2021-05-10 08:06:27',0,0,NULL),(433,'Twist_plus_MT',1,'Twist_plus_MT','Twist_plus_MT.bed','other',NULL,'','Twist_plus_MT.bed.primers','exome',NULL,'capture',919,0,'2021-05-18 14:24:31',0,0,NULL),(434,'agilent_clinical_research_MT',1,'agilent_clinical_research_MT','agilent_clinical_research_MT.bed','agilent',NULL,'','agilent_clinical_research_MT.bed.primers','exome',NULL,'capture',919,0,'2021-05-18 14:25:44',0,0,NULL),(435,'Twist_mouse',1,'Twist_mouse','Twist_mouse.bed','twist',NULL,'','Twist_mouse.bed.primers','exome',NULL,'capture',800,0,'2021-06-01 11:43:26',0,0,NULL),(436,'renome-v4_plus_complement',1,'renome-v4_plus_complement','renome-v4_plus_complement.bed','twist',NULL,'renome','renome-v4_plus_complement.bed.primers','renome',NULL,'capture',919,1,'2021-06-11 13:41:48',0,0,NULL),(437,'renome-v4_complement_COL4A5split100',1,'renome-v4_complement_COL4A5split100','renome-v4_complement_COL4A5split100.bed','twist',NULL,'renome','','renome',NULL,'capture',919,1,'2021-06-18 09:08:52',0,0,NULL),(438,'renome-v4_plus_complement_COL4A5split300',1,'renome-v4_plus_complement_COL4A5split300','renome-v4_plus_complement_COL4A5split300.bed','twist',NULL,'renome','','renome',NULL,'capture',919,1,'2021-06-25 09:19:35',0,0,NULL),(439,'GLSLTL_V2_NIMB',1,'GLSLTL_V2_NIMB','GLSLTL_V2_NIMB.bed','nimblegen',NULL,'ADC','GLSLTL_V2_NIMB.bed.primers','ADC',NULL,'capture',919,1,'2021-07-05 09:22:00',0,0,NULL),(440,'RapidA-v1',1,'RapidA-v1','RapidA-v1.bed','twist',NULL,'RAPID','RapidA-v1.bed.primers','RAPID',NULL,'capture',919,34,'2021-07-07 09:12:44',0,0,NULL),(441,'metabo_v3',1,'metabo_v3','metabo_v3.bed','twist',NULL,'MetaboHepato','metabo_v3.bed.primers','MetaboHepato',NULL,'capture',919,1,'2021-07-09 12:47:24',0,1,NULL),(442,'transcriptome_10X_CYBB',1,'transcriptome_10X_CYBB','','other',NULL,'','','singlecell',NULL,'capture',943,0,'2021-07-29 15:04:26',0,0,NULL),(443,'RapidB',1,'RapidB','RapidB.bed','twist',NULL,'RapidB','RapidB.bed.primers','RapidB',NULL,'capture',919,38,'2021-07-30 20:03:07',0,0,NULL),(444,'deepseq',1,'deepseq','deepseq.bed','other',NULL,'tert','deepseq.bed.primers','tert',NULL,'capture',919,1,'2021-09-06 14:09:47',0,0,NULL),(445,'Epithelium_V2',1,'Epithelium_V2','Epithelium_V2.bed','twist',NULL,'Epythelium','Epithelium_V2.bed.primers','Epythelium',NULL,'capture',919,38,'2021-09-22 10:25:37',0,0,NULL),(446,'BoneOme_v3',1,'BoneOme_v3','BoneOme_v3.bed','twist',NULL,'BONEome','BoneOme_v3.bed.primers','BONEome',NULL,'capture',919,34,'2021-10-11 13:45:38',0,1,NULL),(447,'Renome_v4plus2',1,'Renome_v4plus2','Renome_v4plus2.bed','twist',NULL,'renome','Renome_v4plus2.bed.primers','renome',NULL,'capture',919,1,'2021-10-25 15:03:01',0,0,NULL),(448,'RapidA-v1-mito',1,'RapidA-v1-mito','RapidA-v1-mito.bed','twist',NULL,'mito','RapidA-v1-mito.bed.primers','mito',NULL,'capture',901,34,'2021-11-02 15:45:58',0,0,NULL),(449,'Hypothyseq_v3',1,'Hypothyseq_v3','Hypothyseq_v3.bed','agilent',NULL,'Hypothyseq','Hypothyseq_v3.bed.primers','Hypothyseq',NULL,'capture',919,39,'2021-11-09 09:43:03',2,1,NULL),(450,'agilent_SureselectXT_HS_human_allexonV8',1,'agilent_SureselectXT_HS_human_allexonV8','agilent_SureselectXT_HS_human_allexonV8.bed','agilent',NULL,'','','exome',NULL,'capture',919,0,'2021-11-16 16:48:25',1,0,NULL),(451,'MCD_v2',1,'MCD_v2','MCD_v2.bed','agilent',NULL,'MCD','MCD_v2.bed.primers','MCD',NULL,'capture',919,38,'2021-11-22 15:47:55',0,1,NULL),(452,'GLSLTL_V3_NIMB',1,'GLSLTL_V3_NIMB','GLSLTL_V3_NIMB.bed','nimblegen',NULL,'CDGDC','GLSLTL_V3_NIMB.bed.primers','CDGDC',NULL,'capture',919,1,'2021-11-23 14:49:53',0,0,NULL),(453,'no_capture',1,'no_capture','','other',NULL,'','','other',NULL,'capture',900,0,'2021-12-13 09:07:42',0,0,NULL),(454,'RapidA_V2',1,'RapidA_V2','RapidA_V2.bed','agilent',NULL,'panelrapideA','RapidA_V2.bed.primers','panelrapideA',NULL,'capture',919,38,'2022-01-04 11:05:00',0,0,NULL),(455,'RapidA_V2_MT',1,'RapidA_V2_MT','RapidA_V2_MT.bed','agilent',NULL,'mito','RapidA_V2_MT.bed.primers','mito',NULL,'capture',919,38,'2022-01-05 10:12:58',0,0,NULL),(458,'pms2',1,'pms2','pms2.bed','other',NULL,'pms2','pms2.bed.primers','pms2',NULL,'capture',919,34,'2022-03-14 10:16:47',0,0,NULL),(459,'DIH_EBV_INNEE_V1',1,'DIH_EBV_INNEE.V1','DIH_EBV_INNEE_V1.bed','agilent',NULL,'PID','','PID',NULL,'capture',919,38,'2022-03-21 13:31:19',2,1,NULL),(460,'RNA_Capture_MM',1,'RNA_Capture_MM','RNA_Capture_MM.bed','agilent',NULL,'','RNA_Capture_MM.bed.primers','rnaseq',NULL,'capture',919,0,'2022-03-29 17:02:26',0,0,NULL),(461,'IdFix_V5_IME_hg19',5,'IdFix_V5_IME_hg19','IdFix_V5_IME_hg19.bed','agilent',NULL,'idefix','','idefix',NULL,'capture',919,38,'2022-03-30 09:12:01',0,0,NULL),(462,'stat1',1,'stat1','stat1.bed','other',NULL,'stat1','stat1.bed.primers','stat1',NULL,'capture',929,34,'2022-03-31 14:09:59',0,0,NULL),(463,'nos2',1,'nos2','nos2.bed','other',NULL,'nos2','nos2.bed.primers','nos2',NULL,'capture',929,34,'2022-03-31 14:13:10',0,0,NULL),(464,'RapidB_V2',1,'RapidB_V2','RapidB_V2.bed','agilent',NULL,'panelrapideB','RapidB_V2.bed.primers','panelrapideB',NULL,'capture',319,38,'2022-04-08 15:15:40',0,0,NULL),(465,'GLSLTL_V4_NIMB',1,'GLSLTL_V4_NIMB','GLSLTL_V4_NIMB.bed','nimblegen',NULL,'CDGDC','','CDGDC',NULL,'capture',319,1,'2022-04-12 09:06:49',0,1,NULL),(466,'fas',1,'fas','fas.bed','twist',NULL,'test','','test',NULL,'capture',919,34,'2022-04-26 14:40:50',0,0,NULL),(467,'Surdites_V3',1,'Surdites_V3','Surdites_V3.bed','twist',NULL,'Surdite','','Surdite',NULL,'capture',319,1,'2022-04-27 12:21:08',0,1,NULL),(468,'CBL',1,'CBL','CBL.bed','AmpliSeq',NULL,'','CBL.bed.primers','cbl',NULL,'pcr',919,34,'2022-04-28 12:55:50',0,0,NULL),(469,'Hepato_Cholestase_V1',1,'Hepato_Cholestase_V1','Hepato_Cholestase_V1.bed','twist',NULL,'MetaboHepato','','MetaboHepato',NULL,'capture',919,39,'2022-05-09 10:51:02',0,1,NULL),(470,'CERBA_clinical_exome',1,'CERBA_clinical_exome','CERBA_clinical_exome.bed','other',NULL,'','','exome',NULL,'capture',919,0,'2022-05-10 13:32:04',0,0,NULL),(471,'Epithelium_V3',1,'Epithelium_V3_XTHS2','Epithelium_V3.bed','agilent',NULL,'Epithelium','','Epithelium',NULL,'capture',919,39,'2022-05-31 10:07:59',0,0,NULL),(472,'ALCL_panel',1,'ALCL_panel','ALCL_panel.bed','Qiagen_pcr',NULL,'ALCL','ALCL_panel.bed.primers','ALCL',NULL,'pcr',919,40,'2022-06-07 09:45:00',0,0,NULL),(473,'MCN_V5',1,'MCN_V5_XTHS2','MCN_V5.bed','agilent',NULL,'MCN','','MCN',NULL,'capture',919,5,'2022-06-13 08:21:04',0,1,NULL),(474,'alport_poland',1,'alport_poland','alport_poland.bed','other',NULL,'Alport','','Alport',NULL,'capture',919,40,'2022-06-14 08:56:08',0,0,NULL),(475,'Genodermatoses_AH_V5',1,'Genodermatoses_AH_V5','Genodermatoses_AH_V5.bed','agilent',NULL,'Genodermatoses','','Genodermatoses',NULL,'capture',919,39,'2022-06-22 14:42:13',0,1,NULL),(476,'Twist_comprehensive',1,'Twist_comprehensive','Twist_comprehensive.bed','twist',NULL,'','','exome',NULL,'capture',919,0,'2022-06-23 15:24:23',0,1,NULL),(477,'twist_a_la_con',1,'twist_a_la_con','twist_a_la_con.bed','twist',NULL,'','','exome',NULL,'capture',919,0,'2022-06-27 07:45:24',0,0,NULL),(478,'Epileptome_V2_XTHS2',1,'Epileptome_V2_XTHS2','Epileptome_V2_XTHS2.bed','agilent',NULL,'epileptome','','epileptome',NULL,'capture',919,39,'2022-06-27 09:12:34',0,1,NULL),(479,'Cilbrain_V2',1,'Cilbrain_V2_XTHS2','Cilbrain_V2.bed','agilent',NULL,'CilbrainV2','','CilbrainV2',NULL,'capture',919,34,'2022-06-30 13:21:36',0,1,NULL),(480,'testjmcap',1,'testjmcap','testjmcap.bed','agilent',NULL,'','','exome',NULL,'capture',919,0,'2022-07-18 09:46:54',0,0,NULL),(481,'Epithelium_V4',1,'Epithelium_V4_XTHS2','Epithelium_V4.bed','agilent',NULL,'Epithelium','','Epithelium',NULL,'capture',919,40,'2022-08-01 14:07:10',0,1,NULL),(482,'RENOME_introns_COL4A5',1,'RENOME_introns_COL4A5','RENOME_introns_COL4A5.bed','twist',NULL,'renome','','renome',NULL,'capture',919,1,'2022-08-30 10:43:11',0,0,NULL),(483,'Surdites_V4',1,'Surdites_V4','Surdites_V4.bed','twist',NULL,'Surdite','','Surdite',NULL,'capture',919,1,'2022-09-07 09:07:03',0,1,NULL),(484,'MitomeV2bis_hg19_ADNmt_SRY_CNV',1,'MitomeV2bis_hg19_ADNmt_SRY_CNV','MitomeV2bis_hg19_ADNmt_SRY_CNV.bed','agilent',NULL,'Mitome','','Mitome',NULL,'capture',919,1,'2022-10-26 09:41:39',0,1,NULL),(485,'MM10-NLS-LacZ-SV40polyA',1,'MM10-NLS-LacZ-SV40polyA','','other',NULL,'','','singlecell',NULL,'capture',321,0,'2022-11-07 10:24:24',0,0,NULL),(486,'Renome_V4plus3',1,'Renome_V4plus3','Renome_V4plus3.bed','twist',NULL,'renome','','renome',NULL,'capture',919,1,'2022-11-29 09:53:11',0,0,NULL),(487,'TET2',1,'TET2','TET2.bed','AmpliSeq',NULL,'','TET2.bed.primers','amplicon',NULL,'pcr',919,0,'2022-12-02 10:33:07',0,0,NULL),(488,'Rapid_V3_TubeE',1,'Rapid_V3_TubeE','Rapid_V3_TubeE.bed','agilent',NULL,'panelrapidE','','panelrapidE',NULL,'capture',919,41,'2022-12-19 13:51:14',0,1,NULL),(489,'Rapid_V3_TubeD',1,'Rapid_V3_TubeD','Rapid_V3_TubeD.bed','agilent',NULL,'panelrapidD','','panelrapidD',NULL,'capture',919,41,'2022-12-26 15:16:16',0,1,NULL),(490,'Rapid_V3_TubeC_ADNmt',1,'Rapid_V3_TubeC_ADNmt','Rapid_V3_TubeC_ADNmt.bed','agilent',NULL,'panelrapidCADNmt','','panelrapidCADNmt',NULL,'capture',919,41,'2022-12-27 10:08:30',0,1,NULL),(491,'Rapid_V3_TubeC',1,'Rapid_V3_TubeC','Rapid_V3_TubeC.bed','agilent',NULL,'panelrapideC','','panelrapideC',NULL,'capture',919,41,'2022-12-27 11:04:11',0,1,NULL),(492,'nano_10',1,'panel HBB DNM2 PTEN FBXW7 RUNX1 PHF6','','targetseq',NULL,'','','rnaseq',NULL,'pcr',938,0,'2023-01-23 15:11:19',0,0,NULL),(493,'mRNA_Universal_plus',1,'mRNA_Universal_plus','','other',NULL,'','','rnaseq',NULL,'capture',938,0,'2023-01-26 15:26:41',3,0,NULL),(494,'agilent_SureselectXT_HS2_human_allexonV8',1,'agilent_SureselectXT_HS2_human_allexonV8','agilent_SureselectXT_HS2_human_allexonV8.bed','agilent',NULL,'','','exome',NULL,'capture',919,0,'2023-01-30 14:15:33',2,1,NULL),(495,'SDHC_meth',1,'SDHC_meth','SDHC_meth.bed','other',NULL,'SDHC','','SDHC',NULL,'pcr',919,42,'2023-01-31 17:17:34',0,0,NULL),(496,'panel_arnaud',1,'panel_arnaud','panel_arnaud.bed','other',NULL,'panelarnaud','','panelarnaud',NULL,'capture',919,42,'2023-02-02 09:57:59',0,0,NULL),(497,'Renome_V4plus4',1,'Renome_V4plus4','Renome_V4plus4.bed','twist',NULL,'renome','','renome',NULL,'capture',919,1,'2023-02-14 10:15:52',0,1,NULL),(498,'CanFam4_transcriptome',1,'CanFam4_transcriptome','','other',NULL,'','','rnaseq',NULL,'capture',902,0,'2023-03-06 09:25:22',0,0,NULL),(499,'Sureselect_XT_HS2_RNA',1,'Sureselect_XT_HS2_RNA','Sureselect_XT_HS2_RNA.bed','agilent',NULL,'','','rnaseq',NULL,'capture',938,0,'2023-03-09 14:47:33',2,1,NULL),(500,'HBB',1,'HBB','HBB.bed','targetseq',NULL,'','HBB.bed.primers','rnaseq',NULL,'pcr',938,0,'2023-03-20 15:16:57',0,0,NULL),(501,'DNM2',1,'DNM2','DNM2.bed','targetseq',NULL,'','','rnaseq',NULL,'pcr',938,0,'2023-03-20 15:20:29',0,0,NULL),(502,'FBXW7',1,'FBXW7','FBXW7.bed','targetseq',NULL,'','','rnaseq',NULL,'pcr',938,0,'2023-03-20 15:22:41',0,0,NULL),(503,'PTEN',1,'PTEN','PTEN.bed','targetseq',NULL,'','','rnaseq',NULL,'pcr',938,0,'2023-03-20 15:24:53',0,0,NULL),(504,'PHF6',1,'PHF6','PHF6.bed','targetseq',NULL,'','','rnaseq',NULL,'pcr',938,0,'2023-03-20 15:26:34',0,0,NULL),(505,'RUNX1',1,'RUNX1','RUNX1.bed','targetseq',NULL,'','','rnaseq',NULL,'pcr',938,0,'2023-03-20 15:28:20',0,0,NULL),(506,'Conf-Exom-Cloves',1,'Conf-Exom-Cloves','Conf-Exom-Cloves.bed','other',NULL,'confExomeCloves','','confExomeCloves',NULL,'capture',919,1,'2023-03-21 15:10:38',0,0,NULL),(507,'OncoHemato_v1KH',1,'OncoHemato_v1KH','OncoHemato_v1KH.bed','other',NULL,'OncoHematoKH','','OncoHematoKH',NULL,'capture',919,42,'2023-03-27 11:48:47',0,1,NULL),(508,'rna_seq_mm39_umi',1,'rna_seq_mm39_umi','','other',NULL,'','','rnaseq',NULL,'capture',339,0,'2023-03-31 07:30:25',3,1,NULL),(509,'IRD_V_Labo_umi',1,'IRD_V_Labo_umi','IRD_V_Labo_umi.bed','agilent',NULL,'IRD','','IRD',NULL,'capture',919,33,'2023-04-03 14:13:42',0,1,NULL),(510,'Rapid_V3_TubeC_UMI',1,'Rapid_V3_TubeC_UMI','Rapid_V3_TubeC_UMI.bed','agilent',NULL,'panelrapideC','','panelrapideC',NULL,'capture',919,41,'2023-04-03 14:22:52',2,1,NULL),(511,'Rapid_V3_TubeD_UMI',1,'Rapid_V3_TubeD_UMI','Rapid_V3_TubeD_UMI.bed','agilent',NULL,'panelrapidD','','panelrapidD',NULL,'capture',919,41,'2023-04-21 16:46:24',2,1,NULL),(512,'Rapid_V3_TubeE_UMI',1,'Rapid_V3_TubeE_UMI','Rapid_V3_TubeE_UMI.bed','agilent',NULL,'panelrapidE','','panelrapidE',NULL,'capture',919,41,'2023-04-21 16:59:39',2,1,NULL),(513,'Twist_Coag_v2',1,'Twist_Coag_v2','Twist_Coag_v2.bed','twist',NULL,'HEGPcoag','','HEGPcoag',NULL,'capture',919,3,'2023-05-05 13:28:46',0,1,NULL),(514,'LysPur_V3',1,'LysPur_V3','LysPur_V3.bed','agilent',NULL,'LysPur','','LysPur',NULL,'capture',919,42,'2023-05-16 08:19:17',0,1,NULL),(515,'LysPur_V3_XTHS2',1,'LysPur_V3_XTHS2','LysPur_V3_XTHS2.bed','agilent',NULL,'LysPur','','LysPur',NULL,'capture',919,42,'2023-05-16 10:20:00',2,1,NULL),(516,'Renome_V4plus5',1,'Renome_V4plus5','Renome_V4plus5.bed','twist',NULL,'renome','','renome',NULL,'capture',919,1,'2023-05-17 14:11:46',0,1,NULL),(517,'MitomeV3_ADNnc',1,'MitomeV3_ADNnc','MitomeV3.bed','agilent',NULL,'Mitome','','Mitome',NULL,'capture',919,42,'2023-05-30 09:02:02',0,1,NULL),(518,'MitomeV3_ADNmt',1,'MitomeV3_ADNmt','MitomeV3_ADNmt.bed','agilent',NULL,'Mitome','','Mitome',NULL,'capture',919,42,'2023-05-30 12:01:50',0,1,NULL),(519,'med16',1,'med16','med16.bed','BAC',NULL,'','med16.bed.primers','amplicon',NULL,'capture',919,0,'2023-05-31 06:59:32',0,1,NULL),(520,'TMEM2',1,'TMEM2','TMEM2.bed','AmpliSeq',NULL,'','TMEM2.bed.primers','amplicon',NULL,'pcr',919,0,'2023-05-31 07:11:35',0,1,NULL),(521,'agilent_SureselectXT_HS_human_allexonV7',1,'agilent_SureselectXT_HS_human_allexonV7','agilent_SureselectXT_HS_human_allexonV7.bed','agilent',NULL,'','','exome',NULL,'capture',919,0,'2023-05-31 13:37:58',1,1,NULL),(522,'Revelo_mRNA-Seq_MagicPre_NGS',1,'Revelo_mRNA-Seq_MagicPre_NGS','','other',NULL,'','','rnaseq',NULL,'capture',339,0,'2023-06-01 14:40:51',0,1,NULL),(523,'Epithelium_V5_XTHS2',1,'Epithelium_V5_XTHS2','Epithelium_V5_XTHS2.bed','agilent',NULL,'Epithelium','','Epithelium',NULL,'capture',919,43,'2023-07-10 15:12:05',0,1,NULL),(524,'capture_pourrie',1,'capture_pourrie','','other',NULL,'','','exome',NULL,'capture',919,0,'2023-07-11 08:29:34',0,1,NULL),(525,'Rapid_V3_TubeC_ADNmt_UMI',1,'Rapid_V3_TubeC_ADNmt_UMI','Rapid_V3_TubeC_ADNmt_UMI.bed','agilent',NULL,'panelrapideC','','panelrapideC',NULL,'capture',919,41,'2023-07-21 10:02:51',2,1,NULL),(526,'rna_DR',1,'rna_DR','','other',NULL,'','','rnaseq',NULL,'capture',911,0,'2023-08-01 13:13:06',3,1,NULL),(527,'CHIP',1,'CHIP','CHIP.bed','agilent',NULL,'CHIP','','CHIP',NULL,'capture',919,43,'2023-08-03 09:50:57',2,1,NULL),(528,'DIH_EBV_INNEE_V2',1,'DIH_EBV_INNEE_V2','DIH_EBV_INNEE_V2.bed','agilent',NULL,'PID','','PID',NULL,'capture',919,42,'2023-08-09 09:00:55',2,1,NULL),(529,'Rapid_V4_TubeF',1,'Rapid_V4_TubeF','Rapid_V4_TubeF.bed','agilent',NULL,'PanelRapidF','','PanelRapidF',NULL,'capture',919,43,'2023-08-11 13:32:25',0,1,NULL),(530,'CLOVES_AGILENT_UMI_V3',1,'CLOVES_AGILENT_UMI_V3','CLOVES_AGILENT_UMI_V3.bed','agilent',NULL,'CLOVES','','CLOVES',NULL,'capture',919,43,'2023-09-05 13:29:37',1,1,NULL),(531,'tubulo_twist',1,'tubulo_twist','tubulo_twist.bed','twist',NULL,'Tubulopathies','','Tubulopathies',NULL,'capture',919,1,'2023-09-08 06:47:37',0,1,NULL),(532,'PTPCN20-CP',1,'PTPCN20-CP','PTPCN20-CP.bed','other',NULL,'','','other',NULL,'capture',938,0,'2023-09-25 07:18:16',0,1,NULL),(533,'BoneOme_V4',1,'BoneOme_V4','BoneOme_V4.bed','twist',NULL,'BONEome','','BONEome',NULL,'capture',919,34,'2023-09-27 09:48:54',0,1,NULL),(535,'genome_T2T',1,'genome_T2T','','other',NULL,'','','genome',NULL,'capture',948,0,'2023-09-28 13:18:00',0,1,NULL),(536,'Rapid_V4_TubeF_UMI',1,'Rapid_V4_TubeF_UMI','Rapid_V4_TubeF_UMI.bed','agilent',NULL,'PanelRapidF','','PanelRapidF',NULL,'capture',919,43,'2023-10-02 15:54:56',2,1,NULL),(537,'Rapid_V4_TubeG',1,'Rapid_V4_TubeG','Rapid_V4_TubeG.bed','agilent',NULL,'PanelRapidG','','PanelRapidG',NULL,'capture',919,43,'2023-10-02 16:02:33',0,1,NULL),(538,'Rapid_V4_TubeG_UMI',1,'Rapid_V4_TubeG_UMI','Rapid_V4_TubeG_UMI.bed','agilent',NULL,'PanelRapidG','','PanelRapidG',NULL,'capture',919,43,'2023-10-02 16:26:32',2,1,NULL),(539,'Genodermatoses_AH_V5_umi',1,'Genodermatoses_AH_V5_umi','Genodermatoses_AH_V5_umi.bed','agilent',NULL,'Genodermatoses','','Genodermatoses',NULL,'capture',919,39,'2023-10-12 15:02:37',2,1,NULL),(540,'Rapid_V4_TubeH',1,'Rapid_V4_TubeH','Rapid_V4_TubeH.bed','agilent',NULL,'PanelRapidH','','PanelRapidH',NULL,'capture',919,43,'2023-10-16 15:52:41',0,1,NULL),(541,'Rapid_V4_TubeH_ADNmt',1,'Rapid_V4_TubeH_ADNmt','Rapid_V4_TubeH_ADNmt.bed','agilent',NULL,'PanelRapidH','','PanelRapidH',NULL,'capture',919,43,'2023-10-16 16:14:00',0,1,NULL),(542,'Rapid_V4_TubeH_UMI',1,'Rapid_V4_TubeH_UMI','Rapid_V4_TubeH_UMI.bed','agilent',NULL,'PanelRapidH','','PanelRapidH',NULL,'capture',919,43,'2023-10-17 12:35:27',2,1,NULL),(543,'Rapid_V4_TubeH_ADNmt_UMI',1,'Rapid_V4_TubeH_ADNmt_UMI','Rapid_V4_TubeH_ADNmt_UMI.bed','agilent',NULL,'PanelRapidH','','PanelRapidH',NULL,'capture',919,43,'2023-10-17 12:42:53',2,1,NULL),(544,'Nefisco-v1',1,'Nefisco-v1','Nefisco-v1.bed','other',NULL,'NefiscoV1','','NefiscoV1',NULL,'capture',919,43,'2023-10-25 13:03:02',0,1,NULL),(545,'OncoHematoV2',1,'OncoHematoV2','OncoHematoV2.bed','other',NULL,'OncoHematoKH','','OncoHematoKH',NULL,'capture',919,43,'2023-10-25 14:23:46',0,1,NULL),(546,'Twist_Mouse_Exome_v1',1,'Twist_Mouse_Exome_v1','Twist_Mouse_Exome_v1.bed','twist',NULL,'','','exome',NULL,'capture',339,0,'2023-11-10 17:24:55',0,1,NULL),(547,'PEDIAC',1,'PEDIAC','PEDIAC.bed','other',NULL,'PEDIAC','','PEDIAC',NULL,'capture',919,43,'2023-12-11 17:58:03',0,1,NULL),(548,'Juliette_Cochin_DIMyPsyV1',1,'Juliette_Cochin_DIMyPsyV1','Juliette_Cochin_DIMyPsyV1.bed','other',NULL,'DIMyPsyV1','','DIMyPsyV1',NULL,'capture',919,43,'2024-01-22 15:30:22',0,1,NULL),(549,'lefloch',1,'lefloch','lefloch.bed','other',NULL,'','','other',NULL,'capture',919,0,'2024-01-23 10:00:58',0,1,NULL),(550,'BoneOme_V5',1,'BoneOme_V5','BoneOme_V5.bed','twist',NULL,'BONEome','','BONEome',NULL,'capture',919,34,'2024-01-31 11:18:50',0,1,NULL),(551,'alport11',1,'alport11','alport11.bed','other',NULL,'alport11','','alport11',NULL,'capture',919,3,'2024-02-02 10:53:35',0,1,NULL),(552,'alportlh',1,'alportlh','alportlh.bed','other',NULL,'','','alportlh',NULL,'capture',919,3,'2024-02-02 10:55:58',0,1,NULL),(553,'rna_seq_HG38_neb',1,'rna_seq_HG38_neb','','other',NULL,'','','rnaseq',NULL,'capture',919,0,'2024-02-08 15:04:43',0,1,NULL),(554,'rna_seq_HG38_ribozero',1,'rna_seq_HG38_ribozero','','other',NULL,'','','rnaseq',NULL,'capture',938,0,'2024-02-08 15:10:28',0,1,NULL),(555,'rna_seq_HG38_illumina_stranded',1,'rna_seq_HG38_illumina_stranded','','other',NULL,'','','rnaseq',NULL,'capture',938,0,'2024-02-08 15:11:33',0,1,NULL),(556,'OncoB_reduit2_Twist',1,'OncoB_reduit2_Twist','OncoB_reduit2_Twist.bed','twist',NULL,'oncoB','','oncoB',NULL,'capture',919,1,'2024-02-12 10:55:44',0,1,NULL),(557,'MCN_V6',1,'MCN_V6_XTHS2','MCN_V6.bed','agilent',NULL,'MCN','','MCN',NULL,'capture',919,43,'2024-02-13 14:53:24',0,1,NULL),(558,'Renome_V4plus6',1,'Renome_V4plus6','Renome_V4plus6.bed','twist',NULL,'renome','','renome',NULL,'capture',919,1,'2024-02-22 11:57:12',0,1,NULL),(559,'MucoHemPancFin',1,'Juliette_MucoHemPancFin','MucoHemPancFin.bed','other',NULL,'MucoHemPancFin','','MucoHemPancFin',NULL,'capture',919,43,'2024-03-07 13:13:19',0,1,NULL),(560,'IRAK4',1,'IRAK4','IRAK4.bed','agilent',NULL,'IRAK4','','IRAK4',NULL,'capture',919,43,'2024-03-18 13:33:08',0,1,NULL),(561,'Immuno_GenoDermato_V1',1,'Immuno_GenoDermato_V1','Immuno_GenoDermato_V1.bed','agilent',NULL,'ImmunoDermato','','ImmunoDermato',NULL,'capture',919,42,'2024-03-20 15:48:15',2,1,NULL),(562,'HBG_editing',1,'HBG_editing','','other',NULL,'','','amplicon',NULL,'pcr',919,0,'2024-03-25 19:03:59',0,1,NULL),(563,'1365_Genes_DI_splice',1,'1365_Genes_DI_splice','1365_Genes_DI_splice.bed','agilent',NULL,'1365GenesDIsplice','','1365GenesDIsplice',NULL,'capture',919,43,'2024-03-28 15:56:19',2,1,NULL),(564,'LysPur_V4',1,'LysPur_V4','LysPur_V4.bed','agilent',NULL,'LysPur','','LysPur',NULL,'capture',919,43,'2024-04-05 12:39:47',0,1,NULL),(565,'LysPur_V4_XTHS2',1,'LysPur_V4_XTHS2','LysPur_V4_XTHS2.bed','agilent',NULL,'LysPur','','LysPur',NULL,'capture',919,43,'2024-04-05 15:11:43',2,1,NULL),(566,'DIH_EBV_INNEE_V3',1,'DIH_EBV_INNEE_V3','DIH_EBV_INNEE_V3.bed','agilent',NULL,'PID','','PID',NULL,'capture',919,42,'2024-04-18 15:41:47',2,1,NULL),(567,'COL4A5',1,'COL4A5_Flexicapture','COL4A5.bed','BAC',NULL,'COL4A5','','COL4A5',NULL,'capture',919,43,'2024-05-23 10:39:32',0,1,NULL),(568,'COL4A5_NM_000495_RNA',1,'COL4A5_NM_000495_RNA','COL4A5_NM_000495_RNA.bed','other',NULL,'COL4A5RNA','','COL4A5RNA',NULL,'capture',919,43,'2024-05-23 10:51:46',0,1,NULL),(569,'Transcriptome_10X_mm39',1,'Transcriptome_10X_mm39','','other',NULL,'','','rnaseq',NULL,'capture',933,0,'2024-06-14 08:02:04',0,1,NULL),(570,'ONCOSTIT_V1-2',1,'ONCOSTIT_V1-2','ONCOSTIT_V1-2.bed','other',NULL,'ONCOSTIT','','ONCOSTIT',NULL,'capture',919,43,'2024-06-17 15:33:15',0,1,NULL),(571,'Surdites_V2_GencodeV43',1,'Surdites_V2_GencodeV43','Surdites_V2_GencodeV43.bed','twist',NULL,'Surdite','','Surdite',NULL,'capture',919,43,'2024-06-27 14:44:57',0,1,NULL),(572,'Surdites_V3_GencodeV43',1,'Surdites_V3_GencodeV43','Surdites_V3_GencodeV43.bed','twist',NULL,'Surdite','','Surdite',NULL,'capture',919,43,'2024-06-27 15:06:49',0,1,NULL),(573,'Surdites_V4_GencodeV43',1,'Surdites_V4_GencodeV43','Surdites_V4_GencodeV43.bed','twist',NULL,'Surdite','','Surdite',NULL,'capture',919,43,'2024-06-27 15:54:49',0,1,NULL),(574,'Exome-Agilent_V6',38,'Exome-Agilent_V6','','agilent',NULL,'','','exome',NULL,'capture',938,0,'2024-06-28 09:14:01',0,1,NULL),(575,'TwistCV_v2',1,'TwistCV_v2','TwistCV_v2.bed','twist',NULL,'TwistCV','','TwistCV',NULL,'capture',919,1,'2024-07-03 14:16:50',0,1,NULL),(576,'cbl_hg38',1,'cbl_hg38','cbl_hg38.bed','AmpliSeq',NULL,'','','other',NULL,'pcr',938,34,'2024-07-04 11:04:51',0,1,NULL),(577,'BoneOme_V6',1,'BoneOme_V6','BoneOme_V6.bed','twist',NULL,'BONEome','','BONEome',NULL,'capture',919,34,'2024-07-09 12:32:18',2,1,NULL),(578,'BNIP3_FlexiBAC',1,'BNIP3_FlexiBAC','BAC_BNIP3.bed','BAC',NULL,'BNIP3','','BNIP3',NULL,'capture',919,43,'2024-07-26 08:48:43',0,1,NULL),(579,'DIM_SOM_V1',1,'DIM_SOM_V1','DIM_SOM_V1.bed','agilent',NULL,'Immunite','','Immunite',NULL,'capture',919,42,'2024-08-02 09:34:51',3,1,NULL),(580,'RENOME_V5_Hg38',1,'RENOME_V5_Hg38','RENOME_V5_Hg38.bed','twist',NULL,'renome','','renome',NULL,'capture',938,43,'2024-09-18 09:04:30',0,1,NULL),(581,'FOXP3',1,'FOXP3','FOXP3.bed','other',NULL,'FOXP3','','rnaseq',NULL,'capture',938,43,'2024-09-25 12:48:38',0,1,NULL);
/*!40000 ALTER TABLE `capture_systems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_systemsLike`
--

DROP TABLE IF EXISTS `capture_systemsLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_systemsLike` (
  `capture_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `version` int(11) DEFAULT 0,
  `description` varchar(45) NOT NULL,
  `filename` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `transcripts` varchar(10000) NOT NULL,
  `validation_db` varchar(45) DEFAULT NULL,
  `primers_filename` varchar(45) DEFAULT NULL,
  `analyse` varchar(45) NOT NULL,
  `design_id` int(11) DEFAULT NULL,
  `method` varchar(20) NOT NULL,
  PRIMARY KEY (`capture_id`),
  KEY `index_2` (`name`,`version`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_systemsLike`
--

LOCK TABLES `capture_systemsLike` WRITE;
/*!40000 ALTER TABLE `capture_systemsLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `capture_systemsLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `databases_projects`
--

DROP TABLE IF EXISTS `databases_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `databases_projects` (
  `db_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`db_id`,`project_id`),
  KEY `index_2` (`project_id`),
  KEY `index_3` (`db_id`,`project_id`),
  KEY `index_4` (`db_id`),
  CONSTRAINT `FK_databases_projects_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `databases_projects`
--

LOCK TABLES `databases_projects` WRITE;
/*!40000 ALTER TABLE `databases_projects` DISABLE KEYS */;
INSERT INTO `databases_projects` VALUES (4,9866),(4,9867);
/*!40000 ALTER TABLE `databases_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disease`
--

DROP TABLE IF EXISTS `disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disease` (
  `disease_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(150) NOT NULL,
  `abbreviations` varchar(20) DEFAULT NULL,
  `description_en` varchar(150) DEFAULT NULL,
  `mesh_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`disease_id`),
  UNIQUE KEY `mesh_id_UNIQUE` (`mesh_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disease`
--

LOCK TABLES `disease` WRITE;
/*!40000 ALTER TABLE `disease` DISABLE KEYS */;
/*!40000 ALTER TABLE `disease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disease_transcripts`
--

DROP TABLE IF EXISTS `disease_transcripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disease_transcripts` (
  `disease_id` int(11) NOT NULL,
  `transcript_id` int(11) NOT NULL,
  PRIMARY KEY (`disease_id`,`transcript_id`),
  KEY `FKDT2_idx` (`transcript_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disease_transcripts`
--

LOCK TABLES `disease_transcripts` WRITE;
/*!40000 ALTER TABLE `disease_transcripts` DISABLE KEYS */;
/*!40000 ALTER TABLE `disease_transcripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `externalDB`
--

DROP TABLE IF EXISTS `externalDB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `externalDB` (
  `externaldb_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`externaldb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `externalDB`
--

LOCK TABLES `externalDB` WRITE;
/*!40000 ALTER TABLE `externalDB` DISABLE KEYS */;
/*!40000 ALTER TABLE `externalDB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `externalDB_person`
--

DROP TABLE IF EXISTS `externalDB_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `externalDB_person` (
  `externaldb_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `external_id` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  UNIQUE KEY `index3` (`externaldb_id`,`person_id`,`external_id`),
  KEY `fk_externalDB_person_2_idx` (`person_id`),
  CONSTRAINT `fk_externalDB_person_1` FOREIGN KEY (`externaldb_id`) REFERENCES `externalDB` (`externaldb_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_externalDB_person_2` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `externalDB_person`
--

LOCK TABLES `externalDB_person` WRITE;
/*!40000 ALTER TABLE `externalDB_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `externalDB_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `family`
--

DROP TABLE IF EXISTS `family`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `family` (
  `family_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`family_id`),
  UNIQUE KEY `index2` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=91229 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family`
--

LOCK TABLES `family` WRITE;
/*!40000 ALTER TABLE `family` DISABLE KEYS */;
INSERT INTO `family` VALUES (91228,'MAT'),(91226,'MAT_EA'),(91227,'MAT_M'),(91225,'MAT_P'),(91222,'Test1'),(91223,'Test2'),(91224,'Test3');
/*!40000 ALTER TABLE `family` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filters` (
  `FILTER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PROJECT_ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `FILTER_NAME` varchar(512) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`FILTER_ID`),
  UNIQUE KEY `index_2` (`PROJECT_ID`,`USER_ID`,`FILTER_NAME`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1660 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters`
--

LOCK TABLES `filters` WRITE;
/*!40000 ALTER TABLE `filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters_param`
--

DROP TABLE IF EXISTS `filters_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filters_param` (
  `PARAM_ID` int(11) NOT NULL AUTO_INCREMENT,
  `FILTER_ID` int(11) NOT NULL,
  `PARAM_NAME` varchar(45) NOT NULL,
  `PARAM_VALUE` varchar(10000) NOT NULL,
  PRIMARY KEY (`PARAM_ID`),
  UNIQUE KEY `index_2` (`FILTER_ID`,`PARAM_NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=7582 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters_param`
--

LOCK TABLES `filters_param` WRITE;
/*!40000 ALTER TABLE `filters_param` DISABLE KEYS */;
/*!40000 ALTER TABLE `filters_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters_users`
--

DROP TABLE IF EXISTS `filters_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filters_users` (
  `filter_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`filter_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1660 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters_users`
--

LOCK TABLES `filters_users` WRITE;
/*!40000 ALTER TABLE `filters_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `filters_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `index_2` (`name`,`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2776 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupLike`
--

DROP TABLE IF EXISTS `groupLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupLike` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `index_2` (`name`,`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupLike`
--

LOCK TABLES `groupLike` WRITE;
/*!40000 ALTER TABLE `groupLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `major_project`
--

DROP TABLE IF EXISTS `major_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `major_project` (
  `major_project_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`major_project_id`),
  UNIQUE KEY `index2` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `major_project`
--

LOCK TABLES `major_project` WRITE;
/*!40000 ALTER TABLE `major_project` DISABLE KEYS */;
/*!40000 ALTER TABLE `major_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `major_project_person`
--

DROP TABLE IF EXISTS `major_project_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `major_project_person` (
  `major_project_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY (`major_project_id`,`person_id`),
  KEY `fk_major_project_person_2_idx` (`person_id`),
  CONSTRAINT `fk_major_project_person_1` FOREIGN KEY (`major_project_id`) REFERENCES `major_project` (`major_project_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_major_project_person_2` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `major_project_person`
--

LOCK TABLES `major_project_person` WRITE;
/*!40000 ALTER TABLE `major_project_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `major_project_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `method_pipeline`
--

DROP TABLE IF EXISTS `method_pipeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `method_pipeline` (
  `method_id` int(11) NOT NULL,
  `pipeline_id` int(5) NOT NULL,
  KEY `fk_method_pipeline_1_idx` (`pipeline_id`),
  KEY `index2` (`method_id`,`pipeline_id`),
  CONSTRAINT `fk_method_pipeline_1` FOREIGN KEY (`pipeline_id`) REFERENCES `profile_pipeline` (`pipeline_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `method_pipeline`
--

LOCK TABLES `method_pipeline` WRITE;
/*!40000 ALTER TABLE `method_pipeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `method_pipeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `method_seq`
--

DROP TABLE IF EXISTS `method_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `method_seq` (
  `method_seq_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `def` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`method_seq_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `method_seq`
--

LOCK TABLES `method_seq` WRITE;
/*!40000 ALTER TABLE `method_seq` DISABLE KEYS */;
INSERT INTO `method_seq` VALUES (1,'paired-end',1),(2,'fragment',0),(3,'mate-paired',0),(4,'fragment-ecc',0),(5,'fast_paired-end',0),(6,'SC3Pv1',0),(7,'SC3Pv2',0),(8,'SC3Pv3',0),(9,'SC5P-PE',0),(10,'SC5P-R2',0),(11,'spatial',0),(12,'atac',0),(13,'vdj',0),(14,'adt_vdj',0),(15,'adt',0),(16,'exp',0),(17,'nuclei',0),(18,'arc',0),(19,'rna_plus',0),(20,'rna_minus',0),(21,'tapestri',0),(22,'parseBiosciences',0),(23,'exp_vdj',0),(24,'longread',0),(25,'cmo',0),(26,'adt_cmo',0),(27,'methylome',0),(28,'fixed',1);
/*!40000 ALTER TABLE `method_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `methods`
--

DROP TABLE IF EXISTS `methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `methods` (
  `method_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `def` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `methods`
--

LOCK TABLES `methods` WRITE;
/*!40000 ALTER TABLE `methods` DISABLE KEYS */;
INSERT INTO `methods` VALUES (1,'indel_polyphred','SNP',0),(2,'bipd','SNP',0),(3,'polyphred','SNP',0),(4,'ensembl','SNP',0),(5,'crossmatch','ALIGN',0),(6,'ssaha2','ALIGN',0),(8,'indel_bipd','SNP',0),(9,'gseq','SNP',0),(10,'solexa','SNP',0),(11,'indel_solexa','SNP',0),(12,'maq','SNP',0),(13,'bowtie','SNP',0),(14,'cnv','SNP',0),(15,'gatk','SNP',0),(16,'sam70','SNP',0),(17,'sam100','SNP',0),(18,'beadstd','SNP',0),(19,'dibayes','SNP',0),(20,'mapreads','ALIGN',0),(21,'bwa','ALIGN',1),(22,'affymetrix','ALIGN',0),(23,'bfast','ALIGN',0),(24,'mpileup','SNP',0),(25,'eland','ALIGN',0),(26,'casava','SNP',0),(27,'tmap','ALIGN',0),(28,'trio','SNP',0),(29,'varscan','SNP',0),(30,'haplotypecaller','SNP',0),(31,'unifiedgenotyper','SNP',1),(32,'ion_merge','SNP',0),(35,'ctest','SNP',0),(36,'lifinder','SNP',0),(37,'star','ALIGN',0),(38,'hisat2','ALIGN',1),(39,'featureCounts','SNP',1),(40,'freebayes','SNP',1),(41,'samtools','SNP',1),(42,'duplicate_region_calling','SNP',1),(43,'cp','SNP',0),(44,'mutect','SNP',0),(45,'cellranger','SNP',0),(46,'cellranger_count','SNP',1),(47,'cellranger_star','ALIGN',1),(48,'dude','SNP',1),(49,'SmCounter','SNP',1),(52,'octopus','SNP',0),(53,'p1_freebayes','SNP',1),(54,'eif6_freebayes','SNP',0),(55,'lumpy','SV,SR',1),(56,'canvas','SV',1),(57,'manta','SV,SNP,SR',1),(58,'hpduplicate_region_calling','SNP',1),(59,'wisecondor','SV',1),(60,'bowtie2','ALIGN',0),(61,'haplotypecaller4','SNP',1),(62,'idvigilance','SNP',0),(63,'mutect2','SNP',1),(64,'umi_dedup','ALIGN',1),(65,'lofreq','SNP',1),(66,'agent','ALIGN',0),(67,'bwa_xths2','ALIGN',0),(68,'dragen-calling','SNP',1),(69,'dragen-align','ALIGN',1),(70,'htlv1','ALIGN',1),(71,'htlv1_calling','SNP',1),(74,'crispresso_aln','ALIGN',1),(75,'crispresso_count','SNP',1),(76,'star_umi','ALIGN',0),(77,'no_align','ALIGN',1),(78,'no_calling','SNP',1),(79,'tapestri_aln','ALIGN',0),(80,'tapestri_call','SNP',0),(81,'split-pipe_call','SNP',0),(82,'split-pipe_aln','ALIGN',0),(83,'dragen-sv','SV,SR,SNP',1),(84,'dragen-pon','SV',1),(85,'dragen-cnv','SV',1),(86,'smrtlink','ALIGN',0),(87,'deepvariant','SNP',0),(88,'dragen-count','SNP',1),(90,'splice_calling','SPLICES',1),(91,'melt','SNP',1),(92,'last','ALIGN',1),(93,'dragen-meth','ALIGN',1),(94,'splice','SNP',0),(95,'qiaseq_targeted','ALIGN',0),(96,'spaceranger','ALIGN',1),(97,'spaceranger_count','SNP',1),(98,'qiaseq','SNP',1),(99,'dragen-calling4-2','SNP',1),(100,'minimap2','ALIGN',1),(101,'join-dragen-calling','SNP',1),(102,'dragen-somatic','SNP',1),(103,'epi2me','ALIGN',1),(104,'epi2me_calling','SNP',1),(105,'p02_freebayes','SNP',1),(106,'SMRTlink_alignment','ALIGN',1),(107,'SMRTlink_calling','SNP',1),(108,'pbsv','SV,SR,SNP',1),(109,'expansionHunter','SNP',1),(110,'hificnv','SV',1),(111,'Clair3','SNP',1),(112,'Sniffles2','SNP',1);
/*!40000 ALTER TABLE `methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_view`
--

DROP TABLE IF EXISTS `new_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_view` (
  `project_id` tinyint(4) NOT NULL,
  `name` tinyint(4) NOT NULL,
  `type_project_id` tinyint(4) NOT NULL,
  `description` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_view`
--

LOCK TABLES `new_view` WRITE;
/*!40000 ALTER TABLE `new_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panel`
--

DROP TABLE IF EXISTS `panel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `panel` (
  `panel_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `validation_db` varchar(45) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`panel_id`),
  KEY `index2` (`panel_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel`
--

LOCK TABLES `panel` WRITE;
/*!40000 ALTER TABLE `panel` DISABLE KEYS */;
/*!40000 ALTER TABLE `panel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panel_capture`
--

DROP TABLE IF EXISTS `panel_capture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `panel_capture` (
  `panel_id` int(11) NOT NULL,
  `capture_id` int(11) NOT NULL,
  PRIMARY KEY (`panel_id`,`capture_id`),
  KEY `fk_panel_capture_1` (`panel_id`),
  KEY `fk_panel_capture_2` (`capture_id`),
  CONSTRAINT `fk_panel_capture_1` FOREIGN KEY (`panel_id`) REFERENCES `panel` (`panel_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_panel_capture_2` FOREIGN KEY (`capture_id`) REFERENCES `capture_systems` (`capture_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel_capture`
--

LOCK TABLES `panel_capture` WRITE;
/*!40000 ALTER TABLE `panel_capture` DISABLE KEYS */;
/*!40000 ALTER TABLE `panel_capture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `genbo_id` int(11) DEFAULT 0,
  `project_id` int(11) DEFAULT 0,
  `run_id` int(11) NOT NULL,
  `capture_id` int(11) DEFAULT NULL,
  `panel_id` int(11) DEFAULT 0,
  `profile_id` int(5) DEFAULT 0,
  `name` varchar(45) NOT NULL,
  `origin` varchar(45) DEFAULT NULL,
  `bar_code` varchar(150) DEFAULT NULL,
  `bar_code2` varchar(150) DEFAULT NULL,
  `identity_vigilance` varchar(45) DEFAULT NULL,
  `identity_vigilance_vcf` varchar(45) DEFAULT NULL,
  `sex` tinyint(2) DEFAULT 0,
  `status` tinyint(2) DEFAULT 0,
  `description` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `family` varchar(45) DEFAULT NULL,
  `father` varchar(45) DEFAULT NULL,
  `mother` varchar(45) DEFAULT NULL,
  `flowcell` char(1) CHARACTER SET big5 COLLATE big5_chinese_ci DEFAULT NULL,
  `control` tinyint(1) unsigned zerofill DEFAULT 0,
  `project_id_dest` int(11) DEFAULT 0,
  `type` varchar(15) NOT NULL DEFAULT 'dna',
  `grna` varchar(45) DEFAULT NULL,
  `species_id` int(3) NOT NULL DEFAULT 1,
  `lane` varchar(15) DEFAULT NULL,
  `g_project` varchar(45) DEFAULT NULL,
  `origin_patient_id` int(11) DEFAULT 0,
  `demultiplex_only` tinyint(1) unsigned zerofill DEFAULT 0,
  PRIMARY KEY (`patient_id`) USING BTREE,
  UNIQUE KEY `index_2` (`project_id`,`name`,`run_id`) USING BTREE,
  KEY `index3` (`run_id`),
  KEY `index4` (`capture_id`),
  KEY `index5` (`project_id`),
  KEY `index6` (`project_id_dest`),
  KEY `index7` (`project_id`,`project_id_dest`),
  KEY `index8` (`profile_id`),
  CONSTRAINT `fk_patient_1` FOREIGN KEY (`run_id`) REFERENCES `run` (`run_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=146113 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (146107,0,9866,6163,381,0,1,'Test1','Test1','','','',NULL,1,2,NULL,'2025-01-02 09:02:31','Test1','','','',0,0,'dna',NULL,1,NULL,NULL,0,0),(146108,0,9866,6163,381,0,1,'Test2','Test2','','','',NULL,1,2,NULL,'2025-01-02 09:02:31','Test2','','','',0,0,'dna',NULL,1,NULL,NULL,0,0),(146109,0,0,6163,381,0,1,'Test3','Test3','','','',NULL,1,2,NULL,'2025-01-02 15:21:24','Test3','','','',0,9866,'dna',NULL,1,NULL,NULL,0,0),(146110,0,9867,6164,381,0,4,'MAT_P','MAT_P','','','',NULL,1,1,'','2025-01-02 15:27:49','MAT','','','A',0,0,'dna',NULL,1,NULL,NULL,0,0),(146111,0,9867,6164,381,0,4,'MAT_EA','MAT_EA','','','',NULL,2,2,'','2025-01-02 15:27:49','MAT','MAT_P','MAT_M','A',0,0,'dna',NULL,1,NULL,NULL,0,0),(146112,0,9867,6164,381,0,4,'MAT_M','MAT_M','','','',NULL,2,1,'','2025-01-02 15:27:49','MAT','','','A',0,0,'dna',NULL,1,NULL,NULL,0,0);
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_groups`
--

DROP TABLE IF EXISTS `patient_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_groups` (
  `patient_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  UNIQUE KEY `index_2` (`group_id`,`patient_id`),
  KEY `index_3` (`group_id`),
  KEY `fk_patient_groups_1` (`patient_id`),
  CONSTRAINT `fk_patient_groups_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_groups`
--

LOCK TABLES `patient_groups` WRITE;
/*!40000 ALTER TABLE `patient_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_methods`
--

DROP TABLE IF EXISTS `patient_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_methods` (
  `patient_id` int(11) NOT NULL,
  `method_id` int(11) NOT NULL,
  UNIQUE KEY `index_2` (`patient_id`,`method_id`),
  KEY `fk_method_id` (`method_id`),
  KEY `index_3` (`patient_id`),
  CONSTRAINT `FK_patient_methods_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_methods`
--

LOCK TABLES `patient_methods` WRITE;
/*!40000 ALTER TABLE `patient_methods` DISABLE KEYS */;
INSERT INTO `patient_methods` VALUES (146107,68),(146107,69),(146108,68),(146108,69),(146109,68),(146109,69),(146109,83),(146109,85),(146110,68),(146110,69),(146111,68),(146111,69),(146112,68),(146112,69);
/*!40000 ALTER TABLE `patient_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_methods_empty`
--

DROP TABLE IF EXISTS `patient_methods_empty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_methods_empty` (
  `patient_id` int(11) NOT NULL,
  `method_id` int(11) NOT NULL,
  PRIMARY KEY (`patient_id`,`method_id`),
  KEY `fk_method_id` (`method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_methods_empty`
--

LOCK TABLES `patient_methods_empty` WRITE;
/*!40000 ALTER TABLE `patient_methods_empty` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_methods_empty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_person`
--

DROP TABLE IF EXISTS `patient_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_person` (
  `patient_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  UNIQUE KEY `uniq1` (`patient_id`,`person_id`),
  KEY `fk_patient_person_2_idx` (`person_id`),
  CONSTRAINT `fk_patient_person_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_patient_person_2` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_person`
--

LOCK TABLES `patient_person` WRITE;
/*!40000 ALTER TABLE `patient_person` DISABLE KEYS */;
INSERT INTO `patient_person` VALUES (146107,145928),(146108,145929),(146109,145930),(146110,145940),(146111,145943),(146112,145942);
/*!40000 ALTER TABLE `patient_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_users`
--

DROP TABLE IF EXISTS `patient_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_users` (
  `patient_id` int(11) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_users`
--

LOCK TABLES `patient_users` WRITE;
/*!40000 ALTER TABLE `patient_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `sex` tinyint(2) DEFAULT 0,
  `status` tinyint(2) DEFAULT 0,
  `family_id` int(11) NOT NULL,
  `father_id` int(11) DEFAULT NULL,
  `mother_id` int(11) DEFAULT NULL,
  `major_project_id` int(11) DEFAULT 0,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`person_id`),
  KEY `index1` (`person_id`,`major_project_id`),
  KEY `index2` (`person_id`,`family_id`)
) ENGINE=InnoDB AUTO_INCREMENT=145944 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (145928,'HS0000145928',1,2,91222,0,0,0,'2025-01-02 09:02:31'),(145929,'HS0000145929',1,2,91223,0,0,0,'2025-01-02 09:02:31'),(145930,'HS0000145930',1,2,91224,0,0,0,'2025-01-02 15:21:24'),(145931,'HS0000145931',1,2,91225,0,0,0,'2025-01-02 15:27:49'),(145932,'HS0000145932',1,2,91226,0,0,0,'2025-01-02 15:27:49'),(145933,'HS0000145933',1,2,91227,0,0,0,'2025-01-02 15:27:49'),(145934,'HS0000145931',1,1,91228,0,0,0,'2025-01-03 08:19:04'),(145935,'HS0000145932',1,2,91228,145934,145933,0,'2025-01-03 08:19:04'),(145936,'HS0000145933',2,1,91228,0,0,0,'2025-01-03 08:19:04'),(145937,'HS0000145931',1,1,91228,0,0,0,'2025-01-03 08:41:40'),(145938,'HS0000145932',1,2,91228,145937,145936,0,'2025-01-03 08:41:40'),(145939,'HS0000145933',2,1,91228,0,0,0,'2025-01-03 08:41:40'),(145940,'HS0000145931',1,1,91228,0,0,0,'2025-01-06 08:41:56'),(145941,'HS0000145932',1,2,91228,145940,145939,0,'2025-01-06 08:41:56'),(145942,'HS0000145933',2,1,91228,0,0,0,'2025-01-06 08:41:56'),(145943,'HS0000145932',2,2,91228,145940,145942,0,'2025-01-10 15:16:19');
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perspective`
--

DROP TABLE IF EXISTS `perspective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perspective` (
  `perspective_id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`perspective_id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perspective`
--

LOCK TABLES `perspective` WRITE;
/*!40000 ALTER TABLE `perspective` DISABLE KEYS */;
/*!40000 ALTER TABLE `perspective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perspective_technology`
--

DROP TABLE IF EXISTS `perspective_technology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perspective_technology` (
  `perspective_id` int(2) NOT NULL,
  `technology_id` int(2) NOT NULL,
  PRIMARY KEY (`perspective_id`,`technology_id`),
  KEY `fk_perspective_technology_2_idx` (`technology_id`),
  CONSTRAINT `fk_perspective_technology_1` FOREIGN KEY (`perspective_id`) REFERENCES `perspective` (`perspective_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_perspective_technology_2` FOREIGN KEY (`technology_id`) REFERENCES `technology` (`technology_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perspective_technology`
--

LOCK TABLES `perspective_technology` WRITE;
/*!40000 ALTER TABLE `perspective_technology` DISABLE KEYS */;
/*!40000 ALTER TABLE `perspective_technology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pgroup`
--

DROP TABLE IF EXISTS `pgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pgroup` (
  `pgroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `description` varchar(150) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`pgroup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pgroup`
--

LOCK TABLES `pgroup` WRITE;
/*!40000 ALTER TABLE `pgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `pgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pgroup_person`
--

DROP TABLE IF EXISTS `pgroup_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pgroup_person` (
  `pgroup_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY (`pgroup_id`,`person_id`),
  KEY `fk_pgroup_person_2_idx` (`person_id`),
  CONSTRAINT `fk_pgroup_person_1` FOREIGN KEY (`pgroup_id`) REFERENCES `pgroup` (`pgroup_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pgroup_person_2` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pgroup_person`
--

LOCK TABLES `pgroup_person` WRITE;
/*!40000 ALTER TABLE `pgroup_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `pgroup_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phenotype`
--

DROP TABLE IF EXISTS `phenotype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phenotype` (
  `phenotype_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `update_date` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`phenotype_id`),
  UNIQUE KEY `index_2` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phenotype`
--

LOCK TABLES `phenotype` WRITE;
/*!40000 ALTER TABLE `phenotype` DISABLE KEYS */;
/*!40000 ALTER TABLE `phenotype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phenotype_project`
--

DROP TABLE IF EXISTS `phenotype_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phenotype_project` (
  `phenotype_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`phenotype_id`,`project_id`),
  KEY `fk_phenotype_project_1` (`phenotype_id`),
  KEY `fk_phenotype_project_2` (`project_id`),
  CONSTRAINT `fk_phenotype_project_1` FOREIGN KEY (`phenotype_id`) REFERENCES `phenotype` (`phenotype_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_phenotype_project_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phenotype_project`
--

LOCK TABLES `phenotype_project` WRITE;
/*!40000 ALTER TABLE `phenotype_project` DISABLE KEYS */;
/*!40000 ALTER TABLE `phenotype_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plateform`
--

DROP TABLE IF EXISTS `plateform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plateform` (
  `plateform_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `def` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`plateform_id`),
  KEY `index_2` (`plateform_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plateform`
--

LOCK TABLES `plateform` WRITE;
/*!40000 ALTER TABLE `plateform` DISABLE KEYS */;
INSERT INTO `plateform` VALUES (1,'IMAGINE',1),(2,'INTEGRAGEN',0),(3,'ROCKFELLER',0),(4,'MIAMI',0),(5,'CNG',1),(6,'FASTERIS',0),(7,'ALLEMAGNE',0),(8,'DNA-VISION',0),(9,'BGI',0),(10,'SALPETRIERE',0),(11,'UNKNOWN',0),(12,'NOVARTIS',0),(13,'MARSEILLE',0),(14,'COCHIN',0),(15,'LIFETECH_US',0),(16,'CeGaT',0),(17,'CNS',0),(18,'LAVOISIER',1),(19,'HEMATO',1),(20,'GDANSK',0),(21,'HEIDELBERG',0),(22,'HEGP',0),(23,'BICHAT',1),(24,'IGBMC',0),(25,'OTOGENETICS',0),(26,'LILLE',0),(27,'CURIE',0),(28,'BUDAPEST',0),(29,'PRAGUE',0),(30,'ROUEN',0),(31,'DIJON',0),(32,'PACBIO',0),(33,'HERMINE',0),(34,'ICM',1),(35,'MACROGEN',1);
/*!40000 ALTER TABLE `plateform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `polydb`
--

DROP TABLE IF EXISTS `polydb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `polydb` (
  `db_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `prod` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`db_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `polydb`
--

LOCK TABLES `polydb` WRITE;
/*!40000 ALTER TABLE `polydb` DISABLE KEYS */;
INSERT INTO `polydb` VALUES (1,'Polyprod',1),(2,'Polyrock',1),(3,'polydev',0),(4,'Polyexome',1);
/*!40000 ALTER TABLE `polydb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preparation`
--

DROP TABLE IF EXISTS `preparation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparation` (
  `preparation_id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`preparation_id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preparation`
--

LOCK TABLES `preparation` WRITE;
/*!40000 ALTER TABLE `preparation` DISABLE KEYS */;
/*!40000 ALTER TABLE `preparation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `profile_id` int(5) NOT NULL AUTO_INCREMENT,
  `perspective_id` int(2) NOT NULL,
  `technology_id` int(2) NOT NULL,
  `preparation_id` int(2) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`profile_id`),
  UNIQUE KEY `uniq` (`perspective_id`,`technology_id`,`preparation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,1,1,1,'bulk standard pcr'),(2,1,11,4,'bulk neb pcr-free'),(3,1,1,3,'bulk standard capture'),(4,1,1,4,'bulk standard pcr-free'),(5,1,2,3,'bulk editing capture'),(6,1,2,5,'bulk editing base_editing'),(7,1,2,6,'bulk editing nhej'),(8,1,2,7,'bulk editing prime_editing'),(9,2,3,8,'singlecell 10X adt+vdj'),(10,2,3,9,'singlecell 10X exp'),(11,2,3,10,'singlecell 10X vdj'),(12,2,3,11,'singlecell 10X nuclei'),(13,2,3,12,'singlecell 10X arc'),(14,2,3,13,'singlecell 10X atac'),(15,2,4,9,'singlecell tapestri exp'),(16,2,4,14,'singlecell tapestri crispr'),(17,2,5,9,'singlecell parsebioscience exp'),(18,3,3,8,'spatial 10X adt+vdj'),(19,3,3,9,'spatial 10X exp'),(20,3,3,10,'spatial 10X vdj'),(21,3,3,11,'spatial 10X nuclei'),(22,3,3,12,'spatial 10X arc'),(23,3,3,13,'spatial 10X atac'),(24,3,6,15,'spatial nanostring roi'),(25,1,1,17,'bulk standard rapid'),(26,2,3,16,'singlecell 10X adt'),(27,4,7,18,'methyl methyl pbat'),(28,4,7,19,'methyl methyl directionnal'),(29,4,7,20,'methyl methyl non_directionnal'),(30,5,8,14,'longread nanopore crispr'),(31,1,9,4,'bulk ribozero pcr-free'),(32,1,10,4,'bulk universal pcr-free'),(33,1,12,4,'bulk illumina pcr-free'),(34,5,8,23,'longread nanopore genome'),(35,5,8,24,'longread nanopore amplicon'),(36,5,13,23,'longread pacbio genome'),(37,1,14,4,'bulk NEB-directional pcr-free'),(38,1,16,4,'bulk repliseq pcr-free');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_pipeline`
--

DROP TABLE IF EXISTS `profile_pipeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_pipeline` (
  `pipeline_id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `content` varchar(200) NOT NULL,
  PRIMARY KEY (`pipeline_id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_pipeline`
--

LOCK TABLES `profile_pipeline` WRITE;
/*!40000 ALTER TABLE `profile_pipeline` DISABLE KEYS */;
INSERT INTO `profile_pipeline` VALUES (1,'Genome-dragen','canvas dragen-align dragen-calling manta wisecondor'),(2,'EXOME_Agilent_Twist','dragen-align dragen-calling'),(3,'BDS_pipeline_Capture_DIAG','bwa duplicate_region_calling freebayes haplotypecaller4 melt samtools unifiedgenotyper'),(4,'Dragen_pipeline_Capture_DIAG_UMI','dragen-align dragen-calling duplicate_region_calling melt'),(5,'BDS_Pipeline_RNA_DIAG','star featureCounts'),(6,'genome_defidiag','bwa'),(7,'defidiag','bwa canvas haplotypecaller4 manta wisecondor'),(8,'Cloves-v2_UMI','duplicate_region_calling haplotypecaller4 lofreq melt mutect2 p1_freebayes samtools umi_dedup unifiedgenotyper'),(9,'BDS_Pipeline_OncoHemato_v1KH_V2_Cochin','bwa duplicate_region_calling haplotypecaller4 mutect2 p1_freebayes'),(10,'oncoB_fusion','haplotypecaller4 p1_freebayes qiaseq_targeted SmCounter'),(11,'oncoB_reduit_V2','haplotypecaller4 p1_freebayes qiaseq_targeted SmCounter'),(12,'cDNA_DIAG','featureCounts star'),(13,'BDS_Pipeline_OncoT_v6_CLOVES_CHIP','duplicate_region_calling haplotypecaller4 lofreq melt mutect2 p1_freebayes samtools umi_dedup unifiedgenotyper'),(14,'BDS_Pipeline_Twist_Coag_v2_HEGP','bwa freebayes haplotypecaller4 samtools unifiedgenotyper'),(15,'EXOME_Agilent_Twist_complet','dragen-align dragen-calling haplotypecaller4 melt'),(16,'Nimblegen_GLSLTL','bwa duplicate_region_calling freebayes haplotypecaller4 melt samtools unifiedgenotyper'),(17,'BDS_Pipeline_EXOME','bwa dude haplotypecaller4 melt'),(18,'Nimblegen_GLSLTL_V4','bwa duplicate_region_calling freebayes haplotypecaller4 melt samtools unifiedgenotyper'),(19,'Dragen_Pipeline_RNA_DIAG','dragen-align'),(20,'PEDIAC','bwa duplicate_region_calling haplotypecaller4 lofreq melt mutect2 p1_freebayes samtools unifiedgenotyper'),(21,'Dragen_Pipeline_OncoT_v6_CLOVES_CHIP','dragen-align dragen-calling duplicate_region_calling haplotypecaller4 melt mutect2 p1_freebayes'),(22,'OncoB-reduit2-Twist','dragen-align dragen-calling duplicate_region_calling haplotypecaller4 melt mutect2 p1_freebayes'),(23,'prenatome_dragen_pipeline','dragen-align dragen-calling duplicate_region_calling melt p1_freebayes'),(24,'CLOVES_cfDNA','dragen-align dragen-calling duplicate_region_calling haplotypecaller4 mutect2 p02_freebayes');
/*!40000 ALTER TABLE `profile_pipeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_bundle`
--

DROP TABLE IF EXISTS `project_bundle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_bundle` (
  `project_id` int(11) NOT NULL,
  `bundle_id` varchar(45) DEFAULT NULL,
  UNIQUE KEY `uniq1` (`project_id`,`bundle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_bundle`
--

LOCK TABLES `project_bundle` WRITE;
/*!40000 ALTER TABLE `project_bundle` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_bundle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_disease`
--

DROP TABLE IF EXISTS `project_disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_disease` (
  `project_id` int(11) NOT NULL,
  `disease_id` int(11) NOT NULL,
  PRIMARY KEY (`project_id`,`disease_id`),
  KEY `fk_project_disease_1` (`project_id`),
  CONSTRAINT `fk_project_disease_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_disease`
--

LOCK TABLES `project_disease` WRITE;
/*!40000 ALTER TABLE `project_disease` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_disease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_release`
--

DROP TABLE IF EXISTS `project_release`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_release` (
  `project_release_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `release_id` int(11) NOT NULL,
  `default` int(11) NOT NULL,
  PRIMARY KEY (`project_release_id`),
  KEY `index1` (`project_id`,`default`),
  KEY `fk_project_release_1` (`project_id`),
  CONSTRAINT `fk_project_release_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8949 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_release`
--

LOCK TABLES `project_release` WRITE;
/*!40000 ALTER TABLE `project_release` DISABLE KEYS */;
INSERT INTO `project_release` VALUES (8947,9866,952,1),(8948,9867,952,1);
/*!40000 ALTER TABLE `project_release` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_releaseLike`
--

DROP TABLE IF EXISTS `project_releaseLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_releaseLike` (
  `project_release_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `release_id` int(11) NOT NULL,
  `default` int(11) NOT NULL,
  PRIMARY KEY (`project_release_id`),
  KEY `index1` (`project_id`,`default`),
  KEY `fk_project_release_1` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1023 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_releaseLike`
--

LOCK TABLES `project_releaseLike` WRITE;
/*!40000 ALTER TABLE `project_releaseLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_releaseLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_release_annotation_obsolete`
--

DROP TABLE IF EXISTS `project_release_annotation_obsolete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_release_annotation_obsolete` (
  `project_rel_annot_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `rel_annot_id` int(11) NOT NULL,
  PRIMARY KEY (`project_rel_annot_id`),
  UNIQUE KEY `index` (`project_id`,`rel_annot_id`),
  UNIQUE KEY `index_uniq` (`project_id`,`rel_annot_id`),
  KEY `fk_project_release_annotation_1` (`project_id`),
  KEY `fk_project_release_annotation_2` (`rel_annot_id`),
  CONSTRAINT `fk_project_release_annotation_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_project_release_annotation_2` FOREIGN KEY (`rel_annot_id`) REFERENCES `release_annotation_obsolete` (`rel_annot_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3056 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_release_annotation_obsolete`
--

LOCK TABLES `project_release_annotation_obsolete` WRITE;
/*!40000 ALTER TABLE `project_release_annotation_obsolete` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_release_annotation_obsolete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_release_cache_history`
--

DROP TABLE IF EXISTS `project_release_cache_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_release_cache_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` varchar(45) DEFAULT NULL,
  `version_annotation` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT current_timestamp(),
  `update_date` timestamp NULL DEFAULT NULL,
  `latest_polyweb_activity` timestamp NULL DEFAULT NULL,
  `release_genome` varchar(45) DEFAULT NULL,
  `directory` varchar(45) DEFAULT NULL,
  `latest_user` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `duo` (`project_id`,`version_annotation`)
) ENGINE=InnoDB AUTO_INCREMENT=18494 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_release_cache_history`
--

LOCK TABLES `project_release_cache_history` WRITE;
/*!40000 ALTER TABLE `project_release_cache_history` DISABLE KEYS */;
INSERT INTO `project_release_cache_history` VALUES (18471,'9867','43.20','2025-01-03 10:22:26','2025-01-08 10:06:31',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `project_release_cache_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_release_database`
--

DROP TABLE IF EXISTS `project_release_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_release_database` (
  `project_rel_annot_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `rel_annot_id` int(11) NOT NULL,
  PRIMARY KEY (`project_rel_annot_id`),
  UNIQUE KEY `index` (`project_id`,`rel_annot_id`),
  UNIQUE KEY `index_uniq` (`project_id`,`rel_annot_id`),
  KEY `fk_project_release_database_1` (`project_id`),
  KEY `fk_project_release_database_2` (`rel_annot_id`),
  CONSTRAINT `fk_project_release_database_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_project_release_database_2` FOREIGN KEY (`rel_annot_id`) REFERENCES `release_database_obsolete` (`rel_annot_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2775 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_release_database`
--

LOCK TABLES `project_release_database` WRITE;
/*!40000 ALTER TABLE `project_release_database` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_release_database` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_release_gene`
--

DROP TABLE IF EXISTS `project_release_gene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_release_gene` (
  `project_rel_gene_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `rel_gene_id` int(11) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`project_rel_gene_id`),
  UNIQUE KEY `index` (`project_id`,`rel_gene_id`),
  KEY `fk_project_release_gene_1` (`project_id`),
  KEY `fk_preoject_release_gene_2` (`rel_gene_id`),
  CONSTRAINT `fk_project_release_gene_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_project_release_gene_2` FOREIGN KEY (`rel_gene_id`) REFERENCES `release_gene` (`rel_gene_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9195 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_release_gene`
--

LOCK TABLES `project_release_gene` WRITE;
/*!40000 ALTER TABLE `project_release_gene` DISABLE KEYS */;
INSERT INTO `project_release_gene` VALUES (9193,9867,43,'2025-01-03 09:34:00'),(9194,9866,43,'2025-01-10 14:23:46');
/*!40000 ALTER TABLE `project_release_gene` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_release_public_database`
--

DROP TABLE IF EXISTS `project_release_public_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_release_public_database` (
  `version_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `creation_date` timestamp NULL DEFAULT current_timestamp(),
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `_idx` (`project_id`),
  KEY `version_id` (`version_id`),
  CONSTRAINT `fk_project_id` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `version_id` FOREIGN KEY (`version_id`) REFERENCES `release_public_database` (`version_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10856 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_release_public_database`
--

LOCK TABLES `project_release_public_database` WRITE;
/*!40000 ALTER TABLE `project_release_public_database` DISABLE KEYS */;
INSERT INTO `project_release_public_database` VALUES (20,9867,'2025-01-03 09:40:30',10854),(20,9866,'2025-01-10 14:23:46',10855);
/*!40000 ALTER TABLE `project_release_public_database` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_types`
--

DROP TABLE IF EXISTS `project_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_types` (
  `type_project_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`type_project_id`),
  KEY `index_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_types`
--

LOCK TABLES `project_types` WRITE;
/*!40000 ALTER TABLE `project_types` DISABLE KEYS */;
INSERT INTO `project_types` VALUES (1,'array'),(2,'classic'),(4,'cnv'),(6,'junk'),(3,'ngs'),(5,'reference');
/*!40000 ALTER TABLE `project_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `type_project_id` int(10) unsigned NOT NULL,
  `dejaVu` tinyint(1) DEFAULT 1,
  `somatic` tinyint(1) unsigned zerofill DEFAULT 0,
  `validation_db` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`project_id`),
  KEY `index2` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9868 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1199,'NGS2025_0001','TEST UNIQUEMENT','2012-06-11 11:09:46',3,0,0,NULL),(9866,'NGS2025_0002','test','2025-01-02 09:10:45',3,1,0,NULL),(9867,'NGS2025_0003','test2','2025-01-02 15:28:37',3,1,0,NULL);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_annotation_obsolete`
--

DROP TABLE IF EXISTS `release_annotation_obsolete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_annotation_obsolete` (
  `rel_annot_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `species` varchar(20) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `diag` tinyint(1) NOT NULL,
  `genome` tinyint(1) NOT NULL,
  PRIMARY KEY (`rel_annot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_annotation_obsolete`
--

LOCK TABLES `release_annotation_obsolete` WRITE;
/*!40000 ALTER TABLE `release_annotation_obsolete` DISABLE KEYS */;
/*!40000 ALTER TABLE `release_annotation_obsolete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_database_obsolete`
--

DROP TABLE IF EXISTS `release_database_obsolete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_database_obsolete` (
  `rel_annot_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `species` varchar(20) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `diag` tinyint(1) NOT NULL,
  `genome` tinyint(1) NOT NULL,
  PRIMARY KEY (`rel_annot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_database_obsolete`
--

LOCK TABLES `release_database_obsolete` WRITE;
/*!40000 ALTER TABLE `release_database_obsolete` DISABLE KEYS */;
/*!40000 ALTER TABLE `release_database_obsolete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_gene`
--

DROP TABLE IF EXISTS `release_gene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_gene` (
  `rel_gene_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `default` tinyint(1) unsigned zerofill DEFAULT 0,
  `species_id` int(3) NOT NULL DEFAULT 1,
  PRIMARY KEY (`rel_gene_id`)
) ENGINE=InnoDB AUTO_INCREMENT=946 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_gene`
--

LOCK TABLES `release_gene` WRITE;
/*!40000 ALTER TABLE `release_gene` DISABLE KEYS */;
INSERT INTO `release_gene` VALUES (-1,'-1','2020-05-19 16:02:41',0,1),(0,'0','2020-05-06 12:32:05',0,1),(1,'19','2020-01-13 14:29:09',0,1),(2,'28','2020-01-13 14:29:09',0,1),(3,'31','2020-01-13 14:29:09',0,1),(4,'33.1','2020-06-11 07:34:55',0,1),(5,'19.2','2022-05-04 15:13:02',0,1),(33,'33','2020-05-06 08:58:03',0,1),(34,'34','2020-06-11 07:35:10',0,1),(38,'38','2022-04-21 07:35:10',0,1),(39,'39','2022-03-11 08:35:10',0,1),(40,'40','2022-05-04 15:13:02',0,1),(41,'41','2022-11-17 15:26:30',0,1),(42,'42','2022-11-30 14:59:13',0,1),(43,'43','2023-03-20 10:52:53',1,1),(45,'45','2024-09-19 12:41:47',0,1),(225,'M25','2023-03-27 15:13:28',0,2),(232,'M32','2023-03-27 15:13:28',0,2),(234,'M34','2024-01-25 09:59:59',0,2),(401,'110','2023-11-09 10:52:37',0,4),(943,'43.1','2023-03-29 09:11:12',0,1);
/*!40000 ALTER TABLE `release_gene` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_public_database`
--

DROP TABLE IF EXISTS `release_public_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_public_database` (
  `version_id` int(11) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `description` varchar(45) DEFAULT NULL,
  `default` tinyint(1) unsigned zerofill DEFAULT 0,
  PRIMARY KEY (`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_public_database`
--

LOCK TABLES `release_public_database` WRITE;
/*!40000 ALTER TABLE `release_public_database` DISABLE KEYS */;
INSERT INTO `release_public_database` VALUES (0,'2020-05-07 13:43:49',NULL,0),(1,'2020-05-07 10:27:30',NULL,0),(2,'2020-05-07 10:27:30',NULL,0),(3,'2020-05-07 10:27:30',NULL,0),(4,'2020-05-07 10:27:30',NULL,0),(5,'2020-05-07 10:27:30',NULL,0),(6,'2020-05-07 10:27:30',NULL,0),(7,'2020-07-06 08:44:46',NULL,0),(8,'2020-07-15 12:34:11',NULL,0),(9,'2020-10-20 07:48:47',NULL,0),(10,'2021-03-09 20:04:01',NULL,0),(11,'2021-04-20 07:03:22',NULL,0),(12,'2021-07-07 19:36:55',NULL,0),(13,'2021-10-19 12:28:43',NULL,0),(14,'2022-01-21 15:01:00',NULL,0),(15,'2022-04-08 13:18:35',NULL,0),(16,'2022-07-01 11:18:35',NULL,0),(17,'2022-08-29 09:11:51',NULL,0),(18,'2023-01-30 09:39:31',NULL,0),(19,'2023-06-20 08:15:16',NULL,0),(20,'2024-04-09 12:57:50',NULL,1),(21,'2024-09-19 12:39:14',NULL,0);
/*!40000 ALTER TABLE `release_public_database` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `releases`
--

DROP TABLE IF EXISTS `releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releases` (
  `release_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `species` varchar(20) NOT NULL,
  `def` tinyint(1) unsigned DEFAULT 1,
  `species_id` int(3) NOT NULL DEFAULT 1,
  PRIMARY KEY (`release_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `releases`
--

LOCK TABLES `releases` WRITE;
/*!40000 ALTER TABLE `releases` DISABLE KEYS */;
INSERT INTO `releases` VALUES (319,'HG19_MT','human',1,1),(320,'HG38-EBV','human',0,1),(321,'MM10-NLS-LacZ-SV40polyA','mouse',0,2),(322,'HG38-EBV1','human',0,1),(339,'MM39','mouse',1,2),(351,'HG19_DRAGEN','human',0,1),(381,'HG38_CNG','human',1,1),(500,'RN6','rat',1,3),(601,'EBV','virus',0,7),(602,'EBV95-8','virus',0,7),(603,'RN6_MEDUSE','rat',0,3),(604,'FC9','cat',1,5),(605,'COVID19','covid',0,8),(606,'MED16','human',0,1),(607,'HG38-HPV','human',0,1),(666,'WAI','human',0,1),(700,'GRCg6a','chicken',0,6),(800,'MM38','mouse',1,2),(850,'HG38-MM10','human-mouse',0,1),(900,'OTHER','unknown',0,11),(901,'MT','human',0,1),(902,'CF4','dog',0,12),(910,'DR10','zebrafish',0,4),(911,'DR11','zebrafish',1,4),(919,'HG19','human',1,1),(920,'HG19b','human',0,1),(921,'HG19c','human',0,1),(922,'MM38-ERCC','mouse',0,2),(923,'COHEN','human',0,1),(924,'HBG','human',0,1),(925,'HG19-GBAP1','human',0,1),(926,'MM38-GFP-TOMATO','mouse',0,2),(927,'tRNA','synthetic',0,10),(928,'HG19c.28','human',0,1),(929,'HG19_CNG','human',1,1),(930,'MM10-colnot','mouse',0,2),(931,'HG19.31','human',0,1),(932,'MM10-Tomato_LacZ','mouse',0,2),(933,'MM39-Notch3-rat','mouse',0,2),(934,'HG38-AAV','human',1,1),(935,'MM39-eYFP','mouse',0,2),(936,'MM39-tdTomato','mouse',0,2),(938,'HG38','human',1,1),(939,'lncHG38','human',0,1),(940,'HG38-EGFP','human',0,1),(941,'HG38-ERCC','human',0,1),(942,'sgRNA','crispr',0,9),(943,'HG38-CYBB','human',0,1),(944,'HG38-Virus','human',0,1),(945,'HG38-Sven','human',0,1),(946,'HG38-CRE-EGFP','human',0,1),(947,'MM38-CRE-EGFP','mouse',0,2),(948,'T2T','human',1,1),(950,'MUC1','human',0,1),(951,'HG19_39','human',0,1),(952,'HG38_DRAGEN','human',0,1),(999,'HG18','human',0,1),(9999,'HG38_mCherry_eFFLY_and_MM38','human',0,1);
/*!40000 ALTER TABLE `releases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `run`
--

DROP TABLE IF EXISTS `run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `run` (
  `run_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_run_id` int(10) unsigned NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `description` varchar(150) NOT NULL,
  `document` longblob DEFAULT NULL,
  `file_name` varchar(100) DEFAULT NULL,
  `file_type` varchar(5) DEFAULT NULL,
  `ident_seq` varchar(20) DEFAULT NULL,
  `nbrun_solid` smallint(6) DEFAULT NULL,
  `nbrun_tor` smallint(6) DEFAULT NULL,
  `step` tinyint(1) unsigned zerofill DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `nbpatient` smallint(3) DEFAULT NULL,
  `plateform_run_name` varchar(100) DEFAULT NULL,
  `plt` tinyint(1) unsigned zerofill DEFAULT NULL,
  `fl_revcomp` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`run_id`),
  KEY `index2` (`type_run_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6165 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `run`
--

LOCK TABLES `run` WRITE;
/*!40000 ALTER TABLE `run` DISABLE KEYS */;
INSERT INTO `run` VALUES (6163,3,'2025-01-02 09:02:30','test',NULL,NULL,NULL,NULL,NULL,NULL,1,'test',3,'test',NULL,0),(6164,3,'2025-01-02 15:27:49','test2',NULL,NULL,NULL,NULL,NULL,NULL,1,'test2',3,'',NULL,0);
/*!40000 ALTER TABLE `run` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `runBak`
--

DROP TABLE IF EXISTS `runBak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runBak` (
  `run_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_run_id` int(10) unsigned NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`run_id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `runBak`
--

LOCK TABLES `runBak` WRITE;
/*!40000 ALTER TABLE `runBak` DISABLE KEYS */;
/*!40000 ALTER TABLE `runBak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `runLike`
--

DROP TABLE IF EXISTS `runLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `runLike` (
  `run_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_run_id` int(10) unsigned NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `description` varchar(150) NOT NULL,
  `document` longblob NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `file_type` varchar(5) NOT NULL,
  `ident_seq` varchar(20) NOT NULL,
  `nbrun_solid` smallint(6) NOT NULL,
  `nbrun_tor` smallint(6) NOT NULL,
  `step` tinyint(1) unsigned zerofill NOT NULL,
  `name` varchar(100) NOT NULL,
  `nbpatient` smallint(3) NOT NULL,
  `plateform_run_name` varchar(100) NOT NULL,
  PRIMARY KEY (`run_id`)
) ENGINE=InnoDB AUTO_INCREMENT=831 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `runLike`
--

LOCK TABLES `runLike` WRITE;
/*!40000 ALTER TABLE `runLike` DISABLE KEYS */;
/*!40000 ALTER TABLE `runLike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `run_machine`
--

DROP TABLE IF EXISTS `run_machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `run_machine` (
  `run_id` int(11) NOT NULL,
  `machine_id` int(11) NOT NULL,
  PRIMARY KEY (`run_id`,`machine_id`),
  KEY `index_1` (`run_id`),
  KEY `index_2` (`machine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `run_machine`
--

LOCK TABLES `run_machine` WRITE;
/*!40000 ALTER TABLE `run_machine` DISABLE KEYS */;
INSERT INTO `run_machine` VALUES (6163,21),(6164,21);
/*!40000 ALTER TABLE `run_machine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `run_method_seq`
--

DROP TABLE IF EXISTS `run_method_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `run_method_seq` (
  `run_id` int(11) NOT NULL,
  `method_seq_id` int(11) NOT NULL,
  PRIMARY KEY (`run_id`,`method_seq_id`),
  KEY `FK_run_method_seq` (`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `run_method_seq`
--

LOCK TABLES `run_method_seq` WRITE;
/*!40000 ALTER TABLE `run_method_seq` DISABLE KEYS */;
INSERT INTO `run_method_seq` VALUES (6163,1),(6164,1);
/*!40000 ALTER TABLE `run_method_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `run_methods`
--

DROP TABLE IF EXISTS `run_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `run_methods` (
  `run_id` int(11) NOT NULL,
  `method_id` int(11) NOT NULL,
  PRIMARY KEY (`run_id`,`method_id`),
  KEY `fk_method_id` (`method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `run_methods`
--

LOCK TABLES `run_methods` WRITE;
/*!40000 ALTER TABLE `run_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `run_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `run_plateform`
--

DROP TABLE IF EXISTS `run_plateform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `run_plateform` (
  `run_id` int(11) NOT NULL,
  `plateform_id` int(11) NOT NULL,
  PRIMARY KEY (`run_id`,`plateform_id`),
  KEY `FK_run_plateform` (`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `run_plateform`
--

LOCK TABLES `run_plateform` WRITE;
/*!40000 ALTER TABLE `run_plateform` DISABLE KEYS */;
INSERT INTO `run_plateform` VALUES (6163,1),(6164,1);
/*!40000 ALTER TABLE `run_plateform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `run_type`
--

DROP TABLE IF EXISTS `run_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `run_type` (
  `type_run_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`type_run_id`) USING BTREE,
  KEY `index_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `run_type`
--

LOCK TABLES `run_type` WRITE;
/*!40000 ALTER TABLE `run_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `run_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequencing_machines`
--

DROP TABLE IF EXISTS `sequencing_machines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequencing_machines` (
  `machine_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `def` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`machine_id`),
  KEY `index_2` (`machine_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequencing_machines`
--

LOCK TABLES `sequencing_machines` WRITE;
/*!40000 ALTER TABLE `sequencing_machines` DISABLE KEYS */;
INSERT INTO `sequencing_machines` VALUES (1,'SOLID3','LIFETECH',0),(2,'SOLEXA','ILLUMINA',0),(3,'SOLID4','LIFETECH',0),(4,'SOLID5500','LIFETECH',0),(5,'IONTORRENT','LIFETECH',0),(9,'WILDFIRE','SOLID',0),(10,'PROTON','LIFETECH',0),(11,'MISEQ','ILLUMINA',1),(12,'ROCHE','454',0),(13,'HISEQ2500-1','ILLUMINA',0),(14,'HISEQ2500-2','ILLUMINA',0),(15,'HISEQ2000','ILLUMINA',0),(16,'NEXTSEQ500','ILLUMINA',1),(17,'HISEQ4000','ILLUMINA',0),(18,'ILLUMINAX5','ILLUMINA',0),(19,'HISEQ2500','ILLUMINA',0),(20,'DPNI','ILLUMINA',0),(21,'10X','ILLUMINA',1),(28,'NOVASEQ','ILLUMINA',1),(29,'ISEQ','ILLUMINA',0),(30,'NOVASEQ-Abel','ILLUMINA',0),(31,'SEQUEL','PACBIO',0),(32,'MINION','NANOPORE',0),(33,'P2_solo','NANOPORE',0),(34,'DNBSEQ','BGI',0),(35,'Rhapsody','ILLUMINA',1),(36,'PACBIO','PACBIO',1),(37,'NEXTSEQ2000','ILLUMINA',1),(38,'AVITI','Element_Biosciences',1),(39,'G4','SingularGenomics',1);
/*!40000 ALTER TABLE `sequencing_machines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `species`
--

DROP TABLE IF EXISTS `species`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `species` (
  `species_id` int(3) NOT NULL,
  `name` varchar(30) NOT NULL,
  `latin` varchar(60) DEFAULT NULL,
  `code` varchar(5) NOT NULL,
  PRIMARY KEY (`species_id`),
  UNIQUE KEY `uniq1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `species`
--

LOCK TABLES `species` WRITE;
/*!40000 ALTER TABLE `species` DISABLE KEYS */;
INSERT INTO `species` VALUES (1,'human','homo sapiens','HS'),(2,'mouse','mus musculus','MM'),(3,'rat','rattus norvegicus','RN'),(4,'zebrafish','danio rerio','DR'),(5,'cat','felis catus','FC'),(6,'chicken','gallus gallus','GG'),(7,'virus','virus','VI'),(8,'covid','virus','VI'),(9,'crispr','synthetic','SY'),(10,'synthetic','synthetic','SY'),(11,'unknown','unknown','UN'),(12,'dog','Canis Familiaris','CF');
/*!40000 ALTER TABLE `species` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `technology`
--

DROP TABLE IF EXISTS `technology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `technology` (
  `technology_id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`technology_id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `technology`
--

LOCK TABLES `technology` WRITE;
/*!40000 ALTER TABLE `technology` DISABLE KEYS */;
INSERT INTO `technology` VALUES (3,'10X'),(2,'editing'),(12,'illumina'),(7,'methyl'),(8,'nanopore'),(6,'nanostring'),(11,'neb'),(14,'NEB-directional'),(13,'pacbio'),(5,'parsebioscience'),(16,'repliseq'),(9,'ribozero'),(1,'standard'),(4,'tapestri'),(10,'universal');
/*!40000 ALTER TABLE `technology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `technology_preparation`
--

DROP TABLE IF EXISTS `technology_preparation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `technology_preparation` (
  `technology_id` int(2) NOT NULL,
  `preparation_id` int(2) NOT NULL,
  PRIMARY KEY (`technology_id`,`preparation_id`),
  KEY `fk_technology_preparation_2_idx` (`preparation_id`),
  CONSTRAINT `fk_technology_preparation_1` FOREIGN KEY (`technology_id`) REFERENCES `technology` (`technology_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_technology_preparation_2` FOREIGN KEY (`preparation_id`) REFERENCES `preparation` (`preparation_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `technology_preparation`
--

LOCK TABLES `technology_preparation` WRITE;
/*!40000 ALTER TABLE `technology_preparation` DISABLE KEYS */;
/*!40000 ALTER TABLE `technology_preparation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transcripts`
--

DROP TABLE IF EXISTS `transcripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transcripts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GENE` varchar(25) DEFAULT NULL,
  `ENSEMBL_ID` varchar(25) NOT NULL,
  `transmission` varchar(45) DEFAULT NULL,
  `deprecated` int(11) DEFAULT 0,
  `date_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `index_2` (`ENSEMBL_ID`),
  KEY `index_3` (`deprecated`,`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=231671 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transcripts`
--

LOCK TABLES `transcripts` WRITE;
/*!40000 ALTER TABLE `transcripts` DISABLE KEYS */;
/*!40000 ALTER TABLE `transcripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_description`
--

DROP TABLE IF EXISTS `type_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_description` (
  `type_description_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`type_description_id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_description`
--

LOCK TABLES `type_description` WRITE;
/*!40000 ALTER TABLE `type_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ugroup_projects`
--

DROP TABLE IF EXISTS `ugroup_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ugroup_projects` (
  `UGROUP_ID` int(10) unsigned NOT NULL,
  `PROJECT_ID` int(11) NOT NULL,
  PRIMARY KEY (`UGROUP_ID`,`PROJECT_ID`),
  KEY `fk_group_projects_1_idx` (`PROJECT_ID`),
  CONSTRAINT `fk_group_projects_1` FOREIGN KEY (`PROJECT_ID`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ugroup_projects`
--

LOCK TABLES `ugroup_projects` WRITE;
/*!40000 ALTER TABLE `ugroup_projects` DISABLE KEYS */;
INSERT INTO `ugroup_projects` VALUES (12,9867);
/*!40000 ALTER TABLE `ugroup_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `umi`
--

DROP TABLE IF EXISTS `umi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umi` (
  `umi_id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `mask` varchar(45) NOT NULL,
  PRIMARY KEY (`umi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umi`
--

LOCK TABLES `umi` WRITE;
/*!40000 ALTER TABLE `umi` DISABLE KEYS */;
/*!40000 ALTER TABLE `umi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_last_connection`
--

DROP TABLE IF EXISTS `user_last_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_last_connection` (
  `user_id` int(11) unsigned NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_last_connection`
--

LOCK TABLES `user_last_connection` WRITE;
/*!40000 ALTER TABLE `user_last_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_last_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_projects`
--

DROP TABLE IF EXISTS `user_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_projects` (
  `USER_ID` int(10) unsigned NOT NULL,
  `PROJECT_ID` int(11) NOT NULL,
  `UGROUP_ID` int(10) DEFAULT 0,
  PRIMARY KEY (`USER_ID`,`PROJECT_ID`) USING BTREE,
  KEY `fk_user_projects_1` (`PROJECT_ID`),
  CONSTRAINT `fk_user_projects_1` FOREIGN KEY (`PROJECT_ID`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_projects`
--

LOCK TABLES `user_projects` WRITE;
/*!40000 ALTER TABLE `user_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_projects_last_connection`
--

DROP TABLE IF EXISTS `user_projects_last_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_projects_last_connection` (
  `user_id` int(11) unsigned NOT NULL,
  `project_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `viewer` varchar(45) NOT NULL DEFAULT 'polyQuery',
  PRIMARY KEY (`user_id`,`project_id`,`viewer`),
  KEY `ft_user_proj_lastc` (`project_id`),
  CONSTRAINT `ft_user_proj_lastc` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_projects_last_connection`
--

LOCK TABLES `user_projects_last_connection` WRITE;
/*!40000 ALTER TABLE `user_projects_last_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_projects_last_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version_patients`
--

DROP TABLE IF EXISTS `version_patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version_patients` (
  `version_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `modification_date` datetime NOT NULL,
  `cmd` varchar(3000) NOT NULL DEFAULT '-',
  KEY `index` (`version_id`,`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version_patients`
--

LOCK TABLES `version_patients` WRITE;
/*!40000 ALTER TABLE `version_patients` DISABLE KEYS */;
/*!40000 ALTER TABLE `version_patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version_software`
--

DROP TABLE IF EXISTS `version_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version_software` (
  `version_id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`version_id`),
  UNIQUE KEY `unique` (`version`,`name`),
  KEY `index1` (`version`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version_software`
--

LOCK TABLES `version_software` WRITE;
/*!40000 ALTER TABLE `version_software` DISABLE KEYS */;
INSERT INTO `version_software` VALUES (3,'3.0','DRAGEN'),(4,'4.2.4','DRAGEN'),(5,'4.3','DRAGEN');
/*!40000 ALTER TABLE `version_software` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-14  3:05:26
