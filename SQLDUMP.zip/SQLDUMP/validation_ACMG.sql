/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 129.85.163.136    Database: validation_ACMG
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acmg`
--

DROP TABLE IF EXISTS `acmg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acmg` (
  `idacmg` int(11) NOT NULL,
  `term` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idacmg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acmg`
--

LOCK TABLES `acmg` WRITE;
/*!40000 ALTER TABLE `acmg` DISABLE KEYS */;
/*!40000 ALTER TABLE `acmg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cnv_validations`
--

DROP TABLE IF EXISTS `cnv_validations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cnv_validations` (
  `validation_id` int(11) NOT NULL AUTO_INCREMENT,
  `cnv_id` int(11) DEFAULT NULL,
  `project_id` varchar(45) DEFAULT NULL,
  `validation` int(11) DEFAULT NULL,
  `sample_name` varchar(45) DEFAULT NULL,
  `sample_id` varchar(45) DEFAULT NULL,
  `user_name` varchar(45) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT current_timestamp(),
  `modification_date` timestamp NULL DEFAULT NULL,
  `project_name` varchar(20) DEFAULT NULL,
  `infos` varchar(500) DEFAULT NULL,
  `phenotypes_id` varchar(45) DEFAULT NULL,
  `phenotypes_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`validation_id`),
  UNIQUE KEY `index3` (`sample_id`,`validation`,`user_name`),
  KEY `index4` (`sample_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cnv_validations`
--

LOCK TABLES `cnv_validations` WRITE;
/*!40000 ALTER TABLE `cnv_validations` DISABLE KEYS */;
/*!40000 ALTER TABLE `cnv_validations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cnvs`
--

DROP TABLE IF EXISTS `cnvs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cnvs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chromosome` varchar(3) DEFAULT NULL,
  `start` int(11) DEFAULT NULL,
  `end` int(11) DEFAULT NULL,
  `type` varchar(4) DEFAULT NULL,
  `version` varchar(4) DEFAULT 'HG19',
  `creation_date` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `index2` (`chromosome`,`start`,`end`,`type`),
  KEY `index4` (`end`),
  KEY `index5` (`start`),
  KEY `index6` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cnvs`
--

LOCK TABLES `cnvs` WRITE;
/*!40000 ALTER TABLE `cnvs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cnvs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exons`
--

DROP TABLE IF EXISTS `exons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exons` (
  `exon_id` varchar(200) NOT NULL,
  `project_name` varchar(45) NOT NULL,
  `chromosome` varchar(5) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  `todo` int(11) NOT NULL,
  `done` int(11) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `transcript` varchar(60) NOT NULL,
  `gene` varchar(60) NOT NULL,
  `sample_name` varchar(45) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modification_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`exon_id`,`project_name`) USING BTREE,
  KEY `index_3` (`exon_id`),
  KEY `index_2` (`project_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='InnoDB free: 206848 kB; InnoDB free: 185344 kB; InnoDB free:';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exons`
--

LOCK TABLES `exons` WRITE;
/*!40000 ALTER TABLE `exons` DISABLE KEYS */;
/*!40000 ALTER TABLE `exons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `sample` varchar(45) NOT NULL,
  `project` varchar(45) NOT NULL,
  `json` text NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `conclusion` text NOT NULL,
  `user_name` varchar(45) NOT NULL,
  PRIMARY KEY (`report_id`),
  UNIQUE KEY `index_2` (`sample`,`project`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='InnoDB free: 206848 kB; InnoDB free: 185344 kB; InnoDB free:';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `samples_status`
--

DROP TABLE IF EXISTS `samples_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `samples_status` (
  `sample_id` int(32) NOT NULL,
  `sample_name` varchar(45) NOT NULL,
  `project_name` varchar(45) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(45) NOT NULL,
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `project_id` int(32) NOT NULL,
  `comment` varchar(50) DEFAULT NULL,
  `modification_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `two` (`sample_id`,`user_name`,`status`),
  KEY `one` (`sample_id`),
  KEY `three` (`sample_id`,`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `samples_status`
--

LOCK TABLES `samples_status` WRITE;
/*!40000 ALTER TABLE `samples_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `samples_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validations`
--

DROP TABLE IF EXISTS `validations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `validations` (
  `variation_id` int(11) NOT NULL,
  `project_name` varchar(45) NOT NULL,
  `project_id` int(11) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `validation` int(11) NOT NULL,
  `old_validation` int(11) NOT NULL DEFAULT 0,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `sample_name` varchar(45) NOT NULL,
  `vcf_line` varchar(1000) NOT NULL,
  `modification_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `validation_id` int(11) NOT NULL AUTO_INCREMENT,
  `method` varchar(45) DEFAULT NULL,
  `validation_sanger` int(11) DEFAULT NULL,
  `gene_name` varchar(45) NOT NULL,
  `gene_id` varchar(45) NOT NULL,
  `sample_id` int(32) DEFAULT NULL,
  `phenotypes_id` varchar(200) DEFAULT NULL,
  `phenotypes_name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`validation_id`) USING BTREE,
  UNIQUE KEY `index_unique` (`variation_id`,`project_name`,`user_name`,`validation`,`sample_name`,`gene_id`),
  KEY `index_3` (`gene_id`,`variation_id`,`project_name`,`user_name`,`sample_name`),
  KEY `index_4` (`variation_id`) USING BTREE,
  KEY `index_5` (`creation_date`),
  KEY `index7` (`project_name`) USING BTREE,
  KEY `index6` (`project_id`) USING BTREE,
  KEY `index8` (`project_name`,`sample_name`,`variation_id`),
  KEY `index10` (`modification_date`) USING BTREE,
  KEY `index9` (`variation_id`,`modification_date`,`validation`),
  CONSTRAINT `FK_validations_1` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`variation_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='InnoDB free: 206848 kB; InnoDB free: 185344 kB; InnoDB free:';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validations`
--

LOCK TABLES `validations` WRITE;
/*!40000 ALTER TABLE `validations` DISABLE KEYS */;
/*!40000 ALTER TABLE `validations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variations`
--

DROP TABLE IF EXISTS `variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variations` (
  `variation_id` int(11) NOT NULL AUTO_INCREMENT,
  `polyid` varchar(100) NOT NULL,
  `vcfid` varchar(100) NOT NULL,
  `genbo_id` int(11) DEFAULT NULL,
  `version` varchar(10) NOT NULL,
  `chromosome` varchar(45) NOT NULL,
  `start` int(32) NOT NULL,
  `sequence` varchar(500) NOT NULL,
  `type` varchar(45) NOT NULL,
  `end` int(32) NOT NULL,
  `rs` varchar(45) NOT NULL,
  `uniq_id` int(32) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`variation_id`),
  UNIQUE KEY `index_5` (`chromosome`,`start`,`sequence`,`end`,`version`,`type`) USING BTREE,
  UNIQUE KEY `index_2` (`polyid`,`version`),
  UNIQUE KEY `index_3` (`vcfid`,`version`),
  KEY `index_4` (`genbo_id`,`version`) USING BTREE,
  KEY `idx_variations_chromosome` (`chromosome`,`version`),
  KEY `idx` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='InnoDB free: 206848 kB; InnoDB free: 185344 kB; InnoDB free:';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variations`
--

LOCK TABLES `variations` WRITE;
/*!40000 ALTER TABLE `variations` DISABLE KEYS */;
/*!40000 ALTER TABLE `variations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-14  3:09:26
