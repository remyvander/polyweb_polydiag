#!/bin/bash
 
#pushd `dirname $0` > /dev/null
#DIR=`pwd -P`
#popd > /dev/null

if [ -e "/"$0 ] ;
then 
#    echo "File found ${TEST}"
    DIR=`dirname $0`
else
#    echo "File not found ${TEST}"
    DIR=`pwd -P`"/"`dirname $0`
fi

echo $DIR

source $DIR/../conf/polyweb-core.cfg
sleep 1
echo $POLY_DISK_MYSQL
sleep 2
echo $POLY_DISK_SRC

if [ ! -d $POLY_DISK_SRC ];
then
	mkdir -p $POLY_DISK_SRC
	chmod a+rwx $POLY_DISK_SRC
fi
sleep 1
echo $POLY_DISK_NGS
if [ ! -d $POLY_DISK_NGS ];
then
	mkdir -p $POLY_DISK_NGS
	chmod a+rwx $POLY_DISK_NGS
fi
sleep 1
echo $POLY_DISK_TMP
if [ ! -d $POLY_DISK_TMP ];
then
	mkdir -p $POLY_DISK_TMP
	chmod a+rwx $POLY_DISK_TMP
fi
sleep 1
echo $POLY_DISK_PUBLIC_DATA
if [ ! -d $POLY_DISK_PUBLIC_DATA ];
then
	mkdir -p $POLY_DISK_PUBLIC_DATA
	chmod  a+rwx $POLY_DISK_PUBLIC_DATA
fi
sleep 1
echo $POLY_DISK_BACKUP

if [ ! -d $POLY_DISK_BACKUP ];
then
	mkdir -p $POLY_DISK_BACKUP
	chmod a+rwx $POLY_DISK_BACKUP
fi

sleep 1
echo $POLY_DISK_LOG

if [ ! -d $POLY_DISK_LOG ];
then
	mkdir -p $POLY_DISK_LOG
	chmod a+rwx $POLY_DISK_LOG
	mkdir -p $POLY_DISK_LOG/httpd
	chmod a+rwx $POLY_DISK_LOG/httpd
	mkdir -p $POLY_DISK_LOG/mysql
	chmod a+rwx $POLY_DISK_LOG/mysql
fi


sleep 1
echo $POLY_DISK_WWW

if [ ! -d $POLY_DISK_WWW ];
then
	mkdir -p $POLY_DISK_WWW
	chmod  a+rwx $POLY_DISK_WWW
fi
sleep 1
echo $POLY_DISK_CACHE

if [ ! -d $POLY_DISK_CACHE ];
then
	mkdir -p $POLY_DISK_CACHE
	mkdir -p $POLY_DISK_CACHE/HG38
	mkdir -p $POLY_DISK_CACHE/HG19

	chmod -R  a+rwx $POLY_DISK_CACHE
fi

if [ ! -d $POLY_DISK_WWW/cgi-bin ];
then
	mkdir -p $POLY_DISK_WWW/cgi-bin
	chmod  a+rwx $POLY_DISK_WWW/cgi-bin
fi

if [ ! -d $POLY_DISK_WWW/html ];
then
	mkdir -p $POLY_DISK_WWW/html
	chmod  a+rwx $POLY_DISK_WWW/html
fi
if [ ! -d $POLY_DISK_WWW/icons ];
then
	mkdir -p $POLY_DISK_WWW/icons
	chmod  a+rwx $POLY_DISK_WWW/icons
fi

if [ ! -d $POLY_DISK_WWW/icons ];
then
	mkdir -p $POLY_DISK_WWW/icons
	chmod  a+rwx $POLY_DISK_WWW/icons
fi

if [ ! -d $POLY_DISK_NGS/ngs ];
then
	mkdir -p $POLY_DISK_NGS/ngs
	chmod a+rwx $POLY_DISK_NGS/ngs
fi

if [ ! -d $POLY_DISK_NGS/pipeline ];
then
	mkdir -p $POLY_DISK_NGS/pipeline
	chmod a+rwx $POLY_DISK_NGS/pipeline
fi

if [ ! -d $POLY_DISK_NGS/sequences ];
then
	mkdir -p $POLY_DISK_NGS/sequences
	chmod a+rwx $POLY_DISK_NGS/sequences
fi


#sudo -u polyweb -s $DIR/update.sh
#$DIR/update.sh
 
    echo "create GenBo link" 
cd $POLY_DISK_SRC/polymorphism-cgi/ &&  ln -s ../GenBo/ GenBo 
cd $POLY_DISK_SRC/polyprojectNGS/ && ln -s ../GenBo/ GenBo 
cd $POLY_DISK_SRC/polyusers/ && ln -s ../GenBo/ GenBo 
cd $POLY_DISK_SRC/polyRun/ && ln -s ../GenBo/ GenBo
cd $POLY_DISK_SRC/polyusers/cgi-bin/ && ln -s ../../GenBo/ GenBo 
cd $POLY_DISK_SRC/polyRun/cgi-bin/ && ln -s ../../GenBo/ GenBo
   echo "create www link"
cd $POLY_DISK_SRC/ && ln -s polygit/polymorphism-cgi polymorphism-cgi
cd $POLY_DISK_SRC/ && ln -s polygit/polypipeline polypipeline
cd $POLY_DISK_SRC/ && ln -s polygit/polyweb polyweb
cd $POLY_DISK_SRC/ && ln -s polygit/GenBo GenBo
cd $POLY_DISK_SRC/ && ln -s polygit/GenBoConfig GenBoConfig
cd $POLY_DISK_WWW/cgi-bin && ln -s ../../poly-src/polymorphism-cgi/ polymorphism-cgi
cd $POLY_DISK_WWW/cgi-bin && ln -s ../../poly-src/polyprojectNGS/cgi-bin polyprojectNGS
cd $POLY_DISK_WWW/cgi-bin &&  ln -s ../../poly-src/polyusers/cgi-bin polyusers
cd $POLY_DISK_WWW/cgi-bin &&  ln -s ../../poly-src/polyRun/cgi-bin polyrun

cd $POLY_DISK_WWW/html && ln -s ../../poly-src/polyweb/ polyweb
cd $POLY_DISK_WWW/html && ln -s ../../poly-src/polyRun/html polyRun
cd $POLY_DISK_WWW/html && ln -s ../../poly-src/polyprojectNGS/html polyprojectNGS
cd $POLY_DISK_WWW/html && ln -s ../../poly-src/polyusers/html polyusers
cd $POLY_DISK_WWW/html &&  ln -s ../../poly-src/polyweb/index-polyweb.html index.html
cd $POLY_DISK_WWW/html &&  ln -s ../../poly-data/ngs NGS
cd $POLY_DISK_WWW/html &&  ln -s ../../public-data-data public-data
cd $POLY_DISK_WWW/icons && ln -s ../../poly-src/polyweb/images/polyicons/ Polyicons


 #if [ ! -d "$POLY_DISK_PUBLIC_DATA/HG19" ]; then
# 	echo "NO PUBLIC DATA DOWNLOAD AND INSTALL ...";
#  	cd $POLY_DISK_PUBLIC_DATA/ && curl -u bipd:polywebdownload http://www.polyweb.fr/upload/HG19.tar.gz | tar -xzvf -;
#fi
#  if [ ! -d " $POLY_DISK_NGS/ngs/NGS2014_0002" ]; then
 #	echo "NO POLY-DATA AND INSTALL ...";
#  	cd $POLY_DISK_NGS/../ && curl -u bipd:polywebdownload http://www.polyweb.fr/upload/poly-data.tar.gz | tar -xzvf -;
#fi 


 
