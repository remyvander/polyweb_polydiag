#!/bin/bash
echo " Run web server for polyweb";
DIR=$(dirname $0)
source $DIR/../conf/polyweb-core.cfg


HTTP_CONF="$POLYWEB_DOCKER_CONF/httpd.conf"
TOTO=$(docker inspect polywww_https 2>/dev/null| grep "Running" )
if [[ -n $TOTO ]]
then 
echo "remove previous container"
docker rm -f polywww_https
fi



echo docker run --name polywww_https -p 8989:443  $DOCKER_OPTION_DB $DOCKER_OPTION_MOUNT -v /home/hgid-polyweb/polyweb/polyweb-install/conf/httpd.conf:/etc/httpd/conf/httpd.conf -d imaginebioinfo/polyweb:V3 /usr/sbin/httpd -DFOREGROUND
docker run --name polywww_https -p 8989:443  $DOCKER_OPTION_DB $DOCKER_OPTION_MOUNT -v /home/hgid-polyweb/polyweb/polyweb-install/conf/httpd.conf:/etc/httpd/conf/httpd.conf -d imaginebioinfo/polyweb:V3 /usr/sbin/httpd -DFOREGROUND

sleep 5

TOTO=$(docker inspect polywww_https 2>/dev/null| grep "Running" | grep "true" )
if [[ -n $TOTO ]]
then 
echo "polywww is running on port :$POLY_WWW_PORT ..."
else 
echo "Problem with polywww"
fi
